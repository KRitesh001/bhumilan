"""
tools/train_name_matcher.py - trains BhuMilan's owner-name matching model.

    python tools/train_name_matcher.py            # synthetic training pairs (+ officer labels if any)

Builds labelled pairs of Indian names:
  same person      -> initials (Ravi K.), dropped/added middle names, spelling variants
                      (Sreenivas/Srinivas, Laxmi/Lakshmi), typos, honorifics, other scripts
  different people -> same surname, same first name, similar-looking names
Adds officer decisions saved from the website (data/training/officer_labels.csv), trains a
scikit-learn LogisticRegression on engine.names.features and writes models/name_matcher.json.
Also reports accuracy against the old difflib rule and on a cross-script test set.
"""

import csv
import json
import random
import sys
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from engine.names import FEATURES, features, normalize_name  # noqa: E402

OFFICER_LABELS = ROOT / "data" / "training" / "officer_labels.csv"
OUT = ROOT / "models" / "name_matcher.json"

FIRST = ["Ravi", "Suresh", "Ramesh", "Mahesh", "Rajesh", "Srinivas", "Venkatesh", "Naveen", "Praveen", "Arjun",
         "Vikram", "Sanjay", "Ajay", "Vijay", "Harish", "Manoj", "Rohit", "Amit", "Anil", "Sunil", "Rahul",
         "Karthik", "Murugan", "Senthil", "Manjunath", "Gurpreet", "Harpreet", "Subrata", "Sourav", "Debashis",
         "Imran", "Mohammed", "Abdul", "Joseph", "Thomas", "Krishnan", "Gopal", "Prakash", "Deepak", "Nitin",
         "Priya", "Lakshmi", "Anitha", "Divya", "Pooja", "Swathi", "Keerthi", "Deepa", "Bhavana", "Asha",
         "Meena", "Neha", "Sunita", "Kavita", "Anjali", "Fatima", "Mary", "Geeta", "Radha", "Sarita",
         "Padma", "Rekha", "Shalini", "Sai", "Teja", "Satish", "Rakesh", "Dinesh", "Yogesh", "Ganesh"]
MIDDLE = ["Kumar", "Kumari", "Prasad", "Chandra", "Mohan", "Lal", "Devi", "Rani", "Nath", "Babu", "Sai", "Venkata"]
LAST = ["Reddy", "Rao", "Naidu", "Sharma", "Verma", "Gupta", "Agarwal", "Singh", "Patel", "Shah", "Desai",
        "Patil", "Kulkarni", "Joshi", "Iyer", "Nair", "Menon", "Pillai", "Gowda", "Hegde", "Das", "Bose",
        "Chatterjee", "Mukherjee", "Panda", "Mohanty", "Sahu", "Mishra", "Tiwari", "Yadav", "Khan", "Ansari",
        "Varma", "Chowdary", "Goud", "Kaur", "Gill", "Sandhu", "Bora", "Kalita", "Devi", "Kumar"]
SPELLING = [("ee", "i"), ("i", "ee"), ("sh", "s"), ("s", "sh"), ("v", "w"), ("w", "v"), ("aa", "a"), ("a", "aa"),
            ("th", "t"), ("t", "th"), ("y", "i"), ("ksh", "x"), ("x", "ksh"), ("oo", "u"), ("u", "oo"),
            ("ow", "au"), ("dd", "d"), ("d", "dd"), ("ph", "f"), ("sri", "shri"), ("sri", "sree")]


def spelling_variant(name: str, rng: random.Random) -> str:
    low = name.lower()
    options = [(a, b) for a, b in SPELLING if a in low]
    if not options:
        return name
    a, b = rng.choice(options)
    i = low.index(a)
    out = low[:i] + b + low[i + len(a):]
    return " ".join(w.capitalize() for w in out.split())


def typo(name: str, rng: random.Random) -> str:
    chars = list(name)
    idx = [i for i, c in enumerate(chars) if c.isalpha()]
    if len(idx) < 4:
        return name
    i = rng.choice(idx[1:])
    op = rng.random()
    if op < 0.4:
        del chars[i]
    elif op < 0.7 and i + 1 < len(chars):
        chars[i], chars[i + 1] = chars[i + 1], chars[i]
    else:
        chars.insert(i, chars[i])
    return "".join(chars)


def person(rng: random.Random):
    parts = [rng.choice(FIRST)]
    if rng.random() < 0.35:
        parts.append(rng.choice(MIDDLE))
    parts.append(rng.choice(LAST))
    father = [rng.choice(FIRST[:40]), parts[-1]]
    return parts, father


def vary(parts, rng: random.Random) -> str:
    p = list(parts)
    r = rng.random()
    if r < 0.18 and len(p) >= 2:
        p[-1] = p[-1][0] + "."                           # Ravi K.
    elif r < 0.30 and len(p) >= 2:
        p[0] = p[0][0] + "."                             # R. Kumar
    elif r < 0.45 and len(p) == 3:
        p = [p[0], p[2]]                                 # middle name dropped
    elif r < 0.55 and len(p) == 2:
        p = [p[0], rng.choice(MIDDLE), p[1]]             # middle name added
    elif r < 0.62:
        p = [p[-1]] + p[:-1]                             # surname first (Reddy Naveen Kumar)
    name = " ".join(p)
    if rng.random() < 0.45:
        name = spelling_variant(name, rng)
    if rng.random() < 0.20:
        name = typo(name, rng)
    if rng.random() < 0.08:
        name = rng.choice(["Sri ", "Smt ", "Shri ", "Dr "]) + name
    if rng.random() < 0.15:
        name = name.upper()
    return name


def make_pairs(n: int, seed: int):
    """Returns (name_a, name_b, father_a, father_b, same_person) tuples."""
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        parts, father = person(rng)
        a, fa = " ".join(parts), " ".join(father)
        if rng.random() < 0.5:                                         # same person
            b = vary(parts, rng)
            fb = vary(father, rng) if rng.random() < 0.8 else ""
            rows.append((a, b, fa, fb, 1))
        else:                                                          # different people (mostly hard cases)
            other, ofather = person(rng)
            r = rng.random()
            if r < 0.35:
                other[-1] = parts[-1]                                  # same surname
            elif r < 0.6:
                other[0] = parts[0]                                    # same first name
            elif r < 0.75:
                other = [parts[0], rng.choice(LAST)]                   # Ravi Reddy vs Ravi Sharma
            b = vary(other, rng) if rng.random() < 0.5 else " ".join(other)
            fb = " ".join(ofather) if rng.random() < 0.8 else ""
            if rng.random() < 0.15:
                fb = fa                                                # siblings share a father
            rows.append((a, b, fa, fb, 0))
    return rows


CROSS_SCRIPT = [  # (name in department A, name in department B, same person?)
    ("రవి కుమార్", "Ravi Kumar", 1), ("శ్రీనివాస రావు", "Srinivas Rao", 1), ("నవీన్ కుమార్ రెడ్డి", "Naveen Reddy", 1),
    ("అజయ్ నాయుడు", "Ajay Naidu", 1), ("लक्ष्मी देवी", "Laxmi Devi", 1), ("सुरेश शर्मा", "Suresh Sharma", 1),
    ("अर्जुन सिंह", "Arjun Singh", 1), ("प्रिया अग्रवाल", "Priya Agarwal", 1), ("முருகன் செல்வம்", "Murugan Selvam", 1),
    ("ಮಂಜುನಾಥ್ ಗೌಡ", "Manjunath Gowda", 1), ("সুব্রত দাস", "Subrata Das", 1), ("ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ", "Gurpreet Singh", 1),
    ("ରମେଶ ପଣ୍ଡା", "Ramesh Panda", 1), ("കൃഷ്ണൻ നായർ", "Krishnan Nair", 1), ("મહેશ પટેલ", "Mahesh Patel", 1),
    ("రవి కుమార్", "Ravi Kiran", 0), ("శ్రీనివాస రావు", "Srinivas Reddy", 0), ("सुरेश शर्मा", "Ramesh Sharma", 0),
    ("अर्जुन सिंह", "Gurpreet Singh", 0), ("प्रिया अग्रवाल", "Priya Verma", 0), ("ಮಂಜುನಾಥ್ ಗೌಡ", "Manjula Gowda", 0),
    ("সুব্রত দাস", "Sourav Das", 0), ("ରମେଶ ପଣ୍ଡା", "Ramesh Mohanty", 0), ("મહેશ પટેલ", "Suresh Patel", 0),
    ("కృష్ణ", "Radha Krishna", 0), ("लक्ष्मी देवी", "Lakshmi Prasad", 0),
    ("প্ৰিয়ংকা বৰা", "Priyanka Bora", 1), ("নবনীতা গগৈ", "Nabanita Gogoi", 1), ("ৰূপম নাথ", "R. Nath", 1),
    ("মৌচুমী চৌধুৰী", "Mousumi Choudhury", 1), ("ଦେବାଶିଷ ସ୍ୱାଇଁ", "Debashis Swain", 1), ("ସସ୍ମିତା ସାହୁ", "Sasmita Sahu", 1),
    ("প্ৰাঞ্জল বৰুৱা", "Pranjal Bora", 0), ("নবনীতা গগৈ", "Nabanita Kalita", 0), ("ଲିପି ରାଉତ", "Lipi Panda", 0),
]


def load_officer_labels():
    X, y = [], []
    if OFFICER_LABELS.exists():
        with open(OFFICER_LABELS, encoding="utf-8") as f:
            for r in csv.DictReader(f):
                X.append(features(r["name_a"], r["name_b"], r.get("father_a", ""), r.get("father_b", "")))
                y.append(int(r["same_person"]))
    return X, y


def main():
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import accuracy_score, f1_score

    train = make_pairs(12000, seed=7)
    test = make_pairs(3000, seed=99)
    Xtr = [features(a, b, fa, fb) for a, b, fa, fb, _ in train]
    ytr = [lab for *_, lab in train]
    Xo, yo = load_officer_labels()
    Xtr += Xo * 5                       # officer decisions count 5x - they are real, checked cases
    ytr += yo * 5
    Xte = [features(a, b, fa, fb) for a, b, fa, fb, _ in test]
    yte = [lab for *_, lab in test]

    scaler = StandardScaler().fit(Xtr)
    clf = LogisticRegression(max_iter=2000, C=1.0).fit(scaler.transform(Xtr), ytr)
    pred = clf.predict(scaler.transform(Xte))

    # The prototype's old rule, for comparison: difflib ratio of the raw strings >= 0.8
    raw_pred = [1 if SequenceMatcher(None, a.lower(), b.lower()).ratio() >= 0.8 else 0 for a, b, *_ in test]
    base_pred = [1 if x[0] >= 0.8 else 0 for x in Xte]   # same rule after BhuMilan's normalisation

    Xcs = [features(a, b) for a, b, _ in CROSS_SCRIPT]
    ycs = [lab for _, _, lab in CROSS_SCRIPT]
    cs_pred = clf.predict(scaler.transform(Xcs))
    cs_raw = [1 if SequenceMatcher(None, a.lower(), b.lower()).ratio() >= 0.8 else 0 for a, b, _ in CROSS_SCRIPT]

    metrics = {
        "test_pairs": len(yte),
        "accuracy": round(accuracy_score(yte, pred), 4),
        "f1": round(f1_score(yte, pred), 4),
        "old_difflib_rule_accuracy": round(accuracy_score(yte, raw_pred), 4),
        "normalised_spelling_rule_accuracy": round(accuracy_score(yte, base_pred), 4),
        "cross_script_pairs": len(ycs),
        "cross_script_accuracy": round(accuracy_score(ycs, cs_pred), 4),
        "cross_script_old_rule_accuracy": round(accuracy_score(ycs, cs_raw), 4),
        "officer_labels_used": len(yo),
    }
    model = {
        "version": datetime.now().strftime("%Y%m%d-%H%M%S"),
        "type": "logistic_regression",
        "features": FEATURES,
        "mean": [float(v) for v in scaler.mean_],
        "scale": [float(v) if v > 0 else 1.0 for v in scaler.scale_],
        "coef": [float(v) for v in clf.coef_[0]],
        "intercept": float(clf.intercept_[0]),
        "metrics": metrics,
        "training_pairs": len(ytr),
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(model, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    print("Weights:", {f: round(c, 2) for f, c in zip(FEATURES, model["coef"])})
    print("Saved", OUT)
    return model


if __name__ == "__main__":
    main()
