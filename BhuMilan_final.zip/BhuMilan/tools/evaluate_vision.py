"""
tools/evaluate_vision.py - measures boundary / building / change / height accuracy against the
generator's ground truth (data/locations/*/ground_truth.eval.json).     python tools/evaluate_vision.py
"""
import json
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from engine import vision  # noqa: E402
from engine.geo import mean_corner_offset_m  # noqa: E402


def main():
    rows = []
    for loc in sorted((ROOT / "data" / "locations").iterdir()):
        truth = json.loads((loc / "ground_truth.eval.json").read_text(encoding="utf-8"))["parcels"]
        cad = json.loads((loc / "cadastral.geojson").read_text(encoding="utf-8"))
        for f in cad["features"]:
            pid = f["properties"]["parcel_id"]
            rec = [(lat, lon) for lon, lat in f["geometry"]["coordinates"][0][:-1]]
            t = truth[pid]
            wall = [tuple(p) for p in t["wall"]]
            meta = vision.load_meta(loc / "imagery" / pid)
            img = cv2.imread(str(loc / "imagery" / pid / "ori_2025.jpg"))
            det, score = vision.match_boundary(rec, vision.extract_boundaries(img, meta))
            b_iou = vision.iou(det, wall) if det else 0.0
            b_off = mean_corner_offset_m(det, wall) if det else None
            blds = vision.buildings_in(det or rec, vision.extract_buildings(img, meta))
            tb = [b for b in t["buildings"] if 2025 in b["years"]]
            truth_area = sum(vision.area_m2([tuple(p) for p in g["polygon"]]) for g in tb)
            det_area = sum(b["area_m2"] for b in blds)
            matched = sum(1 for g in tb if any(d["shape"] == "rectangle" and vision.iou([tuple(p) for p in g["polygon"]], d["polygon"]) > 0.5 for d in blds))
            joined = sum(1 for d in blds if d["shape"] != "rectangle")
            old_img = cv2.imread(str(loc / "imagery" / pid / "ori_2019.jpg"))
            ch = vision.detect_changes_px(old_img, img, meta, [rec] + ([det] if det else []))
            truth_new = sum(1 for b in t["buildings"] if b["years"] == [2025])
            truth_new_area = sum(vision.area_m2([tuple(p) for p in b["polygon"]]) for b in t["buildings"] if b["years"] == [2025])
            hts = vision.building_heights(loc / "surface" / f"{pid}.npz", [b for b in blds if b["shape"] == "rectangle"])
            fl_ok = sum(1 for h in hts for g in tb
                        if vision.iou([tuple(p) for p in g["polygon"]], h["polygon"]) > 0.5 and h["floors_est"] == g["floors"])
            rows.append(dict(pid=pid, found=det is not None, iou=b_iou, off=b_off, bld_truth=len(tb), bld_found=matched,
                             bld_false=max(0, len(blds) - matched - joined), joined=joined, area_err=abs(det_area - truth_area) / truth_area,
                             new_truth=truth_new, new_found=len(ch["new"]), new_area=ch["new_area_m2"], new_area_truth=truth_new_area,
                             floors_ok=fl_ok))
    n = len(rows)
    found = [r for r in rows if r["found"]]
    print(f"Parcels evaluated:            {n}")
    print(f"Boundary found:               {len(found)}/{n}")
    print(f"Boundary IoU (mean / min):    {np.mean([r['iou'] for r in found]):.3f} / {min(r['iou'] for r in found):.3f}")
    print(f"Boundary corner error (mean): {np.mean([r['off'] for r in found]):.2f} m")
    bt = sum(r["bld_truth"] for r in rows)
    print(f"Buildings found (IoU>0.5):    {sum(r['bld_found'] for r in rows)}/{bt}   joined house+extension: {sum(r['joined'] for r in rows)}   false detections: {sum(r['bld_false'] for r in rows)}")
    print(f"Built-up area error (median): {100 * np.median([r['area_err'] for r in rows]):.1f} %")
    print(f"New construction found:       {sum(min(r['new_found'], r['new_truth']) for r in rows)}/{sum(r['new_truth'] for r in rows)}"
          f"   false alarms: {sum(max(0, r['new_found'] - r['new_truth']) for r in rows)}")
    nr = [r for r in rows if r["new_truth"]]
    print(f"New-construction area error:  {np.mean([abs(r['new_area'] - r['new_area_truth']) / r['new_area_truth'] for r in nr]) * 100:.1f} % (mean)")
    print(f"Floors estimated correctly:   {sum(r['floors_ok'] for r in rows)}/{bt - sum(r['new_truth'] for r in rows)} (separate buildings)")
    good_b = [r for r in found if r["iou"] >= 0.9]
    metrics = {
        "parcels": n, "boundary_found": len(found), "boundary_iou_ge_0_9": len(good_b),
        "boundary_iou_mean": round(float(np.mean([r["iou"] for r in good_b])), 3),
        "boundary_corner_error_m": round(float(np.mean([r["off"] for r in good_b])), 2),
        "buildings_truth": bt, "buildings_found": sum(r["bld_found"] for r in rows),
        "joined_house_extension": sum(r["joined"] for r in rows),
        "false_building_detections": sum(r["bld_false"] for r in rows),
        "built_up_area_error_median_pct": round(100 * float(np.median([r["area_err"] for r in rows])), 1),
        "new_construction_truth": sum(r["new_truth"] for r in rows),
        "new_construction_found": sum(min(r["new_found"], r["new_truth"]) for r in rows),
        "new_construction_false_alarms": sum(max(0, r["new_found"] - r["new_truth"]) for r in rows),
        "new_construction_area_error_pct": round(float(np.mean([abs(r["new_area"] - r["new_area_truth"]) / r["new_area_truth"] for r in nr])) * 100, 1),
        "floors_correct": sum(r["floors_ok"] for r in rows),
        "floors_evaluated": bt - sum(r["new_truth"] for r in rows),
        "note": "Measured on BhuMilan's synthetic pilot imagery against the generator's ground truth.",
    }
    (ROOT / "models" / "vision_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    bad = [r for r in rows if not r["found"] or r["iou"] < 0.9 or r["bld_false"] or r["new_found"] != r["new_truth"]]
    for r in bad[:15]:
        print("  check:", r)
    return rows


if __name__ == "__main__":
    main()
