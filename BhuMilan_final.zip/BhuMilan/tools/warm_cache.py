"""
warm_cache.py - analyse every pilot location's drone imagery once, ahead of time.

Run at deploy time (see render.yaml) so the first visitor doesn't wait while
walls, roofs and heights are extracted. Safe to run again; results are cached
in data/cache/vision.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from engine import pipeline, store  # noqa: E402


def main():
    t0 = time.perf_counter()
    for m in store.list_locations():
        if any(d["type"] == "cadastral" for d in m["datasets"]):
            s = pipeline.harmonize(m["id"])["summary"]
            print(f"{m['id']}: {s['total_parcels']} parcels, {s['verified']} verified")
    print(f"Cache ready in {time.perf_counter() - t0:.1f} s")


if __name__ == "__main__":
    main()
