"""
tools/generate_pilot_data.py - builds BhuMilan's demo datasets for 5 cities across India.

    python tools/generate_pilot_data.py

For each city it first builds a *ground-truth scene* (true compound walls, buildings in each
survey year, trees, roads, utility lines, terrain heights). Every "department" dataset is then
derived from that scene, with realistic errors deliberately injected in a few parcels:

  cadastral map     boundary shifted / overlapping the neighbour
  Revenue records   regional script, own column names, acres/hectares/bigha, keyed by survey no.
  Municipal records English, own column names, sq.yd/sq.ft, keyed by map location (lat/lon)
  drone ORI         3 survey years (2019, 2022, 2025) - new buildings appear in later years
  DSM / DTM         1 m height grids per parcel
  GNSS points       corner points from a DGPS/RTK survey for some parcels
  utility lines     water mains / power corridors with easement widths

ALL OWNER NAMES AND RECORDS ARE FICTIONAL. Imagery is synthetic and labelled as such.
"""

import csv
import json
import zlib
import math
import random
import shutil
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from engine.geo import from_local_m, to_local_m, area_m2, utm_epsg  # noqa: E402

DATA = ROOT / "data" / "locations"
YEARS = [2019, 2022, 2025]
IMG_W, IMG_H = 768, 512
MARGIN = 0.35
SQM = {"sq_m": 1.0, "sq_yd": 0.836127, "sq_ft": 0.092903, "acre": 4046.8564, "hectare": 10000.0,
       "bigha_assam": 1337.80}

# ---------------------------------------------------------------------------
# City definitions
# ---------------------------------------------------------------------------

CITIES = [
    dict(id="AP-VSK", city="Visakhapatnam", district="Visakhapatnam", state="Andhra Pradesh", state_code=28,
         ulb="Greater Visakhapatnam Municipal Corporation (GVMC)", base_elev=32.0, ground=(118, 146, 104),
         villages=["Madhurawada", "P.M. Palem", "Yendada", "Rushikonda"], legacy_vizag=True,
         revenue=dict(dept="Revenue Department (Webland)", unit="acre", script="Telugu",
                      cols=dict(khata_number="Khata_No", survey_number="Survey_No", village="Village",
                                owner_name="Pattadar_Name", father_name="Father_Husband_Name",
                                area="Extent_Acres", land_use="Land_Classification",
                                document_type="Document_Type", registration_date="Registration_Date")),
         municipal=dict(dept="GVMC Property Tax", unit="sq_yd",
                        cols=dict(assessment_number="Assessment_No", owner_name="Owner_Name",
                                  father_name="Guardian_Name", ward="Ward_No", lat="Latitude", lon="Longitude",
                                  built_up_area="Plinth_Area_SqYd", floors="No_of_Floors", usage="Usage_Type"))),
    dict(id="RJ-JPR", city="Jaipur", district="Jaipur", state="Rajasthan", state_code=8,
         ulb="Jaipur Greater Municipal Corporation", base_elev=431.0, ground=(186, 170, 136),
         origin=(26.85020, 75.76240), rows=3, cols=4, plot=(24.0, 18.0), road=10.0,
         villages=["Mansarovar", "Pratap Nagar", "Jagatpura"],
         revenue=dict(dept="Revenue Department (Apna Khata)", unit="hectare", script="Devanagari",
                      cols=dict(khata_number="खाता_संख्या", survey_number="खसरा_नंबर", village="गांव",
                                owner_name="खातेदार_का_नाम", father_name="पिता_का_नाम",
                                area="क्षेत्रफल_हेक्टेयर", land_use="भूमि_प्रकार",
                                document_type="दस्तावेज़", registration_date="पंजीकरण_तिथि")),
         municipal=dict(dept="JMC Urban Development Tax", unit="sq_ft",
                        cols=dict(assessment_number="PropertyID", owner_name="OwnerName", father_name="FatherName",
                                  ward="Zone", lat="Lat", lon="Lon", built_up_area="BuiltUpArea_SqFt",
                                  floors="Floors", usage="UseType")),
         people=[("सुरेश शर्मा", "Suresh Sharma", "रामेश्वर शर्मा", "Rameshwar Sharma"),
                 ("प्रिया अग्रवाल", "Priya Agarwal", "महेश अग्रवाल", "Mahesh Agarwal"),
                 ("अर्जुन सिंह राठौड़", "Arjun Singh", "भवानी सिंह", "Bhawani Singh"),
                 ("कविता जैन", "Kavita Jain", "विनोद जैन", "Vinod Jain"),
                 ("मोहन लाल गुप्ता", "Mohan Lal Gupta", "किशन लाल गुप्ता", "Kishan Lal Gupta"),
                 ("सुनीता मीणा", "Sunita Meena", "रामजी लाल मीणा", "Ramji Lal Meena"),
                 ("रमेश चौधरी", "Ramesh Chaudhary", "हनुमान चौधरी", "Hanuman Choudhary"),
                 ("अंजलि माथुर", "Anjali Mathur", "राजेंद्र माथुर", "Rajendra Mathur"),
                 ("विक्रम सिंह शेखावत", "Vikram Singh Shekhawat", "जसवंत सिंह", "Jaswant Singh"),
                 ("गीता कुमारी", "Geeta Kumari", "श्याम सुंदर", "Shyam Sundar"),
                 ("दिनेश यादव", "Dinesh Yadav", "बाबू लाल यादव", "Babu Lal Yadav"),
                 ("नीलम सैनी", "Neelam Saini", "ओम प्रकाश सैनी", "Om Prakash Saini")],
         cases={1: ["gnss_record"], 4: ["shift"], 6: ["mutation"], 8: ["new_building"], 10: ["utility"],
                3: ["extra_floor"]}),
    dict(id="MH-PNE", city="Pune", district="Pune", state="Maharashtra", state_code=27,
         ulb="Pune Municipal Corporation (PMC)", base_elev=561.0, ground=(146, 142, 108),
         origin=(18.59110, 73.73870), rows=3, cols=4, plot=(22.0, 20.0), road=9.0,
         villages=["Hinjewadi", "Wakad", "Baner"],
         revenue=dict(dept="Revenue Department (7/12 Mahabhumi)", unit="hectare", script="Devanagari",
                      cols=dict(khata_number="Khata_No", survey_number="Gat_No", village="Village",
                                owner_name="Occupant_Name", father_name="Father_Name", area="Area_Hectare",
                                land_use="Land_Use", document_type="Document", registration_date="Reg_Date")),
         municipal=dict(dept="PMC Property Tax", unit="sq_m",
                        cols=dict(assessment_number="Property_No", owner_name="Owner", father_name="Father_Name",
                                  ward="Ward", lat="Latitude", lon="Longitude", built_up_area="Carpet_Area_SqM",
                                  floors="Floors", usage="Usage")),
         people=[("संजय पाटील", "Sanjay Patil", "बाळासाहेब पाटील", "Balasaheb Patil"),
                 ("स्नेहा कुलकर्णी", "Sneha Kulkarni", "अनिल कुलकर्णी", "Anil Kulkarni"),
                 ("राहुल देशमुख", "Rahul Deshmukh", "विजय देशमुख", "Vijay Deshmukh"),
                 ("प्रिया जोशी", "Priya Joshi", "सुधीर जोशी", "Sudhir Joshi"),
                 ("अमोल पवार", "Amol Pawar", "शिवाजी पवार", "Shivaji Pawar"),
                 ("मीनाक्षी गायकवाड", "Meenakshi Gaikwad", "दत्तात्रय गायकवाड", "Dattatray Gaikwad"),
                 ("निखिल शिंदे", "Nikhil Shinde", "सुरेश शिंदे", "Suresh Shinde"),
                 ("वैशाली भोसले", "Vaishali Bhosale", "मारुती भोसले", "Maruti Bhosale"),
                 ("गणेश कदम", "Ganesh Kadam", "रामचंद्र कदम", "Ramchandra Kadam"),
                 ("अश्विनी जाधव", "Ashwini Jadhav", "प्रकाश जाधव", "Prakash Jadhav"),
                 ("सचिन मोरे", "Sachin More", "दिलीप मोरे", "Dilip More"),
                 ("पूजा साळुंखे", "Pooja Salunkhe", "अशोक साळुंखे", "Ashok Salunkhe")],
         cases={0: ["gnss_record"], 2: ["new_building"], 5: ["overlap_prev"], 7: ["extra_floor"],
                9: ["other_owner"], 10: ["shift", "gnss_truth"]}),
    dict(id="AS-GHY", city="Guwahati", district="Kamrup Metropolitan", state="Assam", state_code=18,
         ulb="Guwahati Municipal Corporation (GMC)", base_elev=56.0, ground=(92, 138, 82),
         origin=(26.11950, 91.79700), rows=3, cols=4, plot=(20.0, 18.0), road=9.0,
         villages=["Beltola", "Six Mile", "Hatigaon"],
         revenue=dict(dept="Revenue Department (Dharitree)", unit="bigha_assam", script="Bengali-Assamese",
                      cols=dict(khata_number="Patta_No", survey_number="Dag_No", village="Village",
                                owner_name="Pattadar", father_name="Father_Name", area="Area_Bigha",
                                land_use="Land_Class", document_type="Document", registration_date="Reg_Date")),
         municipal=dict(dept="GMC Holding Tax", unit="sq_ft",
                        cols=dict(assessment_number="Holding_No", owner_name="Owner_Name", father_name="Father_Name",
                                  ward="Ward", lat="Latitude", lon="Longitude", built_up_area="Plinth_Area_SqFt",
                                  floors="Floors", usage="Use")),
         people=[("দীপংকৰ কলিতা", "Dipankar Kalita", "ভবেন কলিতা", "Bhaben Kalita"),
                 ("প্ৰিয়ংকা বৰা", "Priyanka Bora", "নৃপেন বৰা", "Nripen Bora"),
                 ("ৰিতুৰাজ দাস", "Rituraj Das", "অমল দাস", "Amal Das"),
                 ("অনুপম শইকীয়া", "Anupam Saikia", "প্ৰফুল্ল শইকীয়া", "Prafulla Saikia"),
                 ("নবনীতা গগৈ", "Nabanita Gogoi", "দিলীপ গগৈ", "Dilip Gogoi"),
                 ("ভাস্কৰ ডেকা", "Bhaskar Deka", "হৰেন ডেকা", "Haren Deka"),
                 ("জোনালী হাজৰিকা", "Jonali Hazarika", "বিপিন হাজৰিকা", "Bipin Hazarika"),
                 ("প্ৰাঞ্জল বৰুৱা", "Pranjal Baruah", "গোপাল বৰুৱা", "Gopal Baruah"),
                 ("মৌচুমী চৌধুৰী", "Mousumi Choudhury", "অজিত চৌধুৰী", "Ajit Choudhury"),
                 ("ৰূপম নাথ", "R. Nath", "জিতেন নাথ", "Jiten Nath"),
                 ("কাকলী মেধি", "Kakoli Medhi", "অনিল মেধি", "Anil Medhi"),
                 ("হেমন্ত তালুকদাৰ", "Hemanta Talukdar", "গিৰিন তালুকদাৰ", "Girin Talukdar")],
         cases={2: ["shift"], 5: ["new_building"], 8: ["utility"], 11: ["extra_floor"]}),
    dict(id="OD-BBS", city="Bhubaneswar", district="Khordha", state="Odisha", state_code=21,
         ulb="Bhubaneswar Municipal Corporation (BMC)", base_elev=46.0, ground=(126, 140, 94),
         origin=(20.35270, 85.81880), rows=3, cols=4, plot=(22.0, 18.0), road=9.0,
         villages=["Patia", "Chandrasekharpur", "Nayapalli"],
         revenue=dict(dept="Revenue Department (Bhulekh)", unit="acre", script="Odia",
                      cols=dict(khata_number="Khata_No", survey_number="Plot_No", village="Mouza",
                                owner_name="Tenant_Name", father_name="Father_Name", area="Area_Acre",
                                land_use="Kisam", document_type="Document", registration_date="Reg_Date")),
         municipal=dict(dept="BMC Holding Tax", unit="sq_ft",
                        cols=dict(assessment_number="Holding_No", owner_name="Owner", father_name="Guardian",
                                  ward="Ward", lat="Lat", lon="Long", built_up_area="Builtup_SqFt",
                                  floors="Floors", usage="Usage")),
         people=[("ସୁଭାଷ ମହାନ୍ତି", "Subhash Mohanty", "ଗୋପୀନାଥ ମହାନ୍ତି", "Gopinath Mohanty"),
                 ("ପ୍ରିୟଙ୍କା ଦାଶ", "Priyanka Dash", "ବିପିନ ଦାଶ", "Bipin Dash"),
                 ("ରମେଶ ପଣ୍ଡା", "Ramesh Panda", "ହରିହର ପଣ୍ଡା", "Harihar Panda"),
                 ("ସସ୍ମିତା ସାହୁ", "Sasmita Sahu", "ଅକ୍ଷୟ ସାହୁ", "Akshay Sahu"),
                 ("ଅଜିତ ନାୟକ", "Ajit Nayak", "ପ୍ରଫୁଲ୍ଲ ନାୟକ", "Prafulla Nayak"),
                 ("ମମତା ବେହେରା", "Mamata Behera", "ସନାତନ ବେହେରା", "Sanatan Behera"),
                 ("ବିଜୟ ପାତ୍ର", "Bijay Patra", "ଶ୍ୟାମସୁନ୍ଦର ପାତ୍ର", "Shyamsundar Patra"),
                 ("ସୁନନ୍ଦା ମିଶ୍ର", "Sunanda Mishra", "ରବୀନ୍ଦ୍ର ମିଶ୍ର", "Rabindra Mishra"),
                 ("ପ୍ରଦୀପ ଜେନା", "Pradeep Jena", "କୃଷ୍ଣ ଜେନା", "Krushna Jena"),
                 ("ଲିପି ରାଉତ", "Lipi Rout", "ଭାସ୍କର ରାଉତ", "Bhaskar Rout"),
                 ("ଦେବାଶିଷ ସ୍ୱାଇଁ", "Debashis Swain", "ନିରଞ୍ଜନ ସ୍ୱାଇଁ", "Niranjan Swain"),
                 ("ଅନୁରାଧା ପରିଡ଼ା", "Anuradha Parida", "ସୁରେନ୍ଦ୍ର ପରିଡ଼ା", "Surendra Parida")],
         cases={1: ["overlap_prev"], 3: ["utility"], 5: ["gnss_record"], 6: ["mutation"], 9: ["extra_floor"],
                11: ["new_building"]}),
]

LAND_USES = ["Residential", "Commercial", "Mixed Use", "Residential", "Institutional", "Residential"]
DOCS = ["Sale Deed", "Patta", "Gift Deed", "Partition Deed", "Settlement Deed", "Will"]


# ---------------------------------------------------------------------------
# Scene construction (all geometry in local metres around the city origin)
# ---------------------------------------------------------------------------

def rect(x0, y0, w, h):
    return [(x0, y0), (x0 + w, y0), (x0 + w, y0 + h), (x0, y0 + h)]


def build_scene(c, rng):
    """Returns the ground truth for one city."""
    scene = {"parcels": [], "roads": [], "utilities": [], "trees": {y: [] for y in YEARS}}
    if c.get("legacy_vizag"):
        return build_vizag(c, rng, scene)
    rows, cols = c["rows"], c["cols"]
    pw, ph = c["plot"]
    road = c["road"]
    c["ref"] = c["origin"]
    for r in range(rows):
        for k in range(cols):
            i = r * cols + k
            x0 = road + k * (pw + road)
            y0 = road + r * (ph + road)
            cases = c["cases"].get(i, [])
            h = ph + (3.0 if "utility" in cases else 0.0)       # plot pushed into the utility corridor
            scene["parcels"].append({"idx": i, "row": r, "col": k, "wall": rect(x0, y0, pw, h), "cases": cases})
    W = road + cols * (pw + road)
    H = road + rows * (ph + road)
    scene["extent"] = (0, 0, W, H)
    for r in range(rows + 1):
        scene["roads"].append(rect(0, r * (ph + road), W, road))
    for k in range(cols + 1):
        scene["roads"].append(rect(k * (pw + road), 0, road, H))
    # utilities: water main along the first road, power corridor along the road above the "utility" row
    scene["utilities"].append({"id": "UTIL-WATER-01", "type": "Water main", "buffer_m": 3.0,
                               "name": f"{c['city']} 300 mm water main", "line": [(0, road / 2), (W, road / 2)]})
    urow = next((p["row"] for p in scene["parcels"] if "utility" in p["cases"]), rows - 1)
    yline = road + (urow + 1) * (ph + road) - road / 2
    scene["utilities"].append({"id": "UTIL-POWER-02", "type": "Power corridor", "buffer_m": 4.0,
                               "name": f"{c['city']} 33 kV underground power corridor", "line": [(0, yline), (W, yline)]})
    add_buildings_and_trees(c, rng, scene)
    return scene


def build_vizag(c, rng, scene):
    """Visakhapatnam keeps the original prototype's 24 parcels and owners."""
    legacy = json.loads((ROOT / "tools" / "legacy_vizag.json").read_text(encoding="utf-8"))
    lats = [pt[1] for f in legacy["features"] for pt in f["geometry"]["coordinates"][0]]
    lons = [pt[0] for f in legacy["features"] for pt in f["geometry"]["coordinates"][0]]
    c["ref"] = (min(lats) - 0.00012, min(lons) - 0.00012)
    c["cases"] = {13: ["shift", "gnss_truth"], 16: ["utility"], 10: ["overlap_prev"], 22: ["mutation"],
                  4: ["extra_floor"], 18: ["new_building"], 7: ["gnss_record"], 2: ["script_revenue"],
                  17: ["script_revenue"], 6: ["initials"], 20: ["middle_name"]}
    for i, f in enumerate(legacy["features"]):
        ring = f["geometry"]["coordinates"][0][:-1]
        wall = to_local_m([(lat, lon) for lon, lat in ring], c["ref"])
        scene["parcels"].append({"idx": i, "row": i // 6, "col": i % 6, "wall": wall,
                                 "cases": c["cases"].get(i, []), "legacy": f["properties"]})
    xs = [x for p in scene["parcels"] for x, _ in p["wall"]]
    ys = [y for p in scene["parcels"] for _, y in p["wall"]]
    W, H = max(xs) + 14, max(ys) + 14
    scene["extent"] = (0, 0, W, H)
    for r in range(5):   # horizontal roads between the 4 rows
        row_walls = [p["wall"] for p in scene["parcels"] if p["row"] == r]
        prev_top = max(y for p in scene["parcels"] if p["row"] == r - 1 for _, y in p["wall"]) if r else 0
        next_bottom = min(y for w in row_walls for _, y in w) if row_walls else H
        scene["roads"].append(rect(0, prev_top + 2, W, max(4, next_bottom - prev_top - 4)))
    for k in range(7):
        col_walls = [p["wall"] for p in scene["parcels"] if p["col"] == k]
        prev_r = max(x for p in scene["parcels"] if p["col"] == k - 1 for x, _ in p["wall"]) if k else 0
        next_l = min(x for w in col_walls for x, _ in w) if col_walls else W
        scene["roads"].append(rect(prev_r + 2, 0, max(4, next_l - prev_r - 4), H))

    def lat_to_y(lat):
        return to_local_m([(lat, c["ref"][1])], c["ref"])[0][1]
    scene["utilities"].append({"id": "UTIL-WATER-01", "type": "Water main", "buffer_m": 3.0,
                               "name": "Madhurawada 450 mm water trunk line",
                               "line": [(0, lat_to_y(17.80545)), (W, lat_to_y(17.80545))]})
    scene["utilities"].append({"id": "UTIL-POWER-02", "type": "Power corridor", "buffer_m": 4.0,
                               "name": "APEPDCL 33 kV underground power corridor",
                               "line": [(0, lat_to_y(17.8074)), (W, lat_to_y(17.8074))]})
    add_buildings_and_trees(c, rng, scene)
    return scene


def add_buildings_and_trees(c, rng, scene):
    for p in scene["parcels"]:
        xs = [x for x, _ in p["wall"]]
        ys = [y for _, y in p["wall"]]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        w, h = x1 - x0, y1 - y0
        bw = min(w - 6, rng.uniform(0.45, 0.6) * w)
        bh = min(h - 6, rng.uniform(0.45, 0.6) * h)
        bx = x0 + rng.uniform(2.5, max(2.6, w - bw - 2.5))
        by = y0 + rng.uniform(2.5, max(2.6, h - bh - 2.5))
        floors = rng.choice([1, 2, 2, 3, 3, 4]) if w < 40 else rng.choice([2, 3, 4])
        roof = rng.choice(["concrete", "concrete", "concrete", "terracotta"])
        if "extra_floor" in p["cases"]:
            floors = max(2, floors)          # the record will show one floor fewer
        main = {"poly": rect(bx, by, bw, bh), "floors": floors, "roof": roof, "years": YEARS}
        p["buildings"] = [main]
        if "new_building" in p["cases"]:
            # a new structure in the free corner of the yard, built after the 2022 survey
            nw, nh = min(9.0, w * 0.28), min(7.0, h * 0.28)
            cand = [(x0 + 1.5, y0 + 1.5), (x1 - nw - 1.5, y0 + 1.5), (x0 + 1.5, y1 - nh - 1.5), (x1 - nw - 1.5, y1 - nh - 1.5)]
            def free(pt):
                a = rect(pt[0], pt[1], nw, nh)
                return not (a[0][0] < bx + bw + 1 and a[1][0] > bx - 1 and a[0][1] < by + bh + 1 and a[2][1] > by - 1)
            spot = next((pt for pt in cand if free(pt)), cand[0])
            p["buildings"].append({"poly": rect(spot[0], spot[1], nw, nh), "floors": 1, "roof": "concrete",
                                   "years": [2025]})
    ex = scene["extent"]
    n_trees = int((ex[2] * ex[3]) / 160)
    base = []
    for _ in range(n_trees):
        base.append((rng.uniform(ex[0], ex[2]), rng.uniform(ex[1], ex[3]), rng.uniform(1.4, 3.4), rng.uniform(4, 9)))
    for y in YEARS:
        keep = [t for t in base if rng.random() > 0.08]
        extra = [(rng.uniform(ex[0], ex[2]), rng.uniform(ex[1], ex[3]), rng.uniform(1.2, 2.6), rng.uniform(3, 7))
                 for _ in range(n_trees // 12)]
        scene["trees"][y] = keep + extra


def in_any_building(x, y, parcels, year, pad=0.8):
    for p in parcels:
        for b in p["buildings"]:
            if year in b["years"]:
                xs = [q[0] for q in b["poly"]]
                ys = [q[1] for q in b["poly"]]
                if min(xs) - pad <= x <= max(xs) + pad and min(ys) - pad <= y <= max(ys) + pad:
                    return True
    return False


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def window_for(polys, aspect=IMG_W / IMG_H):
    xs = [x for poly in polys for x, _ in poly]
    ys = [y for poly in polys for _, y in poly]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    w, h = (x1 - x0) * (1 + 2 * MARGIN), (y1 - y0) * (1 + 2 * MARGIN)
    if w / h < aspect:
        w = h * aspect
    else:
        h = w / aspect
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def render(c, scene, win, year, rng, label):
    x0, y0, x1, y1 = win
    sx, sy = IMG_W / (x1 - x0), IMG_H / (y1 - y0)

    def P(poly):
        return np.array([[int(round((x - x0) * sx)), int(round((y1 - y) * sy))] for x, y in poly], np.int32)

    base = np.array(c["ground"][::-1], np.float32)          # BGR
    noise = cv2.GaussianBlur(rng.standard_normal((IMG_H, IMG_W)).astype(np.float32), (0, 0), 6) * 38
    fine = rng.standard_normal((IMG_H, IMG_W)).astype(np.float32) * 5
    img = np.clip(base[None, None, :] + (noise + fine)[..., None] * np.array([0.8, 1.0, 0.7])[None, None, :], 0, 255)
    img = img.astype(np.uint8)
    for rd in scene["roads"]:
        cv2.fillPoly(img, [P(rd)], (138, 142, 146), cv2.LINE_AA)
    for p in scene["parcels"]:                                  # yards are slightly lighter bare soil
        yard = img.copy()
        cv2.fillPoly(yard, [P(p["wall"])], (int(base[0] + 14), int(base[1] + 12), int(base[2] + 16)), cv2.LINE_AA)
        img = cv2.addWeighted(yard, 0.55, img, 0.45, 0)
    # trees (shadow first)
    trees = [t for t in scene["trees"][year] if x0 - 5 <= t[0] <= x1 + 5 and y0 - 5 <= t[1] <= y1 + 5]
    for tx, ty, tr, th in trees:
        if in_any_building(tx, ty, scene["parcels"], year, pad=tr + 0.5):
            continue
        cx, cy = int((tx - x0) * sx), int((y1 - ty) * sy)
        cv2.circle(img, (cx + int(0.35 * th * sx / 3), cy + int(0.35 * th * sy / 3)), int(tr * sx), (40, 60, 45), -1, cv2.LINE_AA)
        g = int(rng.uniform(85, 120))
        cv2.circle(img, (cx, cy), int(tr * sx), (38, g, 52), -1, cv2.LINE_AA)
        cv2.circle(img, (cx - int(tr * sx * 0.3), cy - int(tr * sx * 0.3)), max(1, int(tr * sx * 0.45)), (48, g + 22, 64), -1, cv2.LINE_AA)
    # buildings: shadow, roof, roof edge
    for p in scene["parcels"]:
        for b in p["buildings"]:
            if year not in b["years"]:
                continue
            hgt = b["floors"] * 3.1 + 0.8
            off = hgt * 0.22
            shadow = [(x + off, y - off) for x, y in b["poly"]]
            cv2.fillPoly(img, [P(shadow)], (52, 58, 62), cv2.LINE_AA)
            col = (196, 200, 204) if b["roof"] == "concrete" else (84, 112, 176)
            jitter = rng.uniform(-8, 8)
            col = tuple(int(np.clip(v + jitter, 0, 255)) for v in col)
            cv2.fillPoly(img, [P(b["poly"])], col, cv2.LINE_AA)
            cv2.polylines(img, [P(b["poly"])], True, tuple(min(255, v + 25) for v in col), 2, cv2.LINE_AA)
    # compound walls
    wall_px = max(2, int(round(0.35 * sx)))
    for p in scene["parcels"]:
        cv2.polylines(img, [P(p["wall"])], True, (58, 64, 72), wall_px, cv2.LINE_AA)
    # lighting differs between survey years
    gain = {2019: 0.94, 2022: 1.0, 2025: 1.05}[year]
    img = np.clip(img.astype(np.float32) * gain + rng.uniform(-4, 4), 0, 255).astype(np.uint8)
    cv2.rectangle(img, (0, 0), (430, 22), (25, 25, 25), -1)
    cv2.putText(img, label, (8, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (235, 235, 235), 1, cv2.LINE_AA)
    cv2.putText(img, "SYNTHETIC IMAGERY - FOR DEMO, NOT LEGAL CADASTRAL DATA", (8, IMG_H - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (245, 245, 245), 1, cv2.LINE_AA)
    return img


def surface(c, scene, win, rng, res=1.0):
    """DTM (bare ground) and DSM (ground + buildings + trees) at 1 m for the image window."""
    x0, y0, x1, y1 = win
    nx, ny = int((x1 - x0) / res), int((y1 - y0) / res)
    gx = x0 + (np.arange(nx) + 0.5) * res
    gy = y1 - (np.arange(ny) + 0.5) * res
    X, Y = np.meshgrid(gx, gy)
    dtm = c["base_elev"] + 0.012 * X - 0.008 * Y + cv2.GaussianBlur(
        rng.standard_normal((ny, nx)).astype(np.float32), (0, 0), 5) * 0.25
    dsm = dtm.copy()
    for tx, ty, tr, th in scene["trees"][2025]:
        if not (x0 - 5 <= tx <= x1 + 5 and y0 - 5 <= ty <= y1 + 5) or in_any_building(tx, ty, scene["parcels"], 2025, tr + 0.5):
            continue
        m = (X - tx) ** 2 + (Y - ty) ** 2 <= tr ** 2
        dsm = np.where(m, np.maximum(dsm, dtm + th), dsm)
    for p in scene["parcels"]:
        for b in p["buildings"]:
            if 2025 not in b["years"]:
                continue
            xs = [q[0] for q in b["poly"]]
            ys = [q[1] for q in b["poly"]]
            m = (X >= min(xs)) & (X <= max(xs)) & (Y >= min(ys)) & (Y <= max(ys))
            dsm = np.where(m, dtm + b["floors"] * 3.1 + 0.8, dsm)
    dsm = dsm + rng.standard_normal(dsm.shape).astype(np.float32) * 0.15
    return dtm.astype(np.float32), dsm.astype(np.float32)


# ---------------------------------------------------------------------------
# Department records
# ---------------------------------------------------------------------------

def vizag_people():
    rev = {r["parcel_id"]: r for r in csv.DictReader(open(ROOT / "tools" / "legacy_vizag_revenue.csv", encoding="utf-8"))}
    telugu = {"AP-VSK-003": ("అర్జున్ రావు", "కృష్ణ రావు"), "AP-VSK-018": ("కీర్తి రావు", "మాధవ రావు"),
              "AP-VSK-011": ("శ్రీనివాస రావు", "అప్పల రావు")}
    out = []
    for pid in sorted(rev):
        r = rev[pid]
        native = telugu.get(pid, (r["owner_name"], r["father_name"]))
        out.append((native[0], r["owner_name"], native[1], r["father_name"], r))
    return out


def survey_no(c, i, rng):
    if c["id"] == "AP-VSK":
        return None
    if c["id"] == "RJ-JPR":
        return str(1120 + i * 3)
    if c["id"] == "MH-PNE":
        return f"{241 + i // 3}/{i % 3 + 1}"
    if c["id"] == "AS-GHY":
        return str(612 + i * 2)
    return f"{830 + i}"


def generate_city(c):
    seed = zlib.crc32(c["id"].encode())          # stable seed -> identical data on every run
    rng_py = random.Random(seed)
    rng = np.random.default_rng(seed)
    scene = build_scene(c, rng_py)
    ref = c["ref"]
    out = DATA / c["id"]
    if out.exists():
        shutil.rmtree(out)
    (out / "imagery").mkdir(parents=True)
    (out / "surface").mkdir()

    if c.get("legacy_vizag"):
        people = vizag_people()
    else:
        people = [(p[0], p[1], p[2], p[3], None) for p in c["people"]]

    cad_features, rev_rows, mun_rows, gnss_rows = [], [], [], []
    truth = {"note": "Ground truth for measuring BhuMilan's accuracy only - the pipeline never reads this file.",
             "parcels": {}}
    for p in scene["parcels"]:
        i = p["idx"]
        cases = p["cases"]
        pid = f"{c['id']}-{i + 1:03d}"
        wall = p["wall"]
        record = list(wall)
        if "shift" in cases:
            d = -8.1 if c["id"] == "AP-VSK" else 6.5
            record = [(x + d, y + (1.2 if c["id"] != "AP-VSK" else 0)) for x, y in wall]
        if "overlap_prev" in cases:
            prev = scene["parcels"][i - 1]["wall"]
            prev_right = max(x for x, _ in prev)
            xmin = min(x for x, _ in wall)
            record = [((prev_right - 5.5) if abs(x - xmin) < 1e-6 else x, y) for x, y in wall]
        rec_ll = from_local_m(record, ref)
        wall_ll = from_local_m(wall, ref)
        truth["parcels"][pid] = {
            "wall": wall_ll, "cases": cases,
            "buildings": [{"polygon": from_local_m(b["poly"], ref), "floors": b["floors"], "years": b["years"]}
                          for b in p["buildings"]]}
        native, eng, fnative, feng, legacy = people[i]
        village = (legacy["village"] if legacy else c["villages"][p["row"] % len(c["villages"])])
        sno = legacy["survey_number"] if legacy else survey_no(c, i, rng_py)
        land_use = legacy["land_type"] if legacy else rng_py.choice(LAND_USES)
        cad_features.append({"type": "Feature", "properties": {
            "parcel_id": pid, "survey_number": sno, "village": village, "source": "Cadastral map (digitised)",
            "demo_case": ", ".join(cases) or None},
            "geometry": {"type": "Polygon", "coordinates": [[[lon, lat] for lat, lon in rec_ll] + [[rec_ll[0][1], rec_ll[0][0]]]]}})

        # --- Revenue record (regional script, keyed by survey number, area in state unit)
        rv = c["revenue"]
        area_rec = area_m2(rec_ll) / SQM[rv["unit"]]
        rev_owner, rev_father = native, fnative
        if c["id"] == "AP-VSK":
            rev_owner, rev_father = (native, fnative) if "script_revenue" in cases else (legacy["owner_name"], legacy["father_name"])
        rev_rows.append({
            rv["cols"]["khata_number"]: str(1000 + i * 7), rv["cols"]["survey_number"]: sno,
            rv["cols"]["village"]: village, rv["cols"]["owner_name"]: rev_owner, rv["cols"]["father_name"]: rev_father,
            rv["cols"]["area"]: f"{area_rec:.4f}" if rv["unit"] in ("acre", "hectare") else f"{area_rec:.2f}",
            rv["cols"]["land_use"]: land_use,
            rv["cols"]["document_type"]: legacy["document_type"] if legacy else rng_py.choice(DOCS),
            rv["cols"]["registration_date"]: legacy["registration_date"] if legacy else
            f"{rng_py.randint(2008, 2023)}-{rng_py.randint(1, 12):02d}-{rng_py.randint(1, 28):02d}"})

        # --- Municipal record (English, keyed by geocoded location)
        mu = c["municipal"]
        existing = [b for b in p["buildings"] if 2022 in b["years"]]
        footprint = sum(area_m2(from_local_m(b["poly"], ref)) for b in existing)
        floors = max(b["floors"] for b in existing)
        rec_floors = floors - 1 if "extra_floor" in cases else floors
        built_up = footprint / SQM[mu["unit"]]
        m_owner, m_father = eng, feng
        if c["id"] == "AP-VSK":
            m_owner = {"AP-VSK-007": "Ravi Kumar", "AP-VSK-021": "Naveen Kumar Reddy"}.get(pid, legacy["owner_name"])
            m_father = legacy["father_name"]
        if "mutation" in cases:                          # property still in the father's name
            m_owner, m_father = feng, "—"
        if "other_owner" in cases:
            m_owner, m_father = "Rohan Kale", "Vasant Kale"
        cx = sum(x for x, _ in wall) / 4 + rng_py.uniform(-2, 2)
        cy = sum(y for _, y in wall) / 4 + rng_py.uniform(-2, 2)
        (clat, clon), = from_local_m([(cx, cy)], ref)
        mun_rows.append({
            mu["cols"]["assessment_number"]: f"{c['id'][-3:]}/{p['row'] + 1:02d}/{4100 + i * 13}",
            mu["cols"]["owner_name"]: m_owner, mu["cols"]["father_name"]: m_father,
            mu["cols"]["ward"]: f"Ward {p['row'] + 3}", mu["cols"]["lat"]: f"{clat:.7f}", mu["cols"]["lon"]: f"{clon:.7f}",
            mu["cols"]["built_up_area"]: f"{built_up:.1f}", mu["cols"]["floors"]: str(rec_floors),
            mu["cols"]["usage"]: land_use})

        # --- GNSS survey points
        if "gnss_truth" in cases or "gnss_record" in cases:
            for k, (lat, lon) in enumerate(wall_ll):
                (dlat, dlon), = from_local_m([(rng_py.gauss(0, 0.04), rng_py.gauss(0, 0.04))], (0.0, 0.0))
                gnss_rows.append({"point_id": f"{pid}-C{k + 1}", "parcel_id_hint": pid, "corner": k + 1,
                                  "latitude": f"{lat + dlat:.8f}", "longitude": f"{lon + dlon:.8f}",
                                  "horizontal_accuracy_m": "0.05", "method": "DGNSS (CORS network)",
                                  "surveyor": "Field team", "survey_date": "2025-02-10"})

        # --- Imagery (3 survey years) + DSM/DTM
        win = window_for([wall, record])
        wx0, wy0, wx1, wy1 = win
        (s_lat, w_lon), (n_lat, e_lon) = from_local_m([(wx0, wy0), (wx1, wy1)], ref)
        pdir = out / "imagery" / pid
        pdir.mkdir()
        meta = {"parcel_id": pid, "bounds": [w_lon, s_lat, e_lon, n_lat], "crs": "EPSG:4326",
                "width": IMG_W, "height": IMG_H, "gsd_m": round((wx1 - wx0) / IMG_W, 3), "surveys": []}
        for y in YEARS:
            img = render(c, scene, win, y, rng, f"{pid} | ORI {y} | {c['city']}")
            cv2.imwrite(str(pdir / f"ori_{y}.jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 90])
            meta["surveys"].append({"year": y, "file": f"ori_{y}.jpg", "type": "Drone ORI (synthetic)",
                                    "captured": f"{y}-01-15"})
        (pdir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        dtm, dsm = surface(c, scene, win, rng)
        np.savez_compressed(out / "surface" / f"{pid}.npz", dtm=dtm, dsm=dsm,
                            bounds=np.array([w_lon, s_lat, e_lon, n_lat]), resolution_m=np.array(1.0))

    (out / "ground_truth.eval.json").write_text(json.dumps(truth), encoding="utf-8")

    # --- write department files
    (out / "cadastral.geojson").write_text(json.dumps({
        "type": "FeatureCollection", "name": f"{c['city']} cadastral map",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
        "features": cad_features}, ensure_ascii=False, indent=1), encoding="utf-8")
    for name, rows in (("revenue.csv", rev_rows), ("municipal.csv", mun_rows)):
        with open(out / name, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    if gnss_rows:
        with open(out / "gnss_points.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(gnss_rows[0].keys()))
            w.writeheader()
            w.writerows(gnss_rows)
    util_features = []
    for u in scene["utilities"]:
        ll = from_local_m(u["line"], ref)
        util_features.append({"type": "Feature", "properties": {k: u[k] for k in ("id", "name", "type", "buffer_m")},
                              "geometry": {"type": "LineString", "coordinates": [[lon, lat] for lat, lon in ll]}})
    (out / "utilities.geojson").write_text(json.dumps({"type": "FeatureCollection", "features": util_features},
                                                      indent=1), encoding="utf-8")

    # --- manifest: what each file is and how its columns map to BhuMilan's standard schema
    lat_c, lon_c = from_local_m([(scene["extent"][2] / 2, scene["extent"][3] / 2)], ref)[0]
    manifest = {
        "id": c["id"], "city": c["city"], "district": c["district"], "state": c["state"],
        "state_code_lgd": c["state_code"], "urban_local_body": c["ulb"], "center": [lat_c, lon_c],
        "utm_epsg": utm_epsg(lat_c, lon_c), "synthetic": True,
        "datasets": [
            {"type": "cadastral", "file": "cadastral.geojson", "source": "Survey & Settlement - digitised cadastral map",
             "format": "GeoJSON", "crs": "EPSG:4326"},
            {"type": "revenue", "file": "revenue.csv", "source": c["revenue"]["dept"], "format": "CSV",
             "script": c["revenue"]["script"], "area_unit": c["revenue"]["unit"],
             "mapping": {v: k for k, v in c["revenue"]["cols"].items()}},
            {"type": "municipal", "file": "municipal.csv", "source": c["municipal"]["dept"], "format": "CSV",
             "area_unit": c["municipal"]["unit"], "mapping": {v: k for k, v in c["municipal"]["cols"].items()}},
            {"type": "utilities", "file": "utilities.geojson", "source": "Utility departments", "format": "GeoJSON"},
            {"type": "imagery", "folder": "imagery", "source": "Drone ORI surveys 2019 / 2022 / 2025 (synthetic)"},
            {"type": "surface", "folder": "surface", "source": "DSM / DTM from drone photogrammetry (synthetic)"},
        ] + ([{"type": "gnss", "file": "gnss_points.csv", "source": "DGNSS / CORS field survey", "format": "CSV",
               "crs": "EPSG:4326"}] if gnss_rows else []),
    }
    for d in manifest["datasets"]:
        d.update({"uploaded_by": "BhuMilan pilot data generator", "version": 1})
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{c['id']:7} {c['city']:14} {len(scene['parcels']):3} parcels  cases: "
          + ", ".join(f"{i + 1:03d}:{'+'.join(v)}" for i, v in sorted(c["cases"].items())))


def main():
    DATA.mkdir(parents=True, exist_ok=True)
    for c in CITIES:
        generate_city(c)
    (ROOT / "data" / "locations.json").write_text(json.dumps(
        [{"id": c["id"], "city": c["city"], "district": c["district"], "state": c["state"],
          "state_code_lgd": c["state_code"]} for c in CITIES], ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
