@echo off
title BhuMilan - SIH26013
cd /d "%~dp0"
echo =========================================================================
echo   BhuMilan - AI land record harmonization for India (SIH26013, DoLR)
echo =========================================================================
python --version >nul 2>&1
if errorlevel 1 (
    echo Python was not found. Install Python 3.11 or 3.12 from python.org and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
python -c "import fastapi, uvicorn, cv2, numpy" 2>nul
if errorlevel 1 (
    echo [+] First run: installing Python packages from requirements.txt ...
    python -m pip install -r requirements.txt
    echo.
)
python run_bhumilan.py
pause
