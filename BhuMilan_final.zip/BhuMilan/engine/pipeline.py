"""
engine/pipeline.py - harmonizes every parcel of a location across all data sources.

For each parcel on the cadastral map:
  1. LINK      revenue record (survey number), municipal record (map location), GNSS points (nearest corner)
  2. CHECK     drone boundary vs record, overlaps, validity, utility easements, owner names (ML, any script),
               inheritance not transferred, new construction, extra floors, built-up area
  3. RESOLVE   source-trust rules decide which source is right and produce a recommended action
  4. SCORE     0-100 confidence with plain-language reasons; >= 85 and no safety issue = auto-approved
Officer decisions are applied on top (corrected boundary, standardised owner, updated building record),
so the harmonized output is always the latest agreed version.
"""

import json
import math
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import cv2

from engine import geo, names, store, vision

AUTO_APPROVE = 85
REVIEW = 60
TRUST_ORDER = {
    "boundary": ["GNSS / CORS field survey (+/- 5 cm)", "Drone ORI (+/- 30 cm)", "Digitised cadastral map (+/- 2-5 m)"],
    "ownership": ["Revenue record of rights (legal)", "Municipal tax record"],
    "building": ["DSM / ORI measurement (current)", "Municipal record (self-declared)"],
}
CACHE_DIR = store.DATA / "cache"
_cache: Dict[str, Any] = {}
_lock = threading.RLock()


def _norm_sno(s: str) -> str:
    return re.sub(r"[^0-9A-Z]", "", str(s or "").upper())


# ---------------------------------------------------------------------------
# Vision per parcel (cached on disk - depends only on the images)
# ---------------------------------------------------------------------------

def parcel_vision(loc: str, pid: str) -> Optional[Dict[str, Any]]:
    folder = store.LOCS / loc / "imagery" / pid
    meta = vision.load_meta(folder)
    if not meta or not meta.get("surveys"):
        return None
    surveys = sorted(meta["surveys"], key=lambda s: s["year"])
    files = [folder / s["file"] for s in surveys]
    sig = "|".join(f"{f.name}:{f.stat().st_mtime_ns}" for f in files if f.exists())
    cfile = CACHE_DIR / "vision" / loc / f"{pid}.json"
    if cfile.exists():
        c = json.loads(cfile.read_text(encoding="utf-8"))
        if c.get("sig") == sig and c.get("v") == 3:
            return c
    latest = cv2.imread(str(files[-1]))
    oldest = cv2.imread(str(files[0])) if len(files) > 1 else None
    rings = vision.extract_boundaries(latest, meta)
    blds = vision.extract_buildings(latest, meta)
    change = vision.detect_changes_px(oldest, latest, meta) if oldest is not None else {"new": [], "demolished": []}
    heights = vision.building_heights(store.LOCS / loc / "surface" / f"{pid}.npz",
                                      [b for b in blds if b["shape"] == "rectangle"])
    out = {"v": 3, "sig": sig, "meta": meta, "rings": rings, "buildings": blds, "heights": heights,
           "change": {"new": change["new"], "demolished": change["demolished"],
                      "from": surveys[0]["year"], "to": surveys[-1]["year"]}}
    cfile.parent.mkdir(parents=True, exist_ok=True)
    cfile.write_text(json.dumps(out), encoding="utf-8")
    return out


# ---------------------------------------------------------------------------
# Harmonization
# ---------------------------------------------------------------------------

def harmonize(loc: str) -> Dict[str, Any]:
    sig = store.signature(loc)
    with _lock:
        hit = _cache.get(loc)
        if hit and hit["sig"] == sig:
            return hit["result"]
    t0 = time.perf_counter()
    data = store.load_location(loc)
    decisions = store.load_decisions(loc)
    m = data["manifest"]

    # current records = cadastral map + officer-approved corrections
    parcels = []
    for c in data["cadastral"]:
        d = decisions.get(c["parcel_id"], {})
        poly = [tuple(p) for p in d["corrected_polygon"]] if d.get("corrected_polygon") else c["polygon"]
        parcels.append({**c, "original_polygon": c["polygon"], "polygon": poly})

    rev_by_sno: Dict[str, List[Dict]] = {}
    for r in data["revenue"]:
        rev_by_sno.setdefault(_norm_sno(r.get("survey_number")), []).append(r)
    linked_rev, linked_mun = set(), set()

    # municipal records -> parcel containing the point (or nearest within 6 m)
    mun_for: Dict[str, Dict] = {}
    for j, r in enumerate(data["municipal"]):
        try:
            pt = (float(r["lat"]), float(r["lon"]))
        except (KeyError, TypeError, ValueError):
            continue
        best, best_d = None, 1e9
        for p in parcels:
            if vision.inside(pt, p["polygon"]):
                best, best_d = p, 0.0
                break
            cen = geo.centroid_latlon(p["polygon"])
            dd = geo.mean_corner_offset_m([pt], [cen])
            if dd < best_d:
                best, best_d = p, dd
        if best is not None and (best_d == 0.0 or best_d < 6 + (geo.area_m2(best["polygon"]) ** 0.5) / 2):
            if best["parcel_id"] not in mun_for:
                mun_for[best["parcel_id"]] = {**r, "_link": "inside parcel" if best_d == 0 else f"{best_d:.0f} m from centre"}
                linked_mun.add(j)

    # GNSS points -> parcel with the nearest corner (record or drone) within 10 m
    gnss_for: Dict[str, List] = {}
    for g in data["gnss"]:
        pt = (g["lat"], g["lon"])
        best, best_d = None, 10.0
        for p in parcels:
            for corner in p["polygon"]:
                dd = geo.mean_corner_offset_m([pt], [corner])
                if dd < best_d:
                    best, best_d = p, dd
        if best:
            gnss_for.setdefault(best["parcel_id"], []).append(g)

    results = []
    for p in parcels:
        results.append(_check_parcel(loc, p, parcels, data, rev_by_sno, linked_rev, mun_for.get(p["parcel_id"]),
                                     gnss_for.get(p["parcel_id"], []), decisions.get(p["parcel_id"]), m))
    # correction proposals for overlaps: fix the parcel whose record disagrees with its drone boundary
    for r in results:
        for ov in r["checks"]["topology"]["overlaps"]:
            other = next(x for x in results if x["parcel_id"] == ov["with"])
            ov["cause"] = ("this parcel's record" if r["checks"]["boundary"]["offset_m"] >= other["checks"]["boundary"]["offset_m"]
                           else f"{ov['with']}'s record")

    unlinked_rev = [r for sno, rows in rev_by_sno.items() for r in rows if id(r) not in linked_rev]
    unlinked_mun = [r for j, r in enumerate(data["municipal"]) if j not in linked_mun]
    elapsed = time.perf_counter() - t0
    summary = _summary(results)
    summary.update({"elapsed_seconds": round(elapsed, 2), "unlinked_revenue": len(unlinked_rev),
                    "unlinked_municipal": len(unlinked_mun)})
    result = {
        "location": {k: m.get(k) for k in ("id", "city", "district", "state", "state_code_lgd", "urban_local_body",
                                            "center", "utm_epsg", "synthetic")},
        "datasets": m["datasets"], "summary": summary, "parcels": results,
        "utilities": [{"id": u["id"], "name": u["name"], "type": u["type"], "buffer_m": u["buffer_m"],
                       "line": u["line"]} for u in data["utilities"]],
        "gnss_points": [{"point_id": g["point_id"], "lat": g["lat"], "lon": g["lon"]} for g in data["gnss"]],
        "unlinked": {"revenue": unlinked_rev[:50], "municipal": unlinked_mun[:50]},
        "trust_order": TRUST_ORDER, "generated_at": datetime.now().isoformat(timespec="seconds"),
    }
    with _lock:
        _cache[loc] = {"sig": sig, "result": result}
    return result


def _check_parcel(loc, p, parcels, data, rev_by_sno, linked_rev, mun, gnss, decision, m) -> Dict[str, Any]:
    pid = p["parcel_id"]
    rec = p["polygon"]
    area = geo.area_m2(rec)
    issues, recs, reasons, penalty = [], [], [], {}
    decision = decision or {}
    resolved = set(decision.get("resolved", []))

    # ---------------- 1. linking
    rev_rows = rev_by_sno.get(_norm_sno(p["survey_number"]), [])
    rev = None
    if rev_rows:
        rev = rev_rows[0] if len(rev_rows) == 1 else next(
            (r for r in rev_rows if (r.get("village") or "").lower() == (p["village"] or "").lower()), rev_rows[0])
        linked_rev.add(id(rev))

    # ---------------- 2a. drone boundary
    vis = parcel_vision(loc, pid)
    det, iou_rec, ratio, offset = None, 0.0, None, 0.0
    boundary_state = "no imagery"
    if vis:
        det, iou_rec = vision.match_boundary(rec, [[tuple(q) for q in r] for r in vis["rings"]])
        if det:
            ratio = geo.area_m2(det) / max(area, 1e-6)
            inside_share = geo.overlap_m2(det, rec) / max(geo.area_m2(det), 1e-6)
            overlaps_neighbour = any(
                geo.overlap_m2(rec, o["polygon"]) > 1.0 for o in parcels
                if o["parcel_id"] != pid and abs(o["polygon"][0][0] - rec[0][0]) < 0.01)
            skew = geo.max_edge_angle_deviation(rec, det)
            if skew > 7.0:
                boundary_state = "partly hidden"            # one side bridged across trees / shadow
                det = None
            elif (0.85 <= ratio <= 1.18 and iou_rec > 0.25) or (overlaps_neighbour and inside_share > 0.9 and ratio > 0.4):
                offset = round(geo.mean_corner_offset_m(rec, det), 1)
                boundary_state = "matches" if offset <= 2.0 else "shifted"
            else:
                boundary_state = "unclear"
                det = None
        else:
            boundary_state = "unclear"

    # ---------------- 2b. GNSS ground truth
    g_rec = g_det = None
    gnss_poly = None
    if len(gnss) >= 3:
        pts = [(g["lat"], g["lon"]) for g in gnss]
        g_rec = round(geo.mean_corner_offset_m(pts, rec), 2)
        g_det = round(geo.mean_corner_offset_m(pts, det), 2) if det else None
        cen = geo.centroid_latlon(pts)
        gnss_poly = sorted(pts, key=lambda q: math.atan2(q[0] - cen[0], q[1] - cen[1]))

    geometry_verdict = None
    if g_rec is not None and g_rec > 2.0:
        # GNSS outranks everything: the record is wrong where the surveyor measured it
        both = det is not None and g_det is not None and g_det <= 1.0
        pen = min(35, int(round(5 + 3 * g_rec)))
        penalty["boundary"] = pen
        issues.append("boundary_shift")
        geometry_verdict = "record_wrong_gnss"
        offset = max(offset, g_rec)
        reasons.append(f"GNSS field survey puts the corners {g_rec} m away from the recorded boundary"
                       + (f"; the drone image agrees ({g_det} m)" if both else "") + f" (-{pen})")
        recs.append({"action": "UPDATE_BOUNDARY", "source": "GNSS survey", "confidence": "high",
                     "text": f"Update the cadastral boundary to the GNSS-surveyed corners (about {g_rec} m change)"})
    elif boundary_state == "shifted":
        if g_rec is not None and g_rec <= 1.0:
            geometry_verdict = "record_confirmed"
            reasons.append(f"Drone boundary differs by {offset} m, but the GNSS survey confirms the record "
                           f"(within {g_rec} m) - the image is slightly misaligned")
        else:
            pen = min(35, int(round(5 + 3 * offset)))
            penalty["boundary"] = pen
            reasons.append(f"Recorded boundary is {offset} m away from the wall seen in the drone image (-{pen})")
            recs.append({"action": "ORDER_GNSS_SURVEY", "source": "Source-trust rule", "confidence": "high",
                         "text": "Send a surveyor with DGNSS to confirm the corners before changing the record"})
            recs.append({"action": "UPDATE_BOUNDARY", "source": "Drone ORI", "confidence": "medium",
                         "text": f"Or update the boundary to the drone-detected wall ({offset} m shift)"})
            issues.append("boundary_shift")
    elif boundary_state in ("unclear", "partly hidden") and vis:
        if g_rec is not None and g_rec <= 1.0:
            reasons.append(f"Wall partly hidden in the drone image, but the GNSS survey confirms the record ({g_rec} m)")
        else:
            penalty["boundary"] = 5
            reasons.append("Part of the boundary wall is hidden by trees or shadow in the drone image (-5)"
                           if boundary_state == "partly hidden" else
                           "Boundary wall not clearly visible in the drone image (trees / shadow) (-5)")
            recs.append({"action": "ORDER_GNSS_SURVEY", "source": "Source-trust rule", "confidence": "medium",
                         "text": "Ground-check the corners with DGNSS"})
    elif boundary_state == "matches" and g_rec is not None and g_rec <= 1.0:
        reasons.append(f"Boundary confirmed by the drone image ({offset} m) and the GNSS survey ({g_rec} m)")

    # ---------------- 2c. topology
    overlaps = []
    for o in parcels:
        if o["parcel_id"] == pid:
            continue
        if abs(o["polygon"][0][0] - rec[0][0]) > 0.01 or abs(o["polygon"][0][1] - rec[0][1]) > 0.01:
            continue
        ov = geo.overlap_m2(rec, o["polygon"])
        if ov > 1.0:
            overlaps.append({"with": o["parcel_id"], "area_m2": round(ov, 1)})
    valid = geo.is_simple_polygon(rec)
    if overlaps:
        penalty["topology"] = 15
        issues.append("overlap")
        for ov in overlaps:
            reasons.append(f"Overlaps neighbouring parcel {ov['with']} by {ov['area_m2']} sq.m (-15)")
        if det and geo.mean_corner_offset_m(rec, det) > 1.0:
            recs.append({"action": "UPDATE_BOUNDARY", "source": "Drone ORI", "confidence": "high",
                         "text": "Correct this parcel's boundary to the drone-detected wall - this removes the overlap"})
    if not valid:
        penalty["topology"] = penalty.get("topology", 0) + 20
        issues.append("invalid_geometry")
        reasons.append("Boundary crosses itself (invalid polygon) (-20)")

    # ---------------- 2d. utilities
    util_hits = []
    for u in data["utilities"]:
        cl = geo.polygon_line_clearance_m(rec, u["line"])
        if cl < u["buffer_m"]:
            util_hits.append({"id": u["id"], "name": u["name"], "clearance_m": round(cl, 1), "buffer_m": u["buffer_m"]})
    if util_hits:
        penalty["utility"] = 20
        issues.append("utility")
        for h in util_hits:
            reasons.append(f"Only {h['clearance_m']} m from {h['name']} ({h['buffer_m']:.0f} m easement required) (-20)")
        recs.append({"action": "RECORD_EASEMENT", "source": "Utility layer", "confidence": "high",
                     "text": "Record the easement restriction on the land record and notify the utility department"})

    # ---------------- 2e. owners across departments
    owner = None
    rev_owner = (rev or {}).get("owner_name", "")
    rev_father = (rev or {}).get("father_name", "")
    mun_owner = (mun or {}).get("owner_name", "")
    mun_father = (mun or {}).get("father_name", "")
    if decision.get("municipal_owner_override"):
        mun_owner = decision["municipal_owner_override"]
    if rev is None:
        penalty["link"] = 30
        issues.append("no_revenue_record")
        reasons.append(f"No revenue record found for survey no. {p['survey_number']} (-30)")
        recs.append({"action": "FIELD_ENQUIRY", "source": "Record linkage", "confidence": "high",
                     "text": "Find the record of rights for this survey number"})
    if mun is None:
        penalty["municipal_link"] = 5
        reasons.append("No municipal property record at this location (-5)")
    if rev and mun:
        owner = names.match(rev_owner, mun_owner, rev_father, mun_father if mun_father not in ("—", "-") else "")
        pr = owner["probability"]
        mutation = None
        if pr < 0.5 and rev_father:
            fm = names.match(rev_father, mun_owner)
            if fm["probability"] >= 0.8:
                mutation = fm
        if mutation:
            penalty["owner"] = 25
            issues.append("mutation_pending")
            reasons.append(f"Municipal record is still in the name of the owner's father ({mun_owner}); "
                           f"Revenue shows {rev_owner} - inheritance not transferred (-25)")
            latin = names.transliterate(rev_owner).title()
            shown = rev_owner if latin == rev_owner else f"{rev_owner} ({latin})"
            recs.append({"action": "START_MUTATION", "source": "Revenue record of rights", "confidence": "high",
                         "text": f"Transfer the municipal record to the heir named in the Revenue record: {shown}"})
            owner["mutation"] = True
        elif pr >= 0.95:
            if owner["verdict"] != "Exact match":
                reasons.append(f"Owner names written differently but match ({owner['verdict'].lower()}, {pr:.0%})")
        elif pr >= 0.8:
            penalty["owner"] = 3
            reasons.append(f"Owner names differ slightly - same person ({pr:.0%}) (-3)")
            recs.append({"action": "STANDARDISE_OWNER", "source": "Revenue record of rights", "confidence": "high",
                         "text": f"Use the Revenue spelling in the municipal record"})
        elif pr >= 0.5:
            penalty["owner"] = 15
            issues.append("owner_uncertain")
            reasons.append(f"Owner names may belong to different people ({pr:.0%} same) (-15)")
            recs.append({"action": "CONFIRM_OWNER", "source": "Officer", "confidence": "medium",
                         "text": "Officer to confirm whether both records name the same person"})
        else:
            penalty["owner"] = 30
            issues.append("owner_conflict")
            reasons.append(f"Owners differ: Revenue '{rev_owner}' vs Municipal '{mun_owner}' ({pr:.0%} same) (-30)")
            recs.append({"action": "FIELD_ENQUIRY", "source": "Source-trust rule", "confidence": "high",
                         "text": "Field enquiry and check of registered documents"})

    # ---------------- 2f. buildings: footprint, change, height
    bld_info = {"footprint_m2": None, "floors_est": None, "new": [], "recorded_floors": None, "recorded_built_up_m2": None}
    if vis:
        region = [rec] + ([det] if det else [])
        in_parcel = [b for b in vis["buildings"] if any(vision.inside(vision.centroid(b["polygon"]), r) for r in region)]
        hts = [h for h in vis["heights"] if any(vision.inside(vision.centroid(h["polygon"]), r) for r in region)]
        new_b = [b for b in vis["change"]["new"] if any(vision.inside(vision.centroid(b["polygon"]), r) for r in region)]
        bld_info.update({"buildings": in_parcel, "footprint_m2": round(sum(b["area_m2"] for b in in_parcel), 1),
                         "floors_est": max((h["floors_est"] for h in hts), default=None),
                         "height_m": max((h["height_m"] for h in hts), default=None), "new": new_b,
                         "change_years": [vis["change"]["from"], vis["change"]["to"]]})
    if mun:
        try:
            bld_info["recorded_floors"] = int(float(decision.get("floors_override") or mun.get("floors") or 0)) or None
        except ValueError:
            pass
        bld_info["recorded_built_up_m2"] = decision.get("built_up_override") or mun.get("built_up_area_sq_m")
    new_area = round(sum(b["area_m2"] for b in bld_info["new"]), 1)
    if new_area >= 6 and "building" not in resolved:
        penalty["construction"] = 10
        issues.append("new_construction")
        reasons.append(f"New construction of about {new_area} sq.m since the {bld_info['change_years'][0]} survey, "
                       f"not in the municipal record (-10)")
    fe, fr = bld_info["floors_est"], bld_info["recorded_floors"]
    if fe and fr and fe > fr and "building" not in resolved:
        pen = min(16, 8 * (fe - fr))
        penalty["floors"] = pen
        issues.append("extra_floors")
        reasons.append(f"Building is about {bld_info['height_m']} m tall = {fe} floors; municipal record says {fr} (-{pen})")
    if ("new_construction" in issues or "extra_floors" in issues):
        recs.append({"action": "UPDATE_BUILDING_RECORD", "source": "DSM / ORI measurement", "confidence": "high",
                     "text": "Update the municipal building record (floors / built-up area) for property-tax reassessment"})

    # ---------------- 3. score
    score = max(0, 100 - sum(penalty.values()))
    safety = [i for i in issues if i in ("utility", "overlap", "invalid_geometry", "owner_conflict", "owner_uncertain",
                                          "mutation_pending", "no_revenue_record", "boundary_shift",
                                          "new_construction", "extra_floors")]
    if score >= AUTO_APPROVE and not safety:
        status = "Verified"
    elif score >= REVIEW:
        status = "Review required"
    else:
        status = "Serious conflict"
    reasons.sort(key=lambda t: 0 if re.search(r"\(-\d+\)$", t) else 1)
    if not reasons:
        reasons.append("All sources agree: boundary, owner, utilities and buildings")
    auto_score, auto_status = score, status
    if decision.get("status"):
        status = decision["status"]
        if status.startswith("Verified"):
            score = max(score, 100 if not safety else score)

    return {
        "parcel_id": pid, "ulpin_style_id": _ulpin(rec), "survey_number": p["survey_number"], "village": p["village"],
        "polygon": rec, "original_polygon": p["original_polygon"],
        "corrected": bool(decision.get("corrected_polygon")), "area_m2": round(area, 1),
        "score": score, "status": status, "auto_score": auto_score, "auto_status": auto_status,
        "issues": issues, "reasons": reasons, "score_breakdown": penalty, "recommendations": recs,
        "decision": decision or None,
        "revenue": rev, "municipal": {k: v for k, v in mun.items() if not k.startswith("_")} if mun else None,
        "municipal_link": (mun or {}).get("_link"),
        "owner_match": owner,
        "checks": {
            "boundary": {"state": boundary_state, "offset_m": offset, "detected": det, "iou_with_record": round(iou_rec, 3),
                         "area_ratio": round(ratio, 2) if ratio else None,
                         "gnss_points": len(gnss), "gnss_vs_record_m": g_rec, "gnss_vs_drone_m": g_det,
                         "gnss_polygon": gnss_poly, "verdict": geometry_verdict},
            "topology": {"overlaps": overlaps, "valid": valid},
            "utilities": util_hits,
            "buildings": bld_info,
        },
        "has_imagery": vis is not None,
        "surveys": [s["year"] for s in (vis or {}).get("meta", {}).get("surveys", [])],
    }


def _ulpin(poly) -> str:
    import hashlib
    c = geo.centroid_latlon(poly)
    h = hashlib.sha256(f"{c[0]:.6f}:{c[1]:.6f}".encode()).hexdigest().upper()
    return f"{int(c[0] * 1000) % 10000:04d}{int(c[1] * 1000) % 10000:04d}{h[:6]}"


def _summary(results) -> Dict[str, Any]:
    tot = len(results)
    by = {}
    for r in results:
        by[r["status"]] = by.get(r["status"], 0) + 1
    issues = {}
    for r in results:
        for i in r["issues"]:
            issues[i] = issues.get(i, 0) + 1
    verified = sum(1 for r in results if r["status"].startswith("Verified"))
    auto = sum(1 for r in results if r["auto_status"] == "Verified")
    return {"total_parcels": tot, "verified": verified, "auto_verified": auto,
            "needs_review": sum(1 for r in results if r["status"] in ("Review required", "Serious conflict")),
            "serious": by.get("Serious conflict", 0), "by_status": by, "issues": issues,
            "average_confidence": round(sum(r["score"] for r in results) / max(1, tot), 1),
            "auto_approve_threshold": AUTO_APPROVE}


def invalidate(loc: Optional[str] = None):
    with _lock:
        if loc:
            _cache.pop(loc, None)
        else:
            _cache.clear()
