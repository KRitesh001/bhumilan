"""
engine/vision.py - computer vision on georeferenced drone ORI.

* Boundary extraction : thin dark linear features (compound walls / fences) via morphological
                        black-hat, closed rings -> polygons -> geo-coordinates from the image bounds
* Spatial matching     : detected rings are matched to the recorded parcel by IoU
* Building footprints  : roof segmentation (concrete / tiled roofs) -> rectangles -> geo-coordinates
* Change detection     : building footprints of the oldest vs newest survey, object-level matching
* DSM / DTM            : normalised surface height (nDSM) -> building height -> number of floors
Rule-based CV tuned for this imagery; the interfaces are the same ones a trained segmentation
model (e.g. U-Net on real ORI) plugs into.
"""

import json
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from engine.geo import area_m2, overlap_m2, mean_corner_offset_m

FLOOR_HEIGHT_M = 3.1
PARAPET_M = 0.8


def load_meta(folder: Path) -> Optional[Dict]:
    f = folder / "meta.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None


def px_to_latlon(pts, meta) -> List[Tuple[float, float]]:
    w_lon, s_lat, e_lon, n_lat = meta["bounds"]
    W, H = meta["width"], meta["height"]
    return [(n_lat - (y + 0.5) / H * (n_lat - s_lat), w_lon + (x + 0.5) / W * (e_lon - w_lon)) for x, y in pts]


def latlon_to_px(pts, meta) -> List[Tuple[int, int]]:
    w_lon, s_lat, e_lon, n_lat = meta["bounds"]
    W, H = meta["width"], meta["height"]
    return [(int(round((lon - w_lon) / (e_lon - w_lon) * W - 0.5)),
             int(round((n_lat - lat) / (n_lat - s_lat) * H - 0.5))) for lat, lon in pts]


def iou(a, b) -> float:
    inter = overlap_m2(a, b)
    union = area_m2(a) + area_m2(b) - inter
    return inter / union if union > 0 else 0.0


# ---------------------------------------------------------------------------
# Boundary (compound wall) extraction
# ---------------------------------------------------------------------------

def extract_boundaries(img: np.ndarray, meta: Dict) -> List[List[Tuple[float, float]]]:
    """All closed wall rings in the image, as lat/lon polygons."""
    gsd = meta.get("gsd_m", 0.1)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    k = max(5, int(round(1.2 / gsd)) | 1)
    blackhat = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    mask = ((blackhat > 8) & (gray < 125)).astype(np.uint8) * 255
    mask[:26, :] = 0                      # ignore the caption bars
    mask[-18:, :] = 0
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    # remove building / tree shadows: dark areas thicker than a wall (> ~1 m)
    t = max(3, int(round(1.0 / gsd)) | 1)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    grey_dark = ((hsv[..., 2] < 95) & (hsv[..., 1] < 70)).astype(np.uint8) * 255   # shadows are grey, trees green
    thick = cv2.morphologyEx(grey_dark, cv2.MORPH_OPEN, np.ones((t, t), np.uint8))
    mask &= ~cv2.dilate(thick, np.ones((3, 3), np.uint8))
    # keep only long straight runs (walls); round tree / shadow outlines disappear
    L = max(9, int(round(2.0 / gsd)))
    horiz = cv2.morphologyEx(mask, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (L, 1)))
    vert = cv2.morphologyEx(mask, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, L)))
    # bridge gaps along each wall line where a tree canopy or shadow hides the wall (up to ~16 m)
    B = max(15, int(round(12.0 / gsd)))
    horiz = cv2.morphologyEx(horiz, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (B, 1)))
    vert = cv2.morphologyEx(vert, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (1, B)))
    # re-join corners
    g = max(3, int(round(0.8 / gsd)) | 1)
    mask = cv2.morphologyEx(horiz | vert, cv2.MORPH_CLOSE, np.ones((g, g), np.uint8))
    contours, hier = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    rings = []
    if hier is None:
        return rings
    img_area = img.shape[0] * img.shape[1]
    for cnt, h in zip(contours, hier[0]):
        if h[3] < 0:                      # keep holes = the inside edge of a closed wall ring
            continue
        a = cv2.contourArea(cnt)
        if a < 0.01 * img_area or a > 0.9 * img_area:
            continue
        hull = cv2.convexHull(cnt)
        if a / max(1.0, cv2.contourArea(hull)) < 0.85:
            continue
        approx = cv2.approxPolyDP(hull, 0.02 * cv2.arcLength(hull, True), True)
        if len(approx) < 4 or len(approx) > 8:
            continue
        eps = 0.02
        while len(approx) > 4 and eps < 0.08:       # parcels are quadrilaterals: keep the 4 real corners
            eps += 0.01
            approx = cv2.approxPolyDP(hull, eps * cv2.arcLength(hull, True), True)
        if len(approx) < 4:
            continue
        pts = [(int(p[0][0]), int(p[0][1])) for p in approx]
        # expand by half a wall width so the ring follows the wall centre line
        cx, cy = np.mean([p[0] for p in pts]), np.mean([p[1] for p in pts])
        grow = max(1.0, 0.175 / gsd)
        pts = [(x + grow * np.sign(x - cx), y + grow * np.sign(y - cy)) for x, y in pts]
        rings.append(px_to_latlon(pts, meta))
    return rings


def match_boundary(record, rings) -> Tuple[Optional[List], float]:
    """Picks the detected wall ring that best matches the recorded parcel (highest IoU)."""
    best, best_iou = None, 0.0
    for r in rings:
        v = iou(record, r)
        if v > best_iou:
            best, best_iou = r, v
    return best, best_iou


# ---------------------------------------------------------------------------
# Building footprints
# ---------------------------------------------------------------------------

def roof_mask(img: np.ndarray, meta: Dict) -> np.ndarray:
    """Pixels that look like roofs: bright low-saturation concrete or red/orange tiles."""
    gsd = meta.get("gsd_m", 0.1)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    Hh, S, V = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    mask = (((V > 168) & (S < 42)) | ((Hh <= 14) & (S > 85) & (V > 115))).astype(np.uint8) * 255
    mask[:26, :] = 0
    mask[-18:, :] = 0
    k = max(3, int(round(0.6 / gsd)) | 1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((k, k), np.uint8))
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))


def _blobs(mask: np.ndarray, meta: Dict, min_m2: float = 6.0) -> List[Dict]:
    gsd = meta.get("gsd_m", 0.1)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    for cnt in contours:
        a_m2 = cv2.contourArea(cnt) * gsd * gsd
        if a_m2 < min_m2:
            continue
        (cx, cy), (w, h), ang = cv2.minAreaRect(cnt)
        if cv2.contourArea(cnt) / max(1.0, w * h) >= 0.85:          # a clean rectangle
            pts = cv2.boxPoints(((cx, cy), (w, h), ang))
            shape = "rectangle"
        else:                                                      # e.g. house + extension joined
            pts = cv2.approxPolyDP(cnt, 0.01 * cv2.arcLength(cnt, True), True).reshape(-1, 2)
            shape = "joined buildings"
        poly = px_to_latlon([(float(x), float(y)) for x, y in pts], meta)
        out.append({"polygon": poly, "area_m2": round(a_m2, 1), "shape": shape})
    return out


def extract_buildings(img: np.ndarray, meta: Dict) -> List[Dict]:
    """Building footprints (roof outlines) as lat/lon polygons with their area."""
    return _blobs(roof_mask(img, meta), meta)


def detect_changes_px(img_old: np.ndarray, img_new: np.ndarray, meta: Dict, parcel_poly=None) -> Dict:
    """Roof-mask differencing between two georeferenced surveys of the same ground.
    Roof in the new survey but not the old one = new construction (even if it touches the old house)."""
    gsd = meta.get("gsd_m", 0.1)
    old, new = roof_mask(img_old, meta), roof_mask(img_new, meta)
    tol = max(3, int(round(1.0 / gsd)) | 1)                        # ignore 1 m of edge wobble
    k = max(3, int(round(1.5 / gsd)) | 1)
    added = cv2.morphologyEx(new & ~cv2.dilate(old, np.ones((tol, tol), np.uint8)), cv2.MORPH_OPEN, np.ones((k, k), np.uint8))
    removed = cv2.morphologyEx(old & ~cv2.dilate(new, np.ones((tol, tol), np.uint8)), cv2.MORPH_OPEN, np.ones((k, k), np.uint8))
    # grow the changes back over the tolerance band so their measured area is right
    grow = np.ones((tol + 2, tol + 2), np.uint8)
    added = cv2.dilate(added, grow) & new & ~old
    removed = cv2.dilate(removed, grow) & old & ~new
    new_b, gone_b = _blobs(added, meta), _blobs(removed, meta)
    if parcel_poly:
        polys = parcel_poly if isinstance(parcel_poly[0][0], (list, tuple)) else [parcel_poly]
        new_b = [b for b in new_b if any(inside(centroid(b["polygon"]), p) for p in polys)]
        gone_b = [b for b in gone_b if any(inside(centroid(b["polygon"]), p) for p in polys)]
    return {"new": new_b, "demolished": gone_b, "extended": [],
            "new_area_m2": round(sum(b["area_m2"] for b in new_b), 1)}


def _rectangularity(cnt) -> float:
    (_, _), (w, h), _ = cv2.minAreaRect(cnt)
    return cv2.contourArea(cnt) / max(1.0, w * h)


def _split_rectilinear(blob: np.ndarray, cnt, depth: int = 0):
    """An extension built against a house merges with it into an L / T shape. Cut the shape at a
    concave (inner) corner, along one of the corner's edges, so each part becomes a rectangle."""
    if _rectangularity(cnt) >= 0.9 or depth >= 2:
        return [cnt]
    approx = cv2.approxPolyDP(cnt, 0.012 * cv2.arcLength(cnt, True), True).reshape(-1, 2)
    n = len(approx)
    if n < 5:
        return [cnt]
    best, best_score = None, _rectangularity(cnt)
    for i in range(n):
        p0, p1, p2 = approx[i - 1], approx[i], approx[(i + 1) % n]
        cross = (p1[0] - p0[0]) * (p2[1] - p1[1]) - (p1[1] - p0[1]) * (p2[0] - p1[0])
        area_sign = cv2.contourArea(approx.reshape(-1, 1, 2), oriented=True)
        if cross * area_sign <= 0:           # convex corner - not a place to cut
            continue
        for q in (p0, p2):                   # extend each edge meeting at the inner corner
            d = p1.astype(float) - q.astype(float)
            d /= max(1e-6, np.hypot(*d))
            far = (p1 + d * 4000).astype(int)
            cut = blob.copy()
            cv2.line(cut, tuple(int(v) for v in p1), tuple(int(v) for v in far), 0, 3)
            parts, _ = cv2.findContours(cut, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            parts = [c for c in parts if cv2.contourArea(c) > 0.04 * cv2.contourArea(cnt)]
            if len(parts) < 2:
                continue
            tot = sum(cv2.contourArea(c) for c in parts)
            score = sum(_rectangularity(c) * cv2.contourArea(c) for c in parts) / tot
            if score > best_score + 0.03:
                best, best_score = (cut, parts), score
    if best is None:
        return [cnt]
    cut, parts = best
    out = []
    for c in parts:
        piece = np.zeros(blob.shape, np.uint8)
        cv2.drawContours(piece, [c], -1, 255, -1)
        out += _split_rectilinear(piece, c, depth + 1)
    return out


def inside(pt, poly) -> bool:
    x, y = pt[1], pt[0]
    res = False
    for i in range(len(poly)):
        (y1, x1), (y2, x2) = poly[i], poly[(i + 1) % len(poly)]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            res = not res
    return res


def centroid(poly):
    return (sum(p[0] for p in poly) / len(poly), sum(p[1] for p in poly) / len(poly))


def buildings_in(parcel_poly, buildings):
    return [b for b in buildings if inside(centroid(b["polygon"]), parcel_poly)]


# ---------------------------------------------------------------------------
# Change detection (object level: robust to lighting and trees changing between surveys)
# ---------------------------------------------------------------------------

def detect_changes(old_buildings, new_buildings) -> Dict:
    new_structures, extended = [], []
    for nb in new_buildings:
        best = max((iou(nb["polygon"], ob["polygon"]) for ob in old_buildings), default=0.0)
        if best < 0.3:
            new_structures.append(nb)
        else:
            ob = max(old_buildings, key=lambda o: iou(nb["polygon"], o["polygon"]))
            if nb["area_m2"] > ob["area_m2"] * 1.25:
                extended.append({"polygon": nb["polygon"], "area_m2": nb["area_m2"], "was_m2": ob["area_m2"]})
    demolished = [ob for ob in old_buildings
                  if max((iou(ob["polygon"], nb["polygon"]) for nb in new_buildings), default=0.0) < 0.3]
    return {"new": new_structures, "extended": extended, "demolished": demolished,
            "new_area_m2": round(sum(b["area_m2"] for b in new_structures), 1)}


# ---------------------------------------------------------------------------
# DSM / DTM
# ---------------------------------------------------------------------------

@lru_cache(maxsize=256)
def _load_surface(path: str, mtime: float):
    z = np.load(path)
    return z["dtm"], z["dsm"], tuple(float(v) for v in z["bounds"])


def building_heights(surface_file: Path, buildings: List[Dict]) -> List[Dict]:
    if not surface_file.exists():
        return []
    dtm, dsm, (w_lon, s_lat, e_lon, n_lat) = _load_surface(str(surface_file), surface_file.stat().st_mtime)
    ndsm = dsm - dtm
    ny, nx = ndsm.shape
    out = []
    for b in buildings:
        pts = [((lon - w_lon) / (e_lon - w_lon) * nx, (n_lat - lat) / (n_lat - s_lat) * ny) for lat, lon in b["polygon"]]
        m = np.zeros(ndsm.shape, np.uint8)
        cv2.fillPoly(m, [np.array(pts, np.int32)], 1)
        m = cv2.erode(m, np.ones((3, 3), np.uint8))          # stay off the roof edge
        vals = ndsm[m > 0]
        if vals.size < 4:
            continue
        h = float(np.median(vals))
        floors = max(1, int(round((h - PARAPET_M) / FLOOR_HEIGHT_M)))
        out.append({**b, "height_m": round(h, 1), "floors_est": floors})
    return out


def render_ndsm(surface_file: Path, record=None, meta_bounds=None) -> Optional[bytes]:
    if not surface_file.exists():
        return None
    dtm, dsm, bounds = _load_surface(str(surface_file), surface_file.stat().st_mtime)
    ndsm = np.clip(dsm - dtm, 0, 16)
    norm = (ndsm / 16 * 255).astype(np.uint8)
    col = cv2.applyColorMap(norm, cv2.COLORMAP_TURBO)
    col = cv2.resize(col, (768, int(768 * ndsm.shape[0] / ndsm.shape[1])), interpolation=cv2.INTER_NEAREST)
    if record:
        meta = {"bounds": list(bounds), "width": col.shape[1], "height": col.shape[0]}
        cv2.polylines(col, [np.array(latlon_to_px(record, meta), np.int32)], True, (255, 255, 255), 2, cv2.LINE_AA)
    # legend
    bar = np.linspace(0, 255, 256).astype(np.uint8)[None, :].repeat(14, 0)
    bar = cv2.resize(cv2.applyColorMap(bar, cv2.COLORMAP_TURBO), (220, 14))
    cv2.rectangle(col, (8, col.shape[0] - 46), (300, col.shape[0] - 6), (255, 255, 255), -1)
    col[col.shape[0] - 40:col.shape[0] - 26, 16:236] = bar
    cv2.putText(col, "0 m", (14, col.shape[0] - 11), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (30, 30, 30), 1, cv2.LINE_AA)
    cv2.putText(col, "16 m above ground", (160, col.shape[0] - 11), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (30, 30, 30), 1, cv2.LINE_AA)
    ok, buf = cv2.imencode(".png", col)
    return buf.tobytes() if ok else None


# ---------------------------------------------------------------------------
# Visual evidence for officers
# ---------------------------------------------------------------------------

def _poly(img, pts_ll, meta, color, thick, fill=None):
    px = np.array(latlon_to_px(pts_ll, meta), np.int32)
    if fill is not None:
        over = img.copy()
        cv2.fillPoly(over, [px], fill, cv2.LINE_AA)
        cv2.addWeighted(over, 0.35, img, 0.65, 0, img)
    cv2.polylines(img, [px], True, color, thick, cv2.LINE_AA)


def render_evidence(img, meta, record, detected, buildings, new_buildings, gnss_pts, utilities) -> bytes:
    img = img.copy()
    for u in utilities or []:
        px = np.array(latlon_to_px(u["line"], meta), np.int32)
        width = max(3, int(2 * u["buffer_m"] / meta.get("gsd_m", 0.1)))
        over = img.copy()
        cv2.polylines(over, [px], False, (200, 120, 40), width, cv2.LINE_AA)
        cv2.addWeighted(over, 0.28, img, 0.72, 0, img)
        cv2.polylines(img, [px], False, (200, 110, 30), 2, cv2.LINE_AA)
    for b in buildings:
        _poly(img, b["polygon"], meta, (40, 210, 255), 2)
    for b in new_buildings:
        _poly(img, b["polygon"], meta, (200, 40, 220), 3, fill=(200, 40, 220))
    if detected:
        _poly(img, detected, meta, (40, 40, 225), 4)
        for x, y in latlon_to_px(detected, meta):
            cv2.circle(img, (x, y), 6, (40, 40, 225), -1, cv2.LINE_AA)
    _poly(img, record, meta, (235, 205, 40), 2)
    for lat, lon in gnss_pts or []:
        x, y = latlon_to_px([(lat, lon)], meta)[0]
        cv2.drawMarker(img, (x, y), (255, 255, 255), cv2.MARKER_TILTED_CROSS, 16, 4, cv2.LINE_AA)
        cv2.drawMarker(img, (x, y), (30, 160, 30), cv2.MARKER_TILTED_CROSS, 14, 2, cv2.LINE_AA)
    items = [((235, 205, 40), "Official record")]
    if detected:
        items.append(((40, 40, 225), "Boundary found by AI"))
    if buildings:
        items.append(((40, 210, 255), "Building footprint"))
    if new_buildings:
        items.append(((200, 40, 220), "New since last survey"))
    if gnss_pts:
        items.append(((30, 160, 30), "GNSS survey point"))
    if utilities:
        items.append(((200, 110, 30), "Utility + easement"))
    h = 22 * len(items) + 10
    y0 = img.shape[0] - h - 24
    cv2.rectangle(img, (8, y0), (238, y0 + h), (255, 255, 255), -1)
    for i, (c, t) in enumerate(items):
        yy = y0 + 18 + i * 22
        cv2.line(img, (18, yy - 5), (50, yy - 5), c, 4)
        cv2.putText(img, t, (60, yy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (30, 30, 30), 1, cv2.LINE_AA)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return buf.tobytes()


def render_change(img_old, img_new, meta, old_b, new_b, change) -> bytes:
    a, b = img_old.copy(), img_new.copy()
    for x in old_b:
        _poly(a, x["polygon"], meta, (40, 210, 255), 2)
    for x in new_b:
        _poly(b, x["polygon"], meta, (40, 210, 255), 2)
    for x in change["new"]:
        _poly(b, x["polygon"], meta, (200, 40, 220), 4, fill=(200, 40, 220))
    for x in change["extended"]:
        _poly(b, x["polygon"], meta, (40, 140, 255), 4)
    gap = np.full((a.shape[0], 8, 3), 255, np.uint8)
    out = np.hstack([a, gap, b])
    ok, buf = cv2.imencode(".jpg", out, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return buf.tobytes()
