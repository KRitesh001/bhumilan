"""
engine/geo.py - geo-referencing and coordinate transformation engine (pure Python).

* WGS84 lat/lon  <->  UTM (any zone; India spans zones 42N-47N, EPSG:32642-32647)
* Automatic CRS detection for uploaded coordinates (.prj text, EPSG codes, value ranges)
* Polygon helpers in local metres: area, centroid, convex overlap, point/segment distance

No GDAL/pyproj needed, so the platform installs cleanly on any laptop or server.
Formulas: Kruger series for the transverse Mercator projection (accurate to < 1 mm
inside a UTM zone), the same approach used by GeographicLib and pyproj's 'etmerc'.
"""

import math
import re
from typing import List, Tuple, Optional, Dict

# WGS84 ellipsoid
_A = 6378137.0
_F = 1 / 298.257223563
_K0 = 0.9996
_N = _F / (2 - _F)
_A_HAT = _A / (1 + _N) * (1 + _N ** 2 / 4 + _N ** 4 / 64)
_ALPHA = (
    _N / 2 - 2 * _N ** 2 / 3 + 5 * _N ** 3 / 16,
    13 * _N ** 2 / 48 - 3 * _N ** 3 / 5,
    61 * _N ** 3 / 240,
)
_BETA = (
    _N / 2 - 2 * _N ** 2 / 3 + 37 * _N ** 3 / 96,
    _N ** 2 / 48 + _N ** 3 / 15,
    17 * _N ** 3 / 480,
)
_DELTA = (
    2 * _N - 2 * _N ** 2 / 3 - 2 * _N ** 3,
    7 * _N ** 2 / 3 - 8 * _N ** 3 / 5,
    56 * _N ** 3 / 15,
)

INDIA_BBOX = (68.0, 6.0, 97.5, 37.5)   # lon_min, lat_min, lon_max, lat_max (approx.)


def utm_zone_for(lon: float) -> int:
    return int((lon + 180) // 6) + 1


def utm_epsg(lat: float, lon: float) -> int:
    return (32600 if lat >= 0 else 32700) + utm_zone_for(lon)


def latlon_to_utm(lat: float, lon: float, zone: Optional[int] = None) -> Tuple[float, float, int]:
    """(lat, lon) in degrees -> (easting, northing, zone). Northern hemisphere assumed for India."""
    zone = zone or utm_zone_for(lon)
    lon0 = math.radians((zone - 1) * 6 - 180 + 3)
    phi, lam = math.radians(lat), math.radians(lon) - lon0
    e = math.sqrt(_F * (2 - _F))
    t = math.sinh(math.atanh(math.sin(phi)) - e * math.atanh(e * math.sin(phi)))
    xi_p = math.atan2(t, math.cos(lam))
    eta_p = math.atanh(math.sin(lam) / math.sqrt(1 + t * t))
    xi, eta = xi_p, eta_p
    for j, a in enumerate(_ALPHA, start=1):
        xi += a * math.sin(2 * j * xi_p) * math.cosh(2 * j * eta_p)
        eta += a * math.cos(2 * j * xi_p) * math.sinh(2 * j * eta_p)
    easting = 500000.0 + _K0 * _A_HAT * eta
    northing = _K0 * _A_HAT * xi
    if lat < 0:
        northing += 10000000.0
    return easting, northing, zone


def utm_to_latlon(easting: float, northing: float, zone: int, northern: bool = True) -> Tuple[float, float]:
    """UTM -> (lat, lon) in degrees."""
    if not northern:
        northing -= 10000000.0
    xi = northing / (_K0 * _A_HAT)
    eta = (easting - 500000.0) / (_K0 * _A_HAT)
    xi_p, eta_p = xi, eta
    for j, b in enumerate(_BETA, start=1):
        xi_p -= b * math.sin(2 * j * xi) * math.cosh(2 * j * eta)
        eta_p -= b * math.cos(2 * j * xi) * math.sinh(2 * j * eta)
    chi = math.asin(math.sin(xi_p) / math.cosh(eta_p))
    phi = chi
    for j, d in enumerate(_DELTA, start=1):
        phi += d * math.sin(2 * j * chi)
    lon0 = (zone - 1) * 6 - 180 + 3
    lam = math.atan2(math.sinh(eta_p), math.cos(xi_p))
    return math.degrees(phi), lon0 + math.degrees(lam)


# ---------------------------------------------------------------------------
# CRS detection for uploaded data
# ---------------------------------------------------------------------------

def parse_crs_hint(text: Optional[str]) -> Optional[Dict]:
    """Understands EPSG codes ('EPSG:32644', 'urn:ogc:def:crs:EPSG::32644') and .prj WKT text."""
    if not text:
        return None
    t = str(text)
    m = re.search(r"EPSG[^0-9]{0,6}(\d{4,5})", t, re.I)
    if m:
        code = int(m.group(1))
        if code in (4326, 4979):
            return {"kind": "geographic", "epsg": 4326, "label": "WGS84 latitude/longitude (EPSG:4326)"}
        if 32601 <= code <= 32660 or 32701 <= code <= 32760:
            zone = code % 100
            north = code < 32700
            return {"kind": "utm", "zone": zone, "northern": north, "epsg": code,
                    "label": f"WGS84 / UTM zone {zone}{'N' if north else 'S'} (EPSG:{code})"}
    if "CRS84" in t.upper():
        return {"kind": "geographic", "epsg": 4326, "label": "WGS84 longitude/latitude (CRS84)"}
    m = re.search(r"UTM[ _]?zone[ _]?(\d{1,2})\s*([NS])?", t, re.I)
    if m:
        zone = int(m.group(1))
        north = (m.group(2) or "N").upper() == "N"
        return {"kind": "utm", "zone": zone, "northern": north, "epsg": (32600 if north else 32700) + zone,
                "label": f"WGS84 / UTM zone {zone}{'N' if north else 'S'}"}
    if "GEOGCS" in t.upper() and "PROJCS" not in t.upper():
        return {"kind": "geographic", "epsg": 4326, "label": "Geographic latitude/longitude (from .prj)"}
    return None


def guess_crs(xs: List[float], ys: List[float], hint: Optional[Dict] = None,
              location_lonlat: Optional[Tuple[float, float]] = None) -> Dict:
    """Decides how coordinates are stored when the file doesn't say.
    Degrees inside India -> WGS84.  Large metre values -> UTM (zone from the hint or the chosen location)."""
    if hint:
        return hint
    if not xs:
        return {"kind": "geographic", "epsg": 4326, "label": "WGS84 latitude/longitude (assumed)"}
    x0, y0 = xs[0], ys[0]
    if -180 <= x0 <= 180 and -90 <= y0 <= 90:
        if INDIA_BBOX[0] <= x0 <= INDIA_BBOX[2] and INDIA_BBOX[1] <= y0 <= INDIA_BBOX[3]:
            return {"kind": "geographic", "epsg": 4326, "label": "WGS84 longitude/latitude (detected from values)"}
        if INDIA_BBOX[0] <= y0 <= INDIA_BBOX[2] and INDIA_BBOX[1] <= x0 <= INDIA_BBOX[3]:
            return {"kind": "geographic_swapped", "epsg": 4326,
                    "label": "WGS84 latitude/longitude, columns swapped (detected and fixed)"}
        return {"kind": "geographic", "epsg": 4326, "label": "WGS84 longitude/latitude (outside India!)"}
    if 100000 <= x0 <= 900000 and 0 <= y0 <= 10000000:
        zone = utm_zone_for(location_lonlat[0]) if location_lonlat else 44
        return {"kind": "utm", "zone": zone, "northern": True, "epsg": 32600 + zone,
                "label": f"UTM metres - zone {zone}N taken from the selected location (EPSG:{32600 + zone})"}
    return {"kind": "unknown", "label": "Could not recognise the coordinate system"}


def to_lonlat(x: float, y: float, crs: Dict) -> Tuple[float, float]:
    """Converts one coordinate pair to (lon, lat) WGS84 using a detected CRS."""
    k = crs.get("kind")
    if k == "geographic":
        return x, y
    if k == "geographic_swapped":
        return y, x
    if k == "utm":
        lat, lon = utm_to_latlon(x, y, crs["zone"], crs.get("northern", True))
        return lon, lat
    raise ValueError(crs.get("label", "Unknown coordinate system"))


# ---------------------------------------------------------------------------
# Polygon helpers (small parcels -> local tangent-plane metres are accurate to cm)
# ---------------------------------------------------------------------------

def meters_per_degree(lat: float) -> Tuple[float, float]:
    """Metres per degree of longitude and latitude at a latitude (WGS84 series)."""
    p = math.radians(lat)
    m_lat = 111132.92 - 559.82 * math.cos(2 * p) + 1.175 * math.cos(4 * p)
    m_lon = 111412.84 * math.cos(p) - 93.5 * math.cos(3 * p)
    return m_lon, m_lat


def to_local_m(points_latlon: List[Tuple[float, float]], ref: Tuple[float, float]) -> List[Tuple[float, float]]:
    m_lon, m_lat = meters_per_degree(ref[0])
    return [((lon - ref[1]) * m_lon, (lat - ref[0]) * m_lat) for lat, lon in points_latlon]


def from_local_m(points_xy: List[Tuple[float, float]], ref: Tuple[float, float]) -> List[Tuple[float, float]]:
    m_lon, m_lat = meters_per_degree(ref[0])
    return [(ref[0] + y / m_lat, ref[1] + x / m_lon) for x, y in points_xy]


def centroid_latlon(points_latlon: List[Tuple[float, float]]) -> Tuple[float, float]:
    return (sum(p[0] for p in points_latlon) / len(points_latlon),
            sum(p[1] for p in points_latlon) / len(points_latlon))


def shoelace(xy: List[Tuple[float, float]]) -> float:
    s = 0.0
    for i in range(len(xy)):
        x1, y1 = xy[i]
        x2, y2 = xy[(i + 1) % len(xy)]
        s += x1 * y2 - x2 * y1
    return s / 2.0


def area_m2(points_latlon: List[Tuple[float, float]]) -> float:
    ref = centroid_latlon(points_latlon)
    return abs(shoelace(to_local_m(points_latlon, ref)))


def _ccw(xy):
    return xy if shoelace(xy) > 0 else list(reversed(xy))


def clip_convex(subject: List[Tuple[float, float]], clipper: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
    """Sutherland-Hodgman: intersection of a polygon with a convex polygon (both in metres)."""
    subject, clipper = _ccw(subject), _ccw(clipper)
    out = subject
    for i in range(len(clipper)):
        a, b = clipper[i], clipper[(i + 1) % len(clipper)]
        inp, out = out, []
        if not inp:
            break

        def inside(p):
            return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-9

        def cross(p, q):
            x1, y1, x2, y2 = a[0], a[1], b[0], b[1]
            x3, y3, x4, y4 = p[0], p[1], q[0], q[1]
            den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            if abs(den) < 1e-12:
                return q
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
            return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))

        for j in range(len(inp)):
            cur, prev = inp[j], inp[j - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(cross(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(cross(prev, cur))
    return out


def overlap_m2(poly_a_latlon, poly_b_latlon) -> float:
    """Overlap area of two parcels (convex quadrilaterals, as cadastral parcels here are)."""
    ref = centroid_latlon(list(poly_a_latlon) + list(poly_b_latlon))
    inter = clip_convex(to_local_m(poly_a_latlon, ref), to_local_m(poly_b_latlon, ref))
    return abs(shoelace(inter)) if len(inter) >= 3 else 0.0


def point_segment_m(p, a, b) -> float:
    """Distance (m) from point p to segment ab; all in local metres."""
    (px, py), (ax, ay), (bx, by) = p, a, b
    dx, dy = bx - ax, by - ay
    if dx == dy == 0:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def _segments_intersect(p1, p2, q1, q2) -> bool:
    def o(a, b, c):
        v = (b[1] - a[1]) * (c[0] - b[0]) - (b[0] - a[0]) * (c[1] - b[1])
        return 0 if abs(v) < 1e-12 else (1 if v > 0 else 2)
    return o(p1, p2, q1) != o(p1, p2, q2) and o(q1, q2, p1) != o(q1, q2, p2)


def _point_in_poly(p, poly) -> bool:
    x, y, inside = p[0], p[1], False
    for i in range(len(poly)):
        (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % len(poly)]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
    return inside


def polygon_line_clearance_m(poly_latlon, line_latlon) -> float:
    """Shortest distance (m) between a parcel and a utility line. 0 if the line crosses the parcel."""
    ref = centroid_latlon(list(poly_latlon))
    P = to_local_m(poly_latlon, ref)
    L = to_local_m(line_latlon, ref)
    for i in range(len(L) - 1):
        for j in range(len(P)):
            if _segments_intersect(L[i], L[i + 1], P[j], P[(j + 1) % len(P)]):
                return 0.0
    if any(_point_in_poly(pt, P) for pt in L):
        return 0.0
    best = float("inf")
    for i in range(len(L) - 1):
        for pt in P:
            best = min(best, point_segment_m(pt, L[i], L[i + 1]))
    for pt in L:
        for j in range(len(P)):
            best = min(best, point_segment_m(pt, P[j], P[(j + 1) % len(P)]))
    return best


def mean_corner_offset_m(poly_a_latlon, poly_b_latlon) -> float:
    """Average distance from each corner of A to the nearest corner of B (metres)."""
    ref = centroid_latlon(list(poly_a_latlon))
    A = to_local_m(poly_a_latlon, ref)
    B = to_local_m(poly_b_latlon, ref)
    if not A or not B:
        return 0.0
    return sum(min(math.hypot(ax - bx, ay - by) for bx, by in B) for ax, ay in A) / len(A)


def is_simple_polygon(poly_latlon) -> bool:
    """False if edges cross each other (self-intersection = broken topology)."""
    n = len(poly_latlon)
    if n < 3:
        return False
    ref = centroid_latlon(list(poly_latlon))
    P = to_local_m(poly_latlon, ref)
    for i in range(n):
        for j in range(i + 1, n):
            if abs(i - j) in (1, n - 1):
                continue
            if _segments_intersect(P[i], P[(i + 1) % n], P[j], P[(j + 1) % n]):
                return False
    return True


def max_edge_angle_deviation(poly_a_latlon, poly_b_latlon) -> float:
    """Largest angle (degrees) between an edge of B and the most parallel edge of A.
    A wall hidden by trees gets bridged diagonally - a big deviation reveals it."""
    ref = centroid_latlon(list(poly_a_latlon))
    A = to_local_m(poly_a_latlon, ref)
    B = to_local_m(poly_b_latlon, ref)

    def dirs(P):
        out = []
        for i in range(len(P)):
            (x1, y1), (x2, y2) = P[i], P[(i + 1) % len(P)]
            if math.hypot(x2 - x1, y2 - y1) > 1.0:
                out.append(math.degrees(math.atan2(y2 - y1, x2 - x1)) % 180)
        return out
    da, db = dirs(A), dirs(B)
    worst = 0.0
    for b in db:
        worst = max(worst, min(min(abs(b - a), 180 - abs(b - a)) for a in da) if da else 0.0)
    return worst
