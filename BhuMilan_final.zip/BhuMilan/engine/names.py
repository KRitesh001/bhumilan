"""
engine/names.py - owner-name matching across departments and scripts.

1. Transliteration: Devanagari (Hindi/Marathi), Bengali/Assamese, Gurmukhi, Gujarati, Odia,
   Tamil, Telugu, Kannada and Malayalam -> Latin. These Unicode blocks share the same layout
   (inherited from ISCII), so one offset table covers all of them.
2. Phonetic normalisation of Indian name spellings (Sreenivas = Srinivas = Shrinivas).
3. A trained logistic-regression model (tools/train_name_matcher.py) that turns 10 comparison
   features into a probability that two records name the same person, plus the reasons.
Inference needs only the Python standard library; the weights live in models/name_matcher.json.
"""

import json
import math
import re
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Dict, List, Optional, Tuple

MODEL_FILE = Path(__file__).resolve().parent.parent / "models" / "name_matcher.json"

# Script blocks (start code point, name, deletes final inherent 'a'?)
SCRIPTS = {
    0x0900: ("Devanagari", True), 0x0980: ("Bengali", True), 0x0A00: ("Gurmukhi", True),
    0x0A80: ("Gujarati", True), 0x0B00: ("Odia", False), 0x0B80: ("Tamil", False),
    0x0C00: ("Telugu", False), 0x0C80: ("Kannada", False), 0x0D00: ("Malayalam", False),
}
VOWELS = {0x05: "a", 0x06: "aa", 0x07: "i", 0x08: "ii", 0x09: "u", 0x0A: "uu", 0x0B: "ri", 0x0C: "li",
          0x0D: "e", 0x0E: "e", 0x0F: "e", 0x10: "ai", 0x11: "o", 0x12: "o", 0x13: "o", 0x14: "au"}
MATRAS = {0x3E: "aa", 0x3F: "i", 0x40: "ii", 0x41: "u", 0x42: "uu", 0x43: "ri", 0x44: "rri", 0x45: "e",
          0x46: "e", 0x47: "e", 0x48: "ai", 0x49: "o", 0x4A: "o", 0x4B: "o", 0x4C: "au", 0x57: "au"}
CONSONANTS = {0x15: "k", 0x16: "kh", 0x17: "g", 0x18: "gh", 0x19: "ng", 0x1A: "ch", 0x1B: "chh", 0x1C: "j",
              0x1D: "jh", 0x1E: "ny", 0x1F: "t", 0x20: "th", 0x21: "d", 0x22: "dh", 0x23: "n", 0x24: "t",
              0x25: "th", 0x26: "d", 0x27: "dh", 0x28: "n", 0x29: "n", 0x2A: "p", 0x2B: "ph", 0x2C: "b",
              0x2D: "bh", 0x2E: "m", 0x2F: "y", 0x30: "r", 0x31: "r", 0x32: "l", 0x33: "l", 0x34: "zh",
              0x35: "v", 0x36: "sh", 0x37: "sh", 0x38: "s", 0x39: "h",
              # Devanagari precomposed nukta letters
              0x58: "q", 0x59: "kh", 0x5A: "g", 0x5B: "z", 0x5C: "r", 0x5D: "rh", 0x5E: "f", 0x5F: "y"}
SIGNS = {0x01: "n", 0x02: "n", 0x03: "h"}
GURMUKHI_TIPPI = 0x70
DEAD_CONSONANTS = {0x7A: "n", 0x7B: "n", 0x7C: "r", 0x7D: "l", 0x7E: "l", 0x7F: "k"}   # Malayalam chillu letters
NUKTA_OFF, GURMUKHI_ADDAK = 0x3C, 0x71
VIRAMA, NUKTA = 0x4D, 0x3C

HONORIFICS = {"sri", "shri", "shree", "smt", "srimathi", "shrimati", "mr", "mrs", "ms", "dr", "late", "kum", "km"}


def _block(ch: str) -> Optional[int]:
    cp = ord(ch)
    base = cp & ~0x7F
    return base if base in SCRIPTS else None


def detect_script(text: str) -> str:
    for ch in text or "":
        b = _block(ch)
        if b is not None:
            return SCRIPTS[b][0]
    return "Latin"


def transliterate(text: str) -> str:
    """Indian-script text -> simple Latin spelling. Latin text passes through unchanged."""
    if not text:
        return ""
    text = unicodedata.normalize("NFC", text)
    out_words = []
    for word in re.split(r"(\s+)", text):
        if not word.strip():
            out_words.append(word)
            continue
        buf, pending, deletes_schwa, any_indic = [], None, False, False
        for ch in word:
            b = _block(ch)
            if b is None:
                if pending:
                    buf.append(pending + "a")
                    pending = None
                buf.append(ch)
                continue
            any_indic = True
            deletes_schwa = SCRIPTS[b][1]
            off = ord(ch) - b
            if off in CONSONANTS:
                if pending:
                    buf.append(pending + "a")
                pending = CONSONANTS[off]
            elif off in MATRAS:
                buf.append((pending or "") + MATRAS[off])
                pending = None
            elif off == VIRAMA:
                if pending:
                    buf.append(pending)
                pending = None
            elif off == NUKTA_OFF or (b == 0x0A00 and off == GURMUKHI_ADDAK):
                continue
            elif b == 0x0980 and off in (0x70, 0x71):          # Assamese ৰ (ra) and ৱ (wa)
                if pending:
                    buf.append(pending + "a")
                pending = "r" if off == 0x70 else "w"
            elif b == 0x0B00 and off == 0x71:                     # Odia ୱ (wa)
                if pending:
                    buf.append(pending + "a")
                pending = "w"
            elif b == 0x0D00 and off in DEAD_CONSONANTS:
                if pending:
                    buf.append(pending + "a")
                pending = None
                buf.append(DEAD_CONSONANTS[off])
            elif off in VOWELS:
                if pending:
                    buf.append(pending + "a")
                    pending = None
                buf.append(VOWELS[off])
            elif off in SIGNS or (b == 0x0A00 and off == GURMUKHI_TIPPI):
                if pending:
                    buf.append(pending + "a")
                    pending = None
                buf.append(SIGNS.get(off, "n"))
        if pending:
            # Hindi/Marathi etc. drop the final inherent vowel: राम = "raam", not "raama"
            buf.append(pending if (deletes_schwa and any_indic) else pending + "a")
        out_words.append("".join(buf))
    return "".join(out_words)


_REPLACEMENTS = [("nyj", "nj"), ("nyc", "nc"), ("uwa", "ua"), ("ow", "au"), ("ou", "au"), ("chh", "c"), ("ch", "c"), ("sh", "s"), ("ph", "f"), ("bh", "b"), ("dh", "d"), ("th", "t"),
                 ("kh", "k"), ("gh", "g"), ("jh", "j"), ("aa", "a"), ("ee", "i"), ("ii", "i"), ("oo", "u"),
                 ("uu", "u"), ("w", "v"), ("z", "j"), ("q", "k"), ("x", "ks"), ("ck", "k")]
_TOKEN_EQUIV = {"ravu": "rao", "rav": "rao", "nayudu": "naidu", "naydu": "naidu", "reddy": "redi",
                "reddi": "redi", "redy": "redi", "mohammad": "muhamad", "mohammed": "muhamad",
                "mohamed": "muhamad", "mohd": "muhamad", "md": "muhamad",
                "sinh": "sing", "singh": "sing", "sin": "sing", "kaur": "kaur", "nayar": "nair",
                "chaudhary": "caudari", "chowdary": "caudari", "choudhary": "caudari", "chaudhari": "caudari"}


def normalize_token(tok: str) -> str:
    t = tok.lower()
    t = re.sub(r"[^a-z]", "", t)
    if not t:
        return ""
    if t in _TOKEN_EQUIV:
        return _TOKEN_EQUIV[t]
    for a, b in _REPLACEMENTS:
        t = t.replace(a, b)
    t = re.sub(r"y$", "i", t)
    t = re.sub(r"(?<=[aeiou])h$", "", t)       # Baruah = Barua, Shah = Sha
    t = re.sub(r"oi$", "ai", t)                 # Assamese/Bengali ৈ: Gogoi = গগৈ (gagai)
    t = re.sub(r"(.)\1+", r"\1", t)          # collapse doubled letters
    if len(t) > 3 and t.endswith("a"):       # Srinivasa = Srinivas, Subrata = Subrat
        t = t[:-1]
    return _TOKEN_EQUIV.get(t, t)


def normalize_name(name: str) -> List[str]:
    """Any script -> list of phonetic Latin tokens, without honorifics. Initials keep their letter."""
    latin = transliterate(name or "")
    tokens = [t for t in re.split(r"[\s.,]+", latin) if t]
    out = []
    for t in tokens:
        if t.lower().strip(".") in HONORIFICS:
            continue
        n = normalize_token(t)
        if n:
            out.append(n)
    return out


# ---------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------

FEATURES = ["full_similarity", "token_jaccard", "first_token_match", "last_token_match",
            "initials_consistent", "one_contains_other", "token_count_diff", "aligned_token_similarity",
            "same_first_letter", "father_similarity", "consonant_skeleton_similarity"]


def skeleton(tokens: List[str]) -> str:
    """Consonants only (first letter kept): vowels are written very differently across scripts -
    Assamese/Bengali/Odia inherent 'o' vs 'a' (Gogoi / Gagai), long vs short vowels, etc."""
    return " ".join(t[0] + re.sub(r"[aeiou]", "", t[1:]) for t in tokens if t)


def _sim(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio() if a and b else 0.0


def _tok_match(a: str, b: str) -> float:
    if a == b:
        return 1.0
    if len(a) == 1 or len(b) == 1:            # an initial
        return 0.9 if a[0] == b[0] else 0.0
    return _sim(a, b)


def _initials_consistent(A: List[str], B: List[str]) -> float:
    short, long_ = (A, B) if len(A) <= len(B) else (B, A)
    j = 0
    for t in short:
        while j < len(long_) and _tok_match(t, long_[j]) < 0.85:
            j += 1
        if j == len(long_):
            return 0.0
        j += 1
    return 1.0


def features(name_a: str, name_b: str, father_a: str = "", father_b: str = "") -> List[float]:
    A, B = normalize_name(name_a), normalize_name(name_b)
    if not A or not B:
        return [0.0] * len(FEATURES)
    sa, sb = " ".join(A), " ".join(B)
    full = [t for t in A if len(t) > 1], [t for t in B if len(t) > 1]
    jacc = len(set(full[0]) & set(full[1])) / max(1, len(set(full[0]) | set(full[1])))
    short, long_ = (A, B) if len(A) <= len(B) else (B, A)
    aligned = sum(max(_tok_match(t, u) for u in long_) for t in short) / len(short)
    contains = 1.0 if (set(full[0]) <= set(full[1]) or set(full[1]) <= set(full[0])) and full[0] and full[1] else 0.0
    if father_a and father_b:
        fa, fb = " ".join(normalize_name(father_a)), " ".join(normalize_name(father_b))
        fsim = _sim(fa, fb)
    else:
        fsim = 0.5                               # unknown
    return [
        _sim(sa, sb), jacc,
        _tok_match(A[0], B[0]), _tok_match(A[-1], B[-1]),
        _initials_consistent(A, B), contains, float(abs(len(A) - len(B))), aligned,
        1.0 if A[0][0] == B[0][0] else 0.0, fsim, _sim(skeleton(A), skeleton(B)),
    ]


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

_MODEL_CACHE: Dict = {}


def load_model() -> Dict:
    mtime = MODEL_FILE.stat().st_mtime if MODEL_FILE.exists() else None
    if _MODEL_CACHE.get("mtime") != mtime:
        if mtime is None:
            raise FileNotFoundError("models/name_matcher.json missing - run tools/train_name_matcher.py")
        _MODEL_CACHE["model"] = json.loads(MODEL_FILE.read_text(encoding="utf-8"))
        _MODEL_CACHE["mtime"] = mtime
    return _MODEL_CACHE["model"]


REASON_TEXT = {
    "full_similarity": "overall spelling", "token_jaccard": "shared name parts",
    "first_token_match": "first name", "last_token_match": "surname / last name",
    "initials_consistent": "initials line up", "one_contains_other": "one name contains the other",
    "token_count_diff": "different number of name parts", "aligned_token_similarity": "each name part",
    "same_first_letter": "first letter", "father_similarity": "father's name",
    "consonant_skeleton_similarity": "consonant pattern",
}


def match(name_a: str, name_b: str, father_a: str = "", father_b: str = "") -> Dict:
    """Probability that two records name the same person, with human-readable reasons."""
    m = load_model()
    x = features(name_a, name_b, father_a, father_b)
    z = m["intercept"]
    contrib = []
    for i, f in enumerate(FEATURES):
        v = (x[i] - m["mean"][i]) / m["scale"][i]
        c = m["coef"][i] * v
        z += c
        contrib.append((c, f))
    p = 1 / (1 + math.exp(-z))
    exact = " ".join(normalize_name(name_a)) == " ".join(normalize_name(name_b))
    if (name_a or "").strip().lower() == (name_b or "").strip().lower():
        p, verdict = 1.0, "Exact match"
    elif exact:
        p = max(p, 0.97)
        verdict = "Same name in a different script or spelling"
    elif p >= 0.8:
        verdict = "Very likely the same person"
    elif p >= 0.5:
        verdict = "Possibly the same person - officer should confirm"
    else:
        verdict = "Likely different people"
    # Plain-language reasons, read straight from the comparison (not from model weights)
    f = dict(zip(FEATURES, x))
    A, B = normalize_name(name_a), normalize_name(name_b)
    helped, hurt = [], []
    if f["first_token_match"] >= 0.85:
        helped.append("first name matches" if min(len(A[0]), len(B[0])) > 1 else "initial matches the first name")
    elif f["aligned_token_similarity"] < 0.85:
        hurt.append("first names differ")
    if f["last_token_match"] >= 0.85:
        helped.append("surname matches" if min(len(A[-1]), len(B[-1])) > 1 else "initial matches the surname")
    else:
        hurt.append("surnames differ")
    if f["one_contains_other"] and f["token_count_diff"] >= 1:
        helped.append("one record just adds a middle name")
    if f["father_similarity"] >= 0.85 and f["father_similarity"] != 0.5:
        helped.append("father's name matches")
    elif f["father_similarity"] < 0.6 and f["father_similarity"] != 0.5:
        hurt.append("father's names differ")
    if 0.85 <= f["aligned_token_similarity"] < 1 and f["first_token_match"] >= 0.85:
        helped.append("only small spelling differences")
    sa, sb = detect_script(name_a), detect_script(name_b)
    return {
        "probability": round(p, 3),
        "verdict": verdict,
        "agrees_on": helped,
        "differs_on": hurt,
        "scripts": [sa, sb],
        "read_as": [" ".join(normalize_name(name_a)), " ".join(normalize_name(name_b))],
        "transliterated": [transliterate(name_a) if sa != "Latin" else name_a,
                           transliterate(name_b) if sb != "Latin" else name_b],
        "model_version": m.get("version", "?"),
    }
