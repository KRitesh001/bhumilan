"""
engine/ledger.py - tamper-evident audit ledger (SHA-256 hash chain).
Every entry stores the hash of the previous entry, so editing any old entry breaks the chain
from that point on - and verify_chain() shows exactly where.
"""

import hashlib
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

GENESIS_HASH = hashlib.sha256(b"BHUMILAN_GENESIS").hexdigest()


class AuditLedger:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()
        if not self.path.exists():
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._write([{
                "index": 0, "timestamp": datetime.now().isoformat(timespec="seconds"), "action": "GENESIS_BLOCK",
                "location": "INDIA", "parcel_id": "SYSTEM", "officer_id": "BhuMilan", "details": "Ledger initialised",
                "prev_hash": "0" * 64, "block_hash": GENESIS_HASH}])

    def _write(self, entries):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(entries, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(self.path)

    def entries(self) -> List[Dict[str, Any]]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def record(self, action: str, location: str, parcel_id: str, officer: str, details: str) -> Dict[str, Any]:
        with self._lock:
            entries = self.entries()
            entry = {"index": len(entries), "timestamp": datetime.now().isoformat(timespec="seconds"),
                     "action": action, "location": location, "parcel_id": parcel_id, "officer_id": officer,
                     "details": details, "prev_hash": entries[-1]["block_hash"]}
            entry["block_hash"] = hashlib.sha256(json.dumps(entry, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            entries.append(entry)
            self._write(entries)
            return entry

    def verify(self) -> Dict[str, Any]:
        entries = self.entries()
        results, broken_at, prev = [], None, "0" * 64
        for e in entries:
            if e.get("action") == "GENESIS_BLOCK":
                expected = GENESIS_HASH
            else:
                body = {k: v for k, v in e.items() if k != "block_hash"}
                expected = hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            ok_hash, ok_link = expected == e.get("block_hash"), e.get("prev_hash") == prev
            reason = "OK"
            if not ok_hash:
                reason = "Entry was changed after it was written (hash mismatch)"
            elif not ok_link:
                reason = "Link to the previous entry is broken"
            elif broken_at is not None:
                reason = "Comes after a broken entry - cannot be trusted"
            if not (ok_hash and ok_link) and broken_at is None:
                broken_at = e.get("index")
            results.append({"index": e.get("index"), "ok": ok_hash and ok_link and broken_at is None, "reason": reason})
            prev = e.get("block_hash", "")
        return {"valid": broken_at is None, "broken_at": broken_at, "checked": len(entries), "results": results}

    def rewrite_entry(self, index: int, field: str, value: str) -> str:
        """Used only by the admin tamper demo: edits a stored entry WITHOUT fixing its hash."""
        with self._lock:
            entries = self.entries()
            old = entries[index][field]
            entries[index][field] = value
            self._write(entries)
            return old
