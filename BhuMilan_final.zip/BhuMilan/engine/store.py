"""
engine/store.py - where BhuMilan keeps data for every location in India.

data/locations/<LOCATION-ID>/   one folder per city / ULB / tehsil
    manifest.json               what each dataset is, its source department, column mapping, version
    cadastral.geojson           parcel boundaries            (standard fields)
    revenue.csv                 record of rights             (department's own columns + mapping)
    municipal.csv               property tax records         (department's own columns + mapping)
    utilities.geojson           utility lines with easement widths
    gnss_points.csv             DGNSS / CORS ground-truth points (optional)
    imagery/<parcel>/           georeferenced ORI per survey year + meta.json
    surface/<parcel>.npz        DSM / DTM height grids
data/state/                     runtime state: officer decisions, audit ledger
data/training/                  officer-labelled name pairs used to retrain the matcher
"""

import csv
import io
import json
import re
import shutil
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from engine import ingest

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
LOCS = DATA / "locations"
STATE = DATA / "state"
TRAINING = DATA / "training"
_lock = threading.RLock()

# States and Union Territories: (name, short code, LGD / Census-2011 state code, main script, capital lat/lon)
STATES = [
    ("Andhra Pradesh", "AP", 28, "Telugu", (16.51, 80.52)), ("Arunachal Pradesh", "AR", 12, "Latin", (27.10, 93.62)),
    ("Assam", "AS", 18, "Bengali-Assamese", (26.14, 91.79)), ("Bihar", "BR", 10, "Devanagari", (25.59, 85.14)),
    ("Chhattisgarh", "CG", 22, "Devanagari", (21.25, 81.63)), ("Goa", "GA", 30, "Devanagari", (15.49, 73.83)),
    ("Gujarat", "GJ", 24, "Gujarati", (23.22, 72.65)), ("Haryana", "HR", 6, "Devanagari", (30.73, 76.78)),
    ("Himachal Pradesh", "HP", 2, "Devanagari", (31.10, 77.17)), ("Jharkhand", "JH", 20, "Devanagari", (23.34, 85.31)),
    ("Karnataka", "KA", 29, "Kannada", (12.97, 77.59)), ("Kerala", "KL", 32, "Malayalam", (8.52, 76.94)),
    ("Madhya Pradesh", "MP", 23, "Devanagari", (23.26, 77.41)), ("Maharashtra", "MH", 27, "Devanagari", (19.08, 72.88)),
    ("Manipur", "MN", 14, "Bengali-Assamese", (24.82, 93.94)), ("Meghalaya", "ML", 17, "Latin", (25.58, 91.89)),
    ("Mizoram", "MZ", 15, "Latin", (23.73, 92.72)), ("Nagaland", "NL", 13, "Latin", (25.67, 94.11)),
    ("Odisha", "OD", 21, "Odia", (20.30, 85.82)), ("Punjab", "PB", 3, "Gurmukhi", (30.73, 76.78)),
    ("Rajasthan", "RJ", 8, "Devanagari", (26.91, 75.79)), ("Sikkim", "SK", 11, "Devanagari", (27.33, 88.61)),
    ("Tamil Nadu", "TN", 33, "Tamil", (13.08, 80.27)), ("Telangana", "TG", 36, "Telugu", (17.39, 78.49)),
    ("Tripura", "TR", 16, "Bengali-Assamese", (23.83, 91.28)), ("Uttar Pradesh", "UP", 9, "Devanagari", (26.85, 80.95)),
    ("Uttarakhand", "UK", 5, "Devanagari", (30.32, 78.03)), ("West Bengal", "WB", 19, "Bengali-Assamese", (22.57, 88.36)),
    ("Andaman and Nicobar Islands", "AN", 35, "Latin", (11.62, 92.73)), ("Chandigarh", "CH", 4, "Latin", (30.73, 76.78)),
    ("Dadra and Nagar Haveli and Daman and Diu", "DH", 38, "Gujarati", (20.40, 72.83)),
    ("Delhi", "DL", 7, "Devanagari", (28.61, 77.21)), ("Jammu and Kashmir", "JK", 1, "Latin", (34.08, 74.80)),
    ("Ladakh", "LA", 37, "Latin", (34.15, 77.58)), ("Lakshadweep", "LD", 31, "Malayalam", (10.57, 72.64)),
    ("Puducherry", "PY", 34, "Tamil", (11.94, 79.81)),
]
STATE_BY_NAME = {s[0]: s for s in STATES}


def list_locations() -> List[Dict[str, Any]]:
    out = []
    if LOCS.exists():
        for d in sorted(LOCS.iterdir()):
            m = d / "manifest.json"
            if m.exists():
                out.append(json.loads(m.read_text(encoding="utf-8")))
    return out


def manifest(loc: str) -> Dict[str, Any]:
    f = LOCS / loc / "manifest.json"
    if not re.fullmatch(r"[A-Z]{2}-[A-Z0-9]{2,8}", loc or "") or not f.exists():
        raise KeyError(f"Unknown location {loc}")
    return json.loads(f.read_text(encoding="utf-8"))


def save_manifest(loc: str, m: Dict[str, Any]):
    (LOCS / loc / "manifest.json").write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")


def dataset_entry(m, dtype) -> Optional[Dict[str, Any]]:
    return next((d for d in m["datasets"] if d["type"] == dtype), None)


def signature(loc: str) -> str:
    """Changes whenever any input of the location changes (used for caching results)."""
    base = LOCS / loc
    parts = []
    for f in sorted(base.glob("*.*")):
        parts.append(f"{f.name}:{f.stat().st_mtime_ns}")
    dec = STATE / "decisions" / f"{loc}.json"
    if dec.exists():
        parts.append(f"dec:{dec.stat().st_mtime_ns}")
    model = ROOT / "models" / "name_matcher.json"
    if model.exists():
        parts.append(f"model:{model.stat().st_mtime_ns}")
    return "|".join(parts)


# ---------------------------------------------------------------------------
# Loading datasets in the standard schema
# ---------------------------------------------------------------------------

def _read_table(path: Path, entry: Dict, state: str) -> List[Dict[str, Any]]:
    raw = path.read_bytes()
    parsed = ingest.read_csv(raw)
    mapping = entry.get("mapping") or {c: c for c in parsed["columns"]}
    unit_factor = None
    if entry.get("area_unit"):
        u = entry["area_unit"]
        unit_factor = ingest.BIGHA_M2_BY_STATE.get(state) if u.startswith("bigha") else ingest.UNIT_M2.get(u)
    rows = []
    for r in parsed["rows"]:
        rec = {}
        for col, val in r.items():
            f = mapping.get(col)
            if f:
                rec[f] = (val or "").strip()
        for f in ("area", "built_up_area"):
            if f in rec and f + "_sq_m" not in rec:
                try:
                    v = float(rec[f].replace(",", ""))
                    rec[f + "_sq_m"] = round(v * (unit_factor or 1.0), 2)
                except ValueError:
                    rec[f + "_sq_m"] = None
        rows.append(rec)
    return rows


def load_location(loc: str) -> Dict[str, Any]:
    m = manifest(loc)
    base = LOCS / loc
    out = {"manifest": m, "cadastral": [], "revenue": [], "municipal": [], "utilities": [], "gnss": []}
    e = dataset_entry(m, "cadastral")
    if e:
        gj = json.loads((base / e["file"]).read_text(encoding="utf-8"))
        for i, f in enumerate(gj["features"], start=1):
            p = f["properties"]
            ring = f["geometry"]["coordinates"][0]
            poly = [(lat, lon) for lon, lat in ring]
            if poly[0] == poly[-1]:
                poly = poly[:-1]
            out["cadastral"].append({"parcel_id": p.get("parcel_id") or f"{loc}-{i:03d}",
                                     "survey_number": str(p.get("survey_number", "")), "village": p.get("village", ""),
                                     "polygon": poly, "props": p})
    for dtype in ("revenue", "municipal"):
        e = dataset_entry(m, dtype)
        if e:
            out[dtype] = _read_table(base / e["file"], e, m["state"])
    e = dataset_entry(m, "utilities")
    if e:
        gj = json.loads((base / e["file"]).read_text(encoding="utf-8"))
        for f in gj["features"]:
            p = f["properties"]
            out["utilities"].append({"id": p.get("id"), "name": p.get("name"), "type": p.get("type"),
                                     "buffer_m": float(p.get("buffer_m") or 3.0),
                                     "line": [(lat, lon) for lon, lat in f["geometry"]["coordinates"]]})
    e = dataset_entry(m, "gnss")
    if e:
        for r in csv.DictReader(io.StringIO((base / e["file"]).read_text(encoding="utf-8-sig"))):
            try:
                out["gnss"].append({"point_id": r.get("point_id"), "lat": float(r.get("latitude") or r.get("lat")),
                                    "lon": float(r.get("longitude") or r.get("lon")),
                                    "accuracy_m": float(r.get("horizontal_accuracy_m") or 0.05),
                                    "method": r.get("method", ""), "date": r.get("survey_date", "")})
            except (TypeError, ValueError):
                continue
    return out


# ---------------------------------------------------------------------------
# Officer decisions (per location)
# ---------------------------------------------------------------------------

def load_decisions(loc: str) -> Dict[str, Any]:
    f = STATE / "decisions" / f"{loc}.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}


def save_decisions(loc: str, d: Dict[str, Any]):
    f = STATE / "decisions" / f"{loc}.json"
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


def reset_decisions(loc: Optional[str] = None):
    d = STATE / "decisions"
    if not d.exists():
        return
    for f in d.glob("*.json"):
        if loc is None or f.stem == loc:
            f.unlink()


def add_officer_label(name_a, name_b, father_a, father_b, same: bool, officer: str, loc: str, pid: str):
    TRAINING.mkdir(parents=True, exist_ok=True)
    f = TRAINING / "officer_labels.csv"
    new = not f.exists()
    with open(f, "a", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        if new:
            w.writerow(["name_a", "name_b", "father_a", "father_b", "same_person", "officer", "location", "parcel_id", "at"])
        w.writerow([name_a, name_b, father_a, father_b, 1 if same else 0, officer, loc, pid,
                    datetime.now().isoformat(timespec="seconds")])


def count_officer_labels() -> int:
    f = TRAINING / "officer_labels.csv"
    if not f.exists():
        return 0
    return max(0, sum(1 for _ in open(f, encoding="utf-8")) - 1)


# ---------------------------------------------------------------------------
# New locations and uploads
# ---------------------------------------------------------------------------

def create_location(state: str, district: str, city: str, ulb: str = "") -> Dict[str, Any]:
    if state not in STATE_BY_NAME:
        raise ValueError("Unknown state / UT")
    abbr = STATE_BY_NAME[state][1]
    code = re.sub(r"[^A-Z]", "", city.upper())[:3] or "LOC"
    loc = f"{abbr}-{code}"
    n = 2
    while (LOCS / loc).exists():
        loc = f"{abbr}-{code[:2]}{n}"
        n += 1
    (LOCS / loc).mkdir(parents=True)
    center = STATE_BY_NAME[state][4]
    m = {"id": loc, "city": city.strip(), "district": district.strip(), "state": state,
         "state_code_lgd": STATE_BY_NAME[state][2], "urban_local_body": ulb.strip(), "center": list(center),
         "utm_epsg": None, "synthetic": False, "datasets": [], "created": datetime.now().isoformat(timespec="seconds")}
    save_manifest(loc, m)
    return m


def save_upload(loc: str, dtype: str, filename: str, raw: bytes, std: Dict[str, Any], mapping: Dict[str, str],
                units: Dict[str, float], officer: str) -> Dict[str, Any]:
    """Keeps the original file for audit and writes the standardised dataset."""
    with _lock:
        m = manifest(loc)
        base = LOCS / loc
        up = base / "uploads"
        up.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        safe = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[-60:]
        (up / f"{stamp}_{safe}").write_bytes(raw)
        recs = std["records"]
        if dtype in ("cadastral", "utilities"):
            feats = []
            for i, r in enumerate(recs, start=1):
                g = r["__geometry"]
                props = {k: v for k, v in r.items() if not k.startswith("__")}
                if dtype == "cadastral":
                    props.setdefault("parcel_id", "")
                    if not props["parcel_id"]:
                        props["parcel_id"] = f"{loc}-{i:03d}"
                    coords = [[lon, lat] for lat, lon in g] + [[g[0][1], g[0][0]]]
                    geom = {"type": "Polygon", "coordinates": [coords]}
                else:
                    props["buffer_m"] = float(props.get("buffer_m") or 3.0)
                    props.setdefault("id", f"UTIL-{i:02d}")
                    geom = {"type": "LineString", "coordinates": [[lon, lat] for lat, lon in g]}
                feats.append({"type": "Feature", "properties": props, "geometry": geom})
            fname = f"{dtype}.geojson"
            (base / fname).write_text(json.dumps({"type": "FeatureCollection", "features": feats}, ensure_ascii=False),
                                      encoding="utf-8")
            entry = {"type": dtype, "file": fname, "format": "GeoJSON", "crs": "EPSG:4326"}
            if dtype == "cadastral" and recs:
                from engine.geo import centroid_latlon, utm_epsg
                allpts = [p for r in recs for p in r["__geometry"]]
                c = centroid_latlon(allpts)
                m["center"] = [c[0], c[1]]
                m["utm_epsg"] = utm_epsg(c[0], c[1])
        else:
            fname = "gnss_points.csv" if dtype == "gnss" else f"{dtype}.csv"
            fields = ingest.SCHEMAS[dtype]["fields"] + [f + "_sq_m" for f in ("area", "built_up_area")
                                                        if f in ingest.SCHEMAS[dtype]["fields"]]
            if dtype == "gnss":
                fields = ["point_id", "latitude", "longitude", "horizontal_accuracy_m", "method", "surveyor", "survey_date"]
            with open(base / fname, "w", newline="", encoding="utf-8-sig") as fh:
                w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
                w.writeheader()
                for r in recs:
                    row = dict(r)
                    if dtype == "gnss":
                        row["latitude"], row["longitude"] = r.get("lat"), r.get("lon")
                    w.writerow(row)
            entry = {"type": dtype, "file": fname, "format": "CSV"}
            if dtype != "gnss":
                entry["mapping"] = {f: f for f in fields}
        old = dataset_entry(m, dtype)
        entry.update({"source": std.get("source") or (old or {}).get("source") or ingest.SCHEMAS[dtype]["label"],
                      "original_file": f"uploads/{stamp}_{safe}", "original_mapping": mapping,
                      "units": {k: v for k, v in units.items() if v}, "crs_detected": std["crs"].get("label"),
                      "uploaded_by": officer, "uploaded_at": datetime.now().isoformat(timespec="seconds"),
                      "version": (old or {}).get("version", 0) + 1, "rows": len(recs)})
        m["datasets"] = [d for d in m["datasets"] if d["type"] != dtype] + [entry]
        save_manifest(loc, m)
        return entry


def delete_location(loc: str):
    manifest(loc)
    shutil.rmtree(LOCS / loc)
    reset_decisions(loc)
