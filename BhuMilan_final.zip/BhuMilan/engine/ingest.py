"""
engine/ingest.py - ETL for department uploads (any state, any department).

Formats  : GeoJSON, KML, CSV (any delimiter / encoding), zipped Shapefile (.shp .shx .dbf .prj)
CRS      : detected from the file (.prj / crs member / EPSG text) or from the coordinate values,
           converted to WGS84 (engine/geo.py - all Indian UTM zones)
Schema   : suggests how each column maps to BhuMilan's standard schema, using header synonyms in
           English, Hindi and Telugu plus checks on the values; the officer confirms the mapping
Units    : sq.m, sq.ft, sq.yd / gaj, acre, cent, hectare, guntha, kanal, marla, state-specific bigha
Pure Python - no GDAL / Fiona needed.
"""

import csv
import io
import json
import re
import struct
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

from engine import geo

# ---------------------------------------------------------------------------
# Standard schema
# ---------------------------------------------------------------------------

SCHEMAS = {
    "cadastral": {"label": "Cadastral map (parcel boundaries)", "geometry": "polygon",
                  "required": ["survey_number"],
                  "fields": ["parcel_id", "survey_number", "village"]},
    "revenue": {"label": "Revenue records (record of rights)", "geometry": None,
                "required": ["survey_number", "owner_name"],
                "fields": ["survey_number", "owner_name", "father_name", "village", "khata_number", "area",
                           "land_use", "document_type", "registration_date"]},
    "municipal": {"label": "Municipal property records", "geometry": "point",
                  "required": ["owner_name", "lat", "lon"],
                  "fields": ["assessment_number", "owner_name", "father_name", "ward", "lat", "lon",
                             "built_up_area", "floors", "usage"]},
    "gnss": {"label": "GNSS / CORS survey points (ground truth)", "geometry": "point",
             "required": ["lat", "lon"],
             "fields": ["point_id", "lat", "lon", "horizontal_accuracy_m", "method", "surveyor", "survey_date"]},
    "utilities": {"label": "Utility network (water, power, sewer, gas)", "geometry": "line",
                  "required": [], "fields": ["id", "name", "type", "buffer_m"]},
}

SYNONYMS = {
    "parcel_id": ["parcel_id", "parcel", "ulpin", "bhu_aadhaar", "unique_id", "pid"],
    "survey_number": ["survey_no", "survey_number", "sy_no", "syno", "s_no", "khasra", "khasra_no", "khasra_number",
                      "gat_no", "gat", "dag_no", "dag", "plot_no", "plot", "cts_no", "city_survey_no", "chalta_no",
                      "खसरा", "खसरा_नंबर", "खसरा_संख्या", "गट_क्रमांक", "सर्वे_नंबर", "సర్వే_నం", "సర్వే_నంబర్"],
    "owner_name": ["owner", "owner_name", "ownername", "landholder", "land_holder", "pattadar", "pattadar_name",
                   "khatedar", "khatedar_name", "occupant", "occupant_name", "tenant", "tenant_name", "holder",
                   "raiyat", "name_of_owner", "खातेदार", "खातेदार_का_नाम", "मालिक", "मालिक_का_नाम", "भूस्वामी",
                   "पट्टेदार", "పట్టాదారు", "పట్టాదారు_పేరు", "యజమాని", "యజమాని_పేరు"],
    "father_name": ["father", "father_name", "fathername", "guardian", "guardian_name", "father_husband_name",
                    "husband_father_name", "relative_name", "s_o", "पिता", "पिता_का_नाम", "पिता_पति_का_नाम",
                    "తండ్రి", "తండ్రి_పేరు"],
    "village": ["village", "mouza", "mauza", "gram", "revenue_village", "locality", "गांव", "ग्राम", "मौजा",
                "గ్రామం"],
    "khata_number": ["khata", "khata_no", "khata_number", "patta_no", "patta", "khatauni", "account_no",
                     "खाता", "खाता_संख्या", "खाता_नंबर", "ఖాతా_నం"],
    "area": ["area", "extent", "area_ha", "area_hectare", "extent_acres", "area_acre", "area_bigha", "land_area",
             "क्षेत्रफल", "क्षेत्रफल_हेक्टेयर", "रकबा", "విస్తీర్ణం"],
    "land_use": ["land_use", "land_classification", "kisam", "land_class", "land_type", "classification",
                 "भूमि_प्रकार", "भूमि_का_प्रकार", "భూమి_రకం"],
    "document_type": ["document", "document_type", "deed", "deed_type", "transfer_type", "दस्तावेज़", "दस्तावेज",
                      "దస్తావేజు"],
    "registration_date": ["reg_date", "registration_date", "date_of_registration", "deed_date", "date",
                          "पंजीकरण_तिथि", "रजिस्ट्री_तिथि", "నమోదు_తేదీ"],
    "assessment_number": ["assessment_no", "assessment_number", "property_id", "propertyid", "property_no",
                          "holding_no", "holding_number", "house_no", "door_no", "upic", "ptin", "pid_no"],
    "ward": ["ward", "ward_no", "zone", "circle", "division"],
    "lat": ["lat", "latitude", "y", "y_coord", "northing", "gps_lat"],
    "lon": ["lon", "long", "lng", "longitude", "x", "x_coord", "easting", "gps_lon", "gps_long"],
    "built_up_area": ["built_up", "builtup", "built_up_area", "builtuparea", "plinth_area", "carpet_area",
                      "floor_area", "constructed_area"],
    "floors": ["floors", "no_of_floors", "storeys", "floor_count", "number_of_floors", "stories"],
    "usage": ["usage", "usage_type", "use", "usetype", "use_type", "property_use", "occupancy"],
    "point_id": ["point_id", "point", "pt_id", "station", "name", "id"],
    "horizontal_accuracy_m": ["horizontal_accuracy_m", "accuracy", "h_acc", "hacc", "precision", "rms"],
    "method": ["method", "survey_method", "instrument", "equipment"],
    "surveyor": ["surveyor", "surveyed_by", "operator"],
    "survey_date": ["survey_date", "date", "observed_on"],
    "id": ["id", "asset_id", "line_id"],
    "name": ["name", "asset_name", "description"],
    "type": ["type", "asset_type", "utility_type", "category"],
    "buffer_m": ["buffer_m", "buffer", "easement", "easement_m", "row_m", "right_of_way"],
}

# area units -> square metres. Bigha differs by state, so it is looked up per state.
UNIT_M2 = {"sq_m": 1.0, "sq_ft": 0.09290304, "sq_yd": 0.83612736, "acre": 4046.8564, "cent": 40.468564,
           "hectare": 10000.0, "guntha": 101.17141, "kanal": 505.857, "marla": 25.2929}
BIGHA_M2_BY_STATE = {"Assam": 1337.8, "West Bengal": 1337.8, "Tripura": 1337.8, "Rajasthan": 2529.3,
                     "Uttar Pradesh": 2529.3, "Bihar": 2529.3, "Himachal Pradesh": 836.1, "Punjab": 836.1,
                     "Haryana": 836.1}
UTILITY_BUFFER_M = {"power": 4.0, "electric": 4.0, "water": 3.0, "sewer": 3.0, "gas": 6.0, "pipeline": 6.0,
                    "telecom": 1.5, "fibre": 1.5, "fiber": 1.5, "drain": 2.0}


def norm_header(h: str) -> str:
    h = unicodedata.normalize("NFC", str(h or "")).strip().lower()
    h = re.sub(r"[\s./\\\-()]+", "_", h)
    return re.sub(r"_+", "_", h).strip("_")


def detect_unit(header: str, state: str = "") -> Optional[Tuple[str, float]]:
    h = norm_header(header)
    tokens = set(h.split("_"))
    checks = [("bigha", ("bigha", "बीघा")), ("sq_yd", ("sqyd", "sqyard", "sqyards", "gaj", "गज", "yd", "yard", "yards")),
              ("sq_ft", ("sqft", "sft", "ft", "feet")), ("sq_m", ("sqm", "sqmt", "sqmtr", "m2", "मीटर")),
              ("hectare", ("hectare", "hectares", "ha", "हेक्टेयर")), ("acre", ("acre", "acres", "ac", "एकड़", "ఎకరా")),
              ("cent", ("cent", "cents")), ("guntha", ("guntha", "gunta", "गुंठा")), ("kanal", ("kanal",)),
              ("marla", ("marla",))]
    compact = h.replace("_", "")
    for unit, keys in checks:
        hit = any(k in tokens for k in keys) or any(len(k) >= 4 and k in compact for k in keys)
        if unit == "sq_ft" and not hit:
            hit = "sqft" in compact or "squarefeet" in compact
        if unit == "sq_yd" and not hit:
            hit = "sqyd" in compact or "squareyard" in compact
        if unit == "sq_m" and not hit:
            hit = "sqm" in compact or "squaremet" in compact
        if hit:
            if unit == "bigha":
                f = BIGHA_M2_BY_STATE.get(state)
                return ("bigha", f) if f else ("bigha (size depends on state - please confirm)", None)
            return unit, UNIT_M2[unit]
    return None


# ---------------------------------------------------------------------------
# Readers
# ---------------------------------------------------------------------------

def _decode(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            txt = data.decode(enc)
            if enc == "utf-16" and "\x00" in txt[:50]:
                continue
            return txt
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def read_csv(data: bytes) -> Dict[str, Any]:
    text = _decode(data)
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    rows = list(csv.DictReader(io.StringIO(text), dialect=dialect))
    cols = list(rows[0].keys()) if rows else []
    return {"kind": "table", "columns": cols, "rows": rows, "crs_hint": None}


def _geom_parts(g):
    t = g.get("type")
    c = g.get("coordinates")
    if t == "Polygon":
        return "polygon", [c[0]]
    if t == "MultiPolygon":
        return "polygon", [max((p[0] for p in c), key=len)]
    if t == "LineString":
        return "line", [c]
    if t == "MultiLineString":
        return "line", list(c)
    if t == "Point":
        return "point", [[c]]
    return None, []


def read_geojson(data: bytes) -> Dict[str, Any]:
    gj = json.loads(_decode(data))
    feats = gj.get("features") or ([gj] if gj.get("type") == "Feature" else [])
    crs_hint = None
    if isinstance(gj.get("crs"), dict):
        crs_hint = geo.parse_crs_hint(json.dumps(gj["crs"]))
    rows, cols = [], []
    for f in feats:
        props = dict(f.get("properties") or {})
        kind, parts = _geom_parts(f.get("geometry") or {})
        props["__geom_kind"], props["__coords"] = kind, parts[0] if parts else None
        for k in props:
            if not k.startswith("__") and k not in cols:
                cols.append(k)
        rows.append(props)
    return {"kind": "features", "columns": cols, "rows": rows, "crs_hint": crs_hint}


def read_kml(data: bytes) -> Dict[str, Any]:
    root = ET.fromstring(data)
    ns = "{http://www.opengis.net/kml/2.2}"
    if not root.tag.startswith(ns):
        ns = root.tag.split("}")[0] + "}" if root.tag.startswith("{") else ""
    rows, cols = [], []

    def coords(txt):
        pts = []
        for tok in (txt or "").split():
            v = tok.split(",")
            if len(v) >= 2:
                pts.append([float(v[0]), float(v[1])])
        return pts

    for pm in root.iter(f"{ns}Placemark"):
        props = {}
        name = pm.find(f"{ns}name")
        if name is not None and name.text:
            props["name"] = name.text.strip()
        for d in pm.iter(f"{ns}Data"):
            v = d.find(f"{ns}value")
            props[d.get("name")] = v.text if v is not None else ""
        for d in pm.iter(f"{ns}SimpleData"):
            props[d.get("name")] = d.text or ""
        poly = pm.find(f".//{ns}Polygon//{ns}outerBoundaryIs//{ns}coordinates")
        line = pm.find(f".//{ns}LineString/{ns}coordinates")
        point = pm.find(f".//{ns}Point/{ns}coordinates")
        if poly is not None:
            props["__geom_kind"], props["__coords"] = "polygon", coords(poly.text)
        elif line is not None:
            props["__geom_kind"], props["__coords"] = "line", coords(line.text)
        elif point is not None:
            props["__geom_kind"], props["__coords"] = "point", coords(point.text)
        for k in props:
            if not k.startswith("__") and k not in cols:
                cols.append(k)
        rows.append(props)
    return {"kind": "features", "columns": cols, "rows": rows,
            "crs_hint": {"kind": "geographic", "epsg": 4326, "label": "WGS84 (KML is always WGS84)"}}


def _read_dbf(data: bytes) -> Tuple[List[str], List[Dict[str, str]]]:
    n_rec, hdr_len, rec_len = struct.unpack("<xxxxIHH", data[:12])
    fields, pos = [], 32
    while pos < hdr_len - 1 and data[pos] != 0x0D:
        name = data[pos:pos + 11].split(b"\x00")[0].decode("latin-1")
        ftype, flen = chr(data[pos + 11]), data[pos + 16]
        fields.append((name, ftype, flen))
        pos += 32
    rows = []
    for r in range(n_rec):
        off = hdr_len + r * rec_len
        rec = data[off:off + rec_len]
        if not rec or rec[:1] == b"*":
            continue
        p, row = 1, {}
        for name, ftype, flen in fields:
            raw = rec[p:p + flen]
            try:
                val = raw.decode("utf-8").strip()
            except UnicodeDecodeError:
                val = raw.decode("latin-1").strip()
            row[name] = val
            p += flen
        rows.append(row)
    return [f[0] for f in fields], rows


def _read_shp(data: bytes) -> List[Tuple[Optional[str], Optional[list]]]:
    out, pos = [], 100
    while pos + 8 <= len(data):
        _, clen = struct.unpack(">ii", data[pos:pos + 8])
        content = data[pos + 8:pos + 8 + clen * 2]
        pos += 8 + clen * 2
        stype = struct.unpack("<i", content[:4])[0] if len(content) >= 4 else 0
        if stype in (1, 11, 21):
            x, y = struct.unpack("<dd", content[4:20])
            out.append(("point", [[x, y]]))
        elif stype in (3, 13, 23, 5, 15, 25):
            nparts, npts = struct.unpack("<ii", content[36:44])
            parts = list(struct.unpack(f"<{nparts}i", content[44:44 + 4 * nparts]))
            base = 44 + 4 * nparts
            pts = [list(struct.unpack("<dd", content[base + 16 * i: base + 16 * i + 16])) for i in range(npts)]
            parts.append(npts)
            rings = [pts[parts[i]:parts[i + 1]] for i in range(nparts)]
            kind = "polygon" if stype in (5, 15, 25) else "line"
            out.append((kind, max(rings, key=len) if rings else []))
        else:
            out.append((None, None))
    return out


def read_shapefile_zip(data: bytes) -> Dict[str, Any]:
    z = zipfile.ZipFile(io.BytesIO(data))
    names = {n.lower(): n for n in z.namelist()}
    shp = next((names[n] for n in names if n.endswith(".shp")), None)
    if not shp:
        raise ValueError("The zip file has no .shp file inside")
    base = shp[:-4]
    dbf = next((names[n] for n in names if n == (base + ".dbf").lower()), None)
    prj = next((names[n] for n in names if n == (base + ".prj").lower()), None)
    geoms = _read_shp(z.read(shp))
    cols, attrs = _read_dbf(z.read(dbf)) if dbf else ([], [{} for _ in geoms])
    rows = []
    for (kind, coords), a in zip(geoms, attrs):
        r = dict(a)
        r["__geom_kind"], r["__coords"] = kind, coords
        rows.append(r)
    hint = geo.parse_crs_hint(z.read(prj).decode("latin-1")) if prj else None
    return {"kind": "features", "columns": cols, "rows": rows, "crs_hint": hint}


def read_any(filename: str, data: bytes) -> Dict[str, Any]:
    name = filename.lower()
    if name.endswith((".geojson", ".json")):
        out = read_geojson(data)
        fmt = "GeoJSON"
    elif name.endswith(".kml"):
        out = read_kml(data)
        fmt = "KML"
    elif name.endswith(".zip"):
        out = read_shapefile_zip(data)
        fmt = "Shapefile (zipped)"
    elif name.endswith((".csv", ".txt", ".tsv")):
        out = read_csv(data)
        fmt = "CSV"
    else:
        raise ValueError("Unsupported file type. Use GeoJSON, KML, CSV or a zipped Shapefile.")
    out["format"] = fmt
    return out


# ---------------------------------------------------------------------------
# Column mapping suggestions
# ---------------------------------------------------------------------------

def _numeric_share(values) -> float:
    vals = [v for v in values if str(v).strip() != ""]
    if not vals:
        return 0.0
    ok = 0
    for v in vals:
        try:
            float(str(v).replace(",", ""))
            ok += 1
        except ValueError:
            pass
    return ok / len(vals)


def suggest_mapping(dataset_type: str, columns: List[str], rows: List[Dict], state: str = "") -> List[Dict]:
    fields = SCHEMAS[dataset_type]["fields"]
    cands = []
    for col in columns:
        h = norm_header(col)
        h_nounit = re.sub(r"_(sq_?ft|sq_?yd|sq_?m|sqmt|acres?|ac|ha|hectare|bigha|gaj|cents?|guntha|कें|हेक्टेयर)$", "", h)
        values = [r.get(col, "") for r in rows[:50]]
        for f in fields:
            best, why = 0.0, ""
            for syn in SYNONYMS.get(f, [f]):
                if h == syn or h_nounit == syn:
                    best, why = 1.0, f"header '{col}' is a known name for {f.replace('_', ' ')}"
                    break
                r = SequenceMatcher(None, h_nounit, syn).ratio()
                if syn in h and len(syn) >= 4:
                    r = max(r, 0.86)
                if r > best:
                    best, why = r, f"header looks like '{syn}'"
            # value checks
            ns = _numeric_share(values)
            if f in ("lat", "lon", "floors", "area", "built_up_area", "buffer_m", "horizontal_accuracy_m") and ns < 0.8:
                best *= 0.4
            if f == "lat" and ns >= 0.8:
                try:
                    v = float(str(next(x for x in values if str(x).strip())).replace(",", ""))
                    if 6 <= v <= 37.5:
                        best, why = max(best, 0.7), why or "values look like latitudes in India"
                except (StopIteration, ValueError):
                    pass
            if f == "owner_name" and ns > 0.5:
                best *= 0.3
            if best >= 0.62:
                cands.append((best, col, f, why))
    cands.sort(reverse=True)
    used_c, used_f, mapping = set(), set(), {}
    for score, col, f, why in cands:
        if col in used_c or f in used_f:
            continue
        used_c.add(col)
        used_f.add(f)
        mapping[col] = (f, score, why)
    out = []
    for col in columns:
        f, score, why = mapping.get(col, (None, 0.0, "no matching field - will be kept as extra information"))
        unit = detect_unit(col, state) if f in ("area", "built_up_area") else None
        out.append({"column": col, "field": f, "confidence": round(score, 2), "reason": why,
                    "unit": unit[0] if unit else None, "unit_m2": unit[1] if unit else None,
                    "sample": str(rows[0].get(col, ""))[:40] if rows else ""})
    return out


# ---------------------------------------------------------------------------
# Standardise + validate
# ---------------------------------------------------------------------------

def _num(v) -> Optional[float]:
    try:
        return float(str(v).replace(",", "").strip())
    except (ValueError, AttributeError):
        return None


def standardise(dataset_type: str, parsed: Dict, mapping: Dict[str, str], units: Dict[str, float],
                location_center: Optional[Tuple[float, float]] = None) -> Dict[str, Any]:
    """Applies the confirmed mapping, converts units and coordinates. Returns records + a validation report."""
    schema = SCHEMAS[dataset_type]
    inv = {f: c for c, f in mapping.items() if f}
    rows = parsed["rows"]
    report = {"rows_in": len(rows), "rows_ok": 0, "problems": [], "crs": None, "units": {}}

    # CRS
    xs, ys = [], []
    for r in rows[:30]:
        if r.get("__coords"):
            xs.append(r["__coords"][0][0])
            ys.append(r["__coords"][0][1])
        elif "lat" in inv and "lon" in inv:
            la, lo = _num(r.get(inv["lat"])), _num(r.get(inv["lon"]))
            if la is not None and lo is not None:
                xs.append(lo)
                ys.append(la)
    lonlat_center = (location_center[1], location_center[0]) if location_center else None
    crs = geo.guess_crs(xs, ys, parsed.get("crs_hint"), lonlat_center)
    report["crs"] = crs["label"]
    if crs["kind"] == "unknown" and xs:
        report["problems"].append("Coordinate system not recognised - add a .prj file or EPSG code")

    for f, factor in units.items():
        if factor:
            report["units"][f] = f"converted to sq.m (x {factor:g})"

    out, seen = [], set()
    for i, r in enumerate(rows, start=1):
        rec = {f: (str(r.get(c, "")).strip() if r.get(c) is not None else "") for f, c in inv.items()}
        for f in ("area", "built_up_area"):
            if f in rec and units.get(f):
                v = _num(rec[f])
                rec[f + "_sq_m"] = round(v * units[f], 2) if v is not None else None
        missing = [f for f in schema["required"] if not rec.get(f)]
        geom = None
        if schema["geometry"] in ("polygon", "line") or (schema["geometry"] == "point" and r.get("__coords")):
            coords = r.get("__coords")
            if not coords:
                report["problems"].append(f"Row {i}: no geometry")
                continue
            try:
                ll = [geo.to_lonlat(x, y, crs) for x, y in coords]
            except ValueError as e:
                report["problems"].append(f"Row {i}: {e}")
                continue
            if schema["geometry"] == "polygon":
                ring = [(lat, lon) for lon, lat in ll]
                if len(ring) > 1 and ring[0] == ring[-1]:
                    ring = ring[:-1]
                if len(ring) < 3 or not geo.is_simple_polygon(ring):
                    report["problems"].append(f"Row {i}: boundary crosses itself or has < 3 corners")
                    continue
                geom = ring
            elif schema["geometry"] == "line":
                geom = [(lat, lon) for lon, lat in ll]
            else:
                rec["lon"], rec["lat"] = ll[0]
        elif schema["geometry"] == "point":
            la, lo = _num(rec.get("lat")), _num(rec.get("lon"))
            if la is None or lo is None:
                report["problems"].append(f"Row {i}: latitude/longitude missing")
                continue
            lon, lat = geo.to_lonlat(lo, la, crs) if crs["kind"] in ("utm", "geographic_swapped") else (lo, la)
            rec["lat"], rec["lon"] = lat, lon
        if missing:
            report["problems"].append(f"Row {i}: missing {', '.join(missing)}")
            continue
        if geom is not None:
            rec["__geometry"] = geom
            c = geo.centroid_latlon(geom)
            if not (6 <= c[0] <= 37.5 and 68 <= c[1] <= 97.5):
                report["problems"].append(f"Row {i}: location is outside India - check the coordinate system")
        key = rec.get("survey_number") or rec.get("assessment_number") or rec.get("point_id")
        if key and dataset_type in ("cadastral", "revenue") and key in seen:
            report["problems"].append(f"Row {i}: duplicate survey number {key}")
        seen.add(key)
        if dataset_type == "utilities":
            t = (rec.get("type") or rec.get("name") or "").lower()
            if not _num(rec.get("buffer_m")):
                rec["buffer_m"] = next((v for k, v in UTILITY_BUFFER_M.items() if k in t), 3.0)
        out.append(rec)
    report["rows_ok"] = len(out)
    report["problems"] = report["problems"][:50]
    return {"records": out, "report": report, "crs": crs}
