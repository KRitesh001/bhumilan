"""
run_bhumilan.py - starts BhuMilan and opens the console in your browser.
    python run_bhumilan.py
Set BHUMILAN_HOST=0.0.0.0 to let phones / other laptops on the same Wi-Fi open it.
"""

import os
import threading
import time
import webbrowser

import uvicorn


def main():
    host = os.environ.get("BHUMILAN_HOST", "127.0.0.1")
    port = int(os.environ.get("BHUMILAN_PORT", "8000"))
    print("=" * 72)
    print("  BhuMilan - AI land record harmonization for India (SIH26013, DoLR)")
    print("=" * 72)
    print(f"  Console    : http://localhost:{port}")
    print(f"  API docs   : http://localhost:{port}/docs")
    print(f"  OGC API    : http://localhost:{port}/ogc")
    print("  Logins     : surveyor, gis.officer, ri.vsk, ri.jaipur, tahsildar.vsk, admin  (password demo123)")
    print("  First load : about 10 seconds while drone images are analysed, then cached.")
    print("  Stop       : Ctrl+C\n")
    threading.Thread(target=lambda: (time.sleep(2), webbrowser.open(f"http://127.0.0.1:{port}")), daemon=True).start()
    uvicorn.run("server:app", host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
