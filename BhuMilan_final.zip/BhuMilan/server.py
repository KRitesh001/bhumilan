"""
server.py - BhuMilan web platform (FastAPI).

    python run_bhumilan.py         -> http://localhost:8000        (console)
                                      http://localhost:8000/docs   (API documentation)
                                      http://localhost:8000/ogc    (OGC API - Features for GIS software)
"""

import base64
import csv
import hashlib
import io
import json
import os
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import cv2
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from pydantic import BaseModel

from engine import geo, ingest, names, pipeline, store, vision
from engine.ledger import AuditLedger

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
ledger = AuditLedger(store.STATE / "ledger.json")
TAMPER_BACKUP = store.STATE / "ledger.tamper_demo.json"

app = FastAPI(
    title="BhuMilan - Land Record Harmonization Platform",
    description="AI-assisted integration of cadastral, revenue, municipal, drone, DSM/DTM, GNSS and utility data "
                "for any location in India (SIH26013, DoLR). Other departments can read verified parcels from "
                "these APIs or through the OGC API - Features endpoints under /ogc.",
    version="3.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("BHUMILAN_CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(","),
    allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"],
)

# ---------------------------------------------------------------------------
# Accounts, roles and jurisdiction  (demo accounts - replace with state SSO / e-Pramaan in production)
# ---------------------------------------------------------------------------

ROLE_PERMISSIONS = {
    "Field Surveyor": {"view"},
    "GIS Data Officer": {"view", "upload"},
    "Revenue Inspector": {"view", "decide"},
    "Tahsildar": {"view", "decide", "certify"},
    "National Admin": {"view", "upload", "decide", "certify", "admin"},
}
DEMO_PASSWORD = os.environ.get("BHUMILAN_DEMO_PASSWORD", "demo123")
USERS_SPEC = [
    ("surveyor", "K. Srinu", "Field Surveyor", ["*"]),
    ("gis.officer", "A. Deshpande", "GIS Data Officer", ["*"]),
    ("ri.vsk", "P. Lakshmi", "Revenue Inspector", ["AP-VSK"]),
    ("ri.jaipur", "R. Meena", "Revenue Inspector", ["RJ-JPR"]),
    ("tahsildar.vsk", "M. Rao", "Tahsildar", ["AP-VSK"]),
    ("admin", "BhuMilan Admin", "National Admin", ["*"]),
]


def _pw(pw: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 120_000).hex()


USERS: Dict[str, Dict[str, Any]] = {}
for _u, _n, _r, _j in USERS_SPEC:
    _s = secrets.token_hex(8)
    USERS[_u] = {"name": _n, "role": _r, "jurisdiction": _j, "salt": _s, "hash": _pw(DEMO_PASSWORD, _s)}
SESSIONS: Dict[str, Dict[str, Any]] = {}
FAILED: Dict[str, List[float]] = {}
SESSION_HOURS = 8


def current_user(authorization: Optional[str] = Header(None), token: Optional[str] = None) -> Dict[str, Any]:
    """Every data route needs a signed-in officer. The token normally comes in the Authorization header;
    image and download links (which a browser fetches without headers) pass it as ?token=."""
    tok = authorization[7:] if authorization and authorization.startswith("Bearer ") else token
    if not tok:
        raise HTTPException(status_code=401, detail="Please log in first")
    s = SESSIONS.get(tok)
    if not s or s["expires"] < time.time():
        SESSIONS.pop(tok, None)
        raise HTTPException(status_code=401, detail="Session expired - please log in again")
    return s


def can_see(user, loc: str) -> bool:
    return "*" in user["jurisdiction"] or loc in user["jurisdiction"]


def require(user, perm: str, loc: Optional[str] = None):
    if perm not in ROLE_PERMISSIONS.get(user["role"], set()):
        raise HTTPException(status_code=403, detail=f"A {user['role']} cannot do this")
    if loc and "*" not in user["jurisdiction"] and loc not in user["jurisdiction"]:
        raise HTTPException(status_code=403, detail=f"{user['name']} has no jurisdiction over {loc}")


def officer_label(user) -> str:
    return f"{user['name']} ({user['role']})"


def _loc_or_404(loc: str) -> Dict[str, Any]:
    try:
        return store.manifest(loc)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Location {loc} not found")


def _parcel_or_404(loc: str, pid: str):
    _loc_or_404(loc)
    res = pipeline.harmonize(loc)
    p = next((x for x in res["parcels"] if x["parcel_id"] == pid), None)
    if not p:
        raise HTTPException(status_code=404, detail=f"Parcel {pid} not found")
    return res, p


class LoginReq(BaseModel):
    username: str
    password: str


class DecideReq(BaseModel):
    action: str                    # APPLY_RECOMMENDATIONS | ACCEPT_RECORD | ORDER_GNSS_SURVEY | FIELD_ENQUIRY | UNDO
    remarks: Optional[str] = ""


class LabelReq(BaseModel):
    same_person: bool


class NewLocationReq(BaseModel):
    state: str
    district: str
    city: str
    urban_local_body: Optional[str] = ""


class UploadReq(BaseModel):
    location: str
    dataset_type: str
    filename: str
    content_base64: str
    mapping: Optional[Dict[str, Optional[str]]] = None
    units: Optional[Dict[str, float]] = None
    source: Optional[str] = ""


# ---------------------------------------------------------------------------
# Pages and static files
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse((STATIC / "index.html").read_text(encoding="utf-8"))


@app.get("/static/{file_path:path}")
async def static_files(file_path: str):
    target = (STATIC / file_path).resolve()
    if STATIC.resolve() not in target.parents or not target.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(target)


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

@app.post("/api/login")
async def login(req: LoginReq):
    u = req.username.strip().lower()
    now = time.time()
    recent = [t for t in FAILED.get(u, []) if now - t < 120]
    if len(recent) >= 5:
        raise HTTPException(status_code=429, detail="Too many wrong attempts - wait 2 minutes")
    user = USERS.get(u)
    if not user or _pw(req.password, user["salt"]) != user["hash"]:
        FAILED[u] = recent + [now]
        raise HTTPException(status_code=401, detail="Wrong username or password")
    FAILED.pop(u, None)
    token = secrets.token_urlsafe(24)
    sess = {"username": u, "name": user["name"], "role": user["role"], "jurisdiction": user["jurisdiction"],
            "permissions": sorted(ROLE_PERMISSIONS[user["role"]]), "expires": now + SESSION_HOURS * 3600}
    SESSIONS[token] = sess
    ledger.record("OFFICER_LOGIN", "INDIA", "SYSTEM", officer_label(user), "Signed in")
    return {"token": token, **{k: v for k, v in sess.items() if k != "expires"}}


@app.get("/api/me")
async def me(user=Depends(current_user)):
    return {k: v for k, v in user.items() if k != "expires"}


@app.post("/api/logout")
async def logout(authorization: Optional[str] = Header(None)):
    if authorization and authorization.startswith("Bearer "):
        SESSIONS.pop(authorization[7:], None)
    return {"status": "logged out"}


@app.get("/api/accounts")
async def demo_accounts():
    """Demo accounts shown on the login screen."""
    return [{"username": u, "role": r, "jurisdiction": j, "can": sorted(ROLE_PERMISSIONS[r])} for u, _, r, j in USERS_SPEC]


# ---------------------------------------------------------------------------
# India overview and locations
# ---------------------------------------------------------------------------

@app.get("/api/states")
async def states(user=Depends(current_user)):
    return [{"name": s[0], "code": s[1], "lgd_code": s[2], "script": s[3], "center": s[4]} for s in store.STATES]


@app.get("/api/locations")
async def locations(user=Depends(current_user)):
    out = []
    for m in store.list_locations():
        if not can_see(user, m["id"]):
            continue
        item = {k: m.get(k) for k in ("id", "city", "district", "state", "state_code_lgd", "urban_local_body",
                                       "center", "utm_epsg", "synthetic")}
        item["datasets"] = [d["type"] for d in m["datasets"]]
        if any(d["type"] == "cadastral" for d in m["datasets"]):
            try:
                item["summary"] = pipeline.harmonize(m["id"])["summary"]
            except Exception as e:                     # a broken upload must not break the national view
                item["error"] = str(e)
        out.append(item)
    return out


@app.post("/api/locations")
async def create_location(req: NewLocationReq, user=Depends(current_user)):
    require(user, "upload")
    try:
        m = store.create_location(req.state, req.district, req.city, req.urban_local_body or "")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    ledger.record("LOCATION_CREATED", m["id"], "-", officer_label(user), f"{m['city']}, {m['district']}, {m['state']}")
    return m


@app.get("/api/locations/{loc}")
async def location_detail(loc: str, user=Depends(current_user)):
    require(user, "view", loc)
    _loc_or_404(loc)
    return pipeline.harmonize(loc)


@app.post("/api/locations/{loc}/run")
async def run_pipeline(loc: str, user=Depends(current_user)):
    require(user, "view", loc)
    _loc_or_404(loc)
    pipeline.invalidate(loc)
    t0 = time.perf_counter()
    res = pipeline.harmonize(loc)
    return {"status": "Pipeline completed", "elapsed_seconds": round(time.perf_counter() - t0, 2),
            "summary": res["summary"]}


@app.get("/api/locations/{loc}/parcels/{pid}")
async def parcel_detail(loc: str, pid: str, user=Depends(current_user)):
    require(user, "view", loc)
    return _parcel_or_404(loc, pid)[1]


# ---------------------------------------------------------------------------
# Evidence images
# ---------------------------------------------------------------------------

def _latest(loc, pid):
    folder = store.LOCS / loc / "imagery" / pid
    meta = vision.load_meta(folder)
    if not meta:
        raise HTTPException(status_code=404, detail="No imagery for this parcel")
    surveys = sorted(meta["surveys"], key=lambda s: s["year"])
    return folder, meta, surveys


@app.get("/api/locations/{loc}/parcels/{pid}/evidence.jpg")
async def evidence(loc: str, pid: str, user=Depends(current_user)):
    require(user, "view", loc)
    res, p = _parcel_or_404(loc, pid)
    folder, meta, surveys = _latest(loc, pid)
    img = cv2.imread(str(folder / surveys[-1]["file"]))
    c = p["checks"]
    gp = c["boundary"].get("gnss_polygon") or []
    utils = [{"line": u["line"], "buffer_m": u["buffer_m"]} for u in res["utilities"]
             if any(h["id"] == u["id"] for h in c["utilities"])]
    jpg = vision.render_evidence(img, meta, [tuple(q) for q in p["polygon"]],
                                 [tuple(q) for q in c["boundary"]["detected"]] if c["boundary"]["detected"] else None,
                                 c["buildings"].get("buildings", []), c["buildings"].get("new", []),
                                 [tuple(q) for q in gp], utils)
    return Response(content=jpg, media_type="image/jpeg")


@app.get("/api/locations/{loc}/parcels/{pid}/change.jpg")
async def change_image(loc: str, pid: str, user=Depends(current_user)):
    require(user, "view", loc)
    res, p = _parcel_or_404(loc, pid)
    folder, meta, surveys = _latest(loc, pid)
    a, b = cv2.imread(str(folder / surveys[0]["file"])), cv2.imread(str(folder / surveys[-1]["file"]))
    region = [[tuple(q) for q in p["polygon"]]]
    old_b = vision.buildings_in(region[0], vision.extract_buildings(a, meta))
    new_b = p["checks"]["buildings"].get("buildings", [])
    jpg = vision.render_change(a, b, meta, old_b, new_b, {"new": p["checks"]["buildings"].get("new", []), "extended": []})
    return Response(content=jpg, media_type="image/jpeg")


@app.get("/api/locations/{loc}/parcels/{pid}/ndsm.png")
async def ndsm(loc: str, pid: str, user=Depends(current_user)):
    require(user, "view", loc)
    res, p = _parcel_or_404(loc, pid)
    png = vision.render_ndsm(store.LOCS / loc / "surface" / f"{pid}.npz", [tuple(q) for q in p["polygon"]])
    if png is None:
        raise HTTPException(status_code=404, detail="No DSM/DTM for this parcel")
    return Response(content=png, media_type="image/png")


@app.get("/imagery/{loc}/{pid}/{filename}")
async def imagery(loc: str, pid: str, filename: str, user=Depends(current_user)):
    require(user, "view", loc)
    root = (store.LOCS / loc / "imagery").resolve()
    target = (root / pid / filename).resolve()
    if root not in target.parents or not target.is_file():
        raise HTTPException(status_code=404, detail="Image not found")
    return FileResponse(target)


# ---------------------------------------------------------------------------
# Officer decisions
# ---------------------------------------------------------------------------

@app.post("/api/locations/{loc}/parcels/{pid}/decide")
async def decide(loc: str, pid: str, req: DecideReq, user=Depends(current_user)):
    require(user, "decide", loc)
    res, p = _parcel_or_404(loc, pid)
    decisions = store.load_decisions(loc)
    prev = decisions.get(pid, {})
    remarks = (req.remarks or "").strip() or "No remarks"
    changes = []
    if req.action == "UNDO":
        decisions.pop(pid, None)
        changes.append("decision withdrawn - back to the system's assessment")
    elif req.action in ("APPLY_RECOMMENDATIONS", "ACCEPT_RECORD", "ORDER_GNSS_SURVEY", "FIELD_ENQUIRY"):
        d = {"history": prev.get("history", []), "version": prev.get("version", 0) + 1}
        if req.action == "APPLY_RECOMMENDATIONS":
            acts = {r["action"]: r for r in p["recommendations"]}
            b = p["checks"]["boundary"]
            if "UPDATE_BOUNDARY" in acts:
                if acts["UPDATE_BOUNDARY"]["source"] == "GNSS survey" and b.get("gnss_polygon"):
                    d["corrected_polygon"], src = b["gnss_polygon"], "GNSS survey"
                elif b.get("detected"):
                    d["corrected_polygon"], src = b["detected"], "drone image"
                else:
                    src = None
                if src:
                    changes.append(f"boundary updated to the {src} ({b['offset_m']} m change)")
            if "STANDARDISE_OWNER" in acts or "START_MUTATION" in acts:
                d["municipal_owner_override"] = p["revenue"]["owner_name"]
                changes.append("municipal owner set to the Revenue record-of-rights owner"
                               + (" (mutation started)" if "START_MUTATION" in acts else ""))
            if "UPDATE_BUILDING_RECORD" in acts:
                bi = p["checks"]["buildings"]
                d["floors_override"] = bi.get("floors_est")
                d["built_up_override"] = bi.get("footprint_m2")
                d["resolved"] = ["building"]
                changes.append(f"municipal building record updated: {bi.get('floors_est')} floors, "
                               f"{bi.get('footprint_m2')} sq.m built-up")
            if "RECORD_EASEMENT" in acts:
                d["easement_recorded"] = True
                changes.append("utility easement restriction recorded")
            if not changes:
                changes.append("no automatic changes needed")
            d["status"] = "Verified (officer)"
        elif req.action == "ACCEPT_RECORD":
            d["status"] = "Verified (officer)"
            changes.append("officer confirmed the existing record is correct")
        elif req.action == "ORDER_GNSS_SURVEY":
            d["status"] = "Ground survey ordered"
            changes.append("DGNSS ground survey ordered")
        else:
            d["status"] = "Field enquiry ordered"
            changes.append("field enquiry ordered")
        d.update({"action": req.action, "officer": officer_label(user), "remarks": remarks,
                  "decided_at": datetime.now().isoformat(timespec="seconds"), "changes": changes})
        d["history"] = (d["history"] + [{k: v for k, v in prev.items() if k != "history"}])[-10:] if prev else []
        decisions[pid] = d
    else:
        raise HTTPException(status_code=400, detail=f"Unknown action {req.action}")
    store.save_decisions(loc, decisions)
    entry = ledger.record(req.action, loc, pid, officer_label(user), "; ".join(changes) + f". Remarks: {remarks}")
    pipeline.invalidate(loc)
    return {"success": True, "changes": changes, "ledger_entry": entry,
            "parcel": next(x for x in pipeline.harmonize(loc)["parcels"] if x["parcel_id"] == pid)}


@app.post("/api/locations/{loc}/parcels/{pid}/owner-label")
async def owner_label(loc: str, pid: str, req: LabelReq, user=Depends(current_user)):
    """Officer says whether the two owner names are the same person - saved to retrain the AI."""
    require(user, "decide", loc)
    res, p = _parcel_or_404(loc, pid)
    if not (p["revenue"] and p["municipal"]):
        raise HTTPException(status_code=400, detail="Both records are needed")
    store.add_officer_label(p["revenue"].get("owner_name", ""), p["municipal"].get("owner_name", ""),
                            p["revenue"].get("father_name", ""), p["municipal"].get("father_name", ""),
                            req.same_person, officer_label(user), loc, pid)
    ledger.record("NAME_LABEL", loc, pid, officer_label(user),
                  f"Officer marked owner names as {'the same person' if req.same_person else 'different people'}")
    return {"success": True, "labels_collected": store.count_officer_labels()}


@app.post("/api/locations/{loc}/certify")
async def certify(loc: str, user=Depends(current_user)):
    require(user, "certify", loc)
    res = pipeline.harmonize(loc)
    ok = [p["parcel_id"] for p in res["parcels"] if p["status"].startswith("Verified")]
    pending = [p["parcel_id"] for p in res["parcels"] if not p["status"].startswith("Verified")]
    stamp = datetime.now()
    h = hashlib.sha256(json.dumps([(p["parcel_id"], p["polygon"], p["score"]) for p in res["parcels"]
                                   if p["parcel_id"] in ok]).encode()).hexdigest().upper()
    entry = ledger.record("BATCH_CERTIFICATION", loc, f"BATCH-{loc}", officer_label(user),
                          f"Certified {len(ok)} of {len(res['parcels'])} parcels. Batch hash {h[:16]}")
    return {"success": True, "batch_id": f"BHUMILAN-{loc}-{stamp.strftime('%Y%m%d-%H%M%S')}", "batch_hash": h,
            "certified_count": len(ok), "pending_parcels": pending, "total_parcels": len(res["parcels"]),
            "officer": officer_label(user), "ledger_entry": entry}


# ---------------------------------------------------------------------------
# Upload (any department, any format) + new locations
# ---------------------------------------------------------------------------

def _decode_upload(req: UploadReq):
    if req.dataset_type not in ingest.SCHEMAS:
        raise HTTPException(status_code=400, detail="Unknown dataset type")
    try:
        raw = base64.b64decode(req.content_base64)
    except Exception:
        raise HTTPException(status_code=400, detail="File content could not be read")
    if len(raw) > 25 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File is larger than 25 MB")
    try:
        parsed = ingest.read_any(req.filename, raw)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not read the file: {e}")
    return raw, parsed


@app.post("/api/upload/preview")
async def upload_preview(req: UploadReq, user=Depends(current_user)):
    require(user, "upload")
    m = _loc_or_404(req.location)
    raw, parsed = _decode_upload(req)
    sug = ingest.suggest_mapping(req.dataset_type, parsed["columns"], parsed["rows"], m["state"])
    mapping = {s["column"]: s["field"] for s in sug}
    units = {s["field"]: s["unit_m2"] for s in sug if s["field"] and s["unit_m2"]}
    std = ingest.standardise(req.dataset_type, parsed, mapping, units, tuple(m.get("center") or (0, 0)))
    return {"format": parsed["format"], "rows": len(parsed["rows"]), "columns": sug,
            "schema": ingest.SCHEMAS[req.dataset_type], "crs": std["crs"]["label"], "report": std["report"],
            "preview": [{k: v for k, v in r.items() if not k.startswith("__")} for r in std["records"][:5]],
            "fields": ingest.SCHEMAS[req.dataset_type]["fields"]}


@app.post("/api/upload/commit")
async def upload_commit(req: UploadReq, user=Depends(current_user)):
    require(user, "upload")
    m = _loc_or_404(req.location)
    raw, parsed = _decode_upload(req)
    mapping = {c: f for c, f in (req.mapping or {}).items() if f}
    std = ingest.standardise(req.dataset_type, parsed, mapping, req.units or {}, tuple(m.get("center") or (0, 0)))
    if not std["records"]:
        raise HTTPException(status_code=400, detail="No valid rows: " + "; ".join(std["report"]["problems"][:3]))
    std["source"] = req.source
    entry = store.save_upload(req.location, req.dataset_type, req.filename, raw, std, mapping, req.units or {},
                              officer_label(user))
    pipeline.invalidate(req.location)
    ledger.record("DATA_UPLOAD", req.location, "-", officer_label(user),
                  f"{ingest.SCHEMAS[req.dataset_type]['label']}: {len(std['records'])} rows from {req.filename} "
                  f"(version {entry['version']}, {std['crs']['label']})")
    return {"success": True, "dataset": entry, "report": std["report"]}


# ---------------------------------------------------------------------------
# Exports + OGC API - Features (for QGIS / ArcGIS / other departments)
# ---------------------------------------------------------------------------

def _feature(p, loc):
    ring = [[lon, lat] for lat, lon in p["polygon"]]
    ring.append(ring[0])
    return {"type": "Feature", "id": p["parcel_id"], "geometry": {"type": "Polygon", "coordinates": [ring]},
            "properties": {"parcel_id": p["parcel_id"], "location": loc, "survey_number": p["survey_number"],
                           "village": p["village"], "area_m2": p["area_m2"], "confidence": p["score"],
                           "status": p["status"], "issues": ",".join(p["issues"]),
                           "owner_revenue": (p["revenue"] or {}).get("owner_name"),
                           "owner_municipal": (p["municipal"] or {}).get("owner_name"),
                           "boundary_corrected": p["corrected"],
                           "record_version": (p["decision"] or {}).get("version", 0)}}


@app.get("/api/locations/{loc}/export.geojson")
async def export_geojson(loc: str, user=Depends(current_user)):
    require(user, "view", loc)
    _loc_or_404(loc)
    res = pipeline.harmonize(loc)
    fc = {"type": "FeatureCollection", "name": f"BhuMilan {loc}", "features": [_feature(p, loc) for p in res["parcels"]]}
    return Response(json.dumps(fc, ensure_ascii=False), media_type="application/geo+json",
                    headers={"Content-Disposition": f'attachment; filename="BhuMilan_{loc}.geojson"'})


@app.get("/api/locations/{loc}/export.csv")
async def export_csv(loc: str, user=Depends(current_user)):
    require(user, "view", loc)
    _loc_or_404(loc)
    res = pipeline.harmonize(loc)
    buf = io.StringIO()
    rows = [_feature(p, loc)["properties"] for p in res["parcels"]]
    w = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
    return Response("﻿" + buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="BhuMilan_{loc}.csv"'})


def _base_url():
    return (os.environ.get("BHUMILAN_PUBLIC_URL") or os.environ.get("RENDER_EXTERNAL_URL")
            or "http://localhost:8000").rstrip("/")


@app.get("/ogc")
async def ogc_landing():
    b = _base_url()
    return {"title": "BhuMilan OGC API - Features", "description": "Harmonized land parcels for every BhuMilan location",
            "links": [{"href": f"{b}/ogc", "rel": "self", "type": "application/json"},
                      {"href": f"{b}/ogc/conformance", "rel": "conformance", "type": "application/json"},
                      {"href": f"{b}/ogc/collections", "rel": "data", "type": "application/json"},
                      {"href": f"{b}/openapi.json", "rel": "service-desc", "type": "application/vnd.oai.openapi+json;version=3.0"}]}


@app.get("/ogc/conformance")
async def ogc_conformance():
    return {"conformsTo": ["http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/core",
                           "http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/geojson"]}


def _collection(m):
    b = _base_url()
    cid = f"{m['id']}-parcels"
    lat, lon = (m.get("center") or [0, 0])[:2]
    return {"id": cid, "title": f"Harmonized parcels - {m['city']}, {m['state']}",
            "extent": {"spatial": {"bbox": [[lon - 0.02, lat - 0.02, lon + 0.02, lat + 0.02]]}},
            "links": [{"href": f"{b}/ogc/collections/{cid}/items", "rel": "items", "type": "application/geo+json"}]}


@app.get("/ogc/collections")
async def ogc_collections(user=Depends(current_user)):
    return {"collections": [_collection(m) for m in store.list_locations() if can_see(user, m["id"])
                            and any(d["type"] == "cadastral" for d in m["datasets"])],
            "links": [{"href": f"{_base_url()}/ogc/collections", "rel": "self", "type": "application/json"}]}


@app.get("/ogc/collections/{cid}")
async def ogc_collection(cid: str, user=Depends(current_user)):
    loc = cid.rsplit("-parcels", 1)[0]
    require(user, "view", loc)
    return _collection(_loc_or_404(loc))


@app.get("/ogc/collections/{cid}/items")
async def ogc_items(cid: str, bbox: Optional[str] = None, limit: int = 100, offset: int = 0,
                    user=Depends(current_user)):
    loc = cid.rsplit("-parcels", 1)[0]
    require(user, "view", loc)
    _loc_or_404(loc)
    feats = [_feature(p, loc) for p in pipeline.harmonize(loc)["parcels"]]
    if bbox:
        try:
            x0, y0, x1, y1 = [float(v) for v in bbox.split(",")]
        except ValueError:
            raise HTTPException(status_code=400, detail="bbox must be minLon,minLat,maxLon,maxLat")
        feats = [f for f in feats if any(x0 <= c[0] <= x1 and y0 <= c[1] <= y1 for c in f["geometry"]["coordinates"][0])]
    limit = max(1, min(int(limit), 1000))
    page = feats[int(offset):int(offset) + limit]
    body = {"type": "FeatureCollection", "numberMatched": len(feats), "numberReturned": len(page), "features": page,
            "timeStamp": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    return Response(json.dumps(body, ensure_ascii=False), media_type="application/geo+json")


# ---------------------------------------------------------------------------
# AI model info + retraining from officer decisions
# ---------------------------------------------------------------------------

@app.get("/api/model")
async def model_info(user=Depends(current_user)):
    nm = json.loads((BASE / "models" / "name_matcher.json").read_text(encoding="utf-8"))
    vm_file = BASE / "models" / "vision_metrics.json"
    return {"name_matcher": {"version": nm["version"], "type": nm["type"], "features": nm["features"],
                             "metrics": nm["metrics"], "training_pairs": nm["training_pairs"]},
            "vision": json.loads(vm_file.read_text(encoding="utf-8")) if vm_file.exists() else None,
            "officer_labels_collected": store.count_officer_labels()}


@app.get("/api/model/match")
async def model_match(a: str = "", b: str = "", father_a: str = "", father_b: str = "",
                      user=Depends(current_user)):
    """Try the owner-name matcher: any two names, any Indian script."""
    if not a.strip() or not b.strip():
        raise HTTPException(status_code=400, detail="Give two names")
    return names.match(a[:120], b[:120], father_a[:120], father_b[:120])


@app.post("/api/model/retrain")
async def retrain(user=Depends(current_user)):
    require(user, "admin")
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("trainer", BASE / "tools" / "train_name_matcher.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        model = mod.main()
    except ImportError:
        raise HTTPException(status_code=500, detail="scikit-learn is not installed on the server")
    pipeline.invalidate()
    ledger.record("MODEL_RETRAINED", "INDIA", "-", officer_label(user),
                  f"Name matcher {model['version']} trained with {model['metrics']['officer_labels_used']} officer labels; "
                  f"accuracy {model['metrics']['accuracy']:.1%}")
    return {"success": True, "version": model["version"], "metrics": model["metrics"]}


# ---------------------------------------------------------------------------
# Audit ledger + demo controls
# ---------------------------------------------------------------------------

@app.get("/api/audit-log")
async def audit_log(location: Optional[str] = None, user=Depends(current_user)):
    e = ledger.entries()
    if "*" not in user["jurisdiction"]:
        e = [x for x in e if x.get("location") in user["jurisdiction"] or x.get("location") == "INDIA"]
    if location:
        e = [x for x in e if x.get("location") in (location, "INDIA")]
    return {"entries": e}


@app.get("/api/audit-log/verify")
async def audit_verify(user=Depends(current_user)):
    return ledger.verify()


@app.post("/api/demo/tamper")
async def demo_tamper(user=Depends(current_user)):
    require(user, "admin")
    if TAMPER_BACKUP.exists():
        raise HTTPException(status_code=400, detail="Already tampered - click Undo first")
    target = next((e for e in ledger.entries() if e["action"] not in ("GENESIS_BLOCK", "OFFICER_LOGIN", "DEMO_RESET")), None)
    if not target:
        raise HTTPException(status_code=400, detail="Record at least one officer decision first")
    old = ledger.rewrite_entry(target["index"], "details", target["details"] + " [secretly edited: owner changed]")
    TAMPER_BACKUP.write_text(json.dumps({"index": target["index"], "details": old}), encoding="utf-8")
    return {"status": f"Entry #{target['index']} was edited directly in the file"}


@app.post("/api/demo/restore")
async def demo_restore(user=Depends(current_user)):
    require(user, "admin")
    if not TAMPER_BACKUP.exists():
        raise HTTPException(status_code=400, detail="Nothing to restore")
    orig = json.loads(TAMPER_BACKUP.read_text(encoding="utf-8"))
    ledger.rewrite_entry(orig["index"], "details", orig["details"])
    TAMPER_BACKUP.unlink()
    return {"status": f"Entry #{orig['index']} restored"}


@app.post("/api/demo/reset")
async def demo_reset(location: Optional[str] = None, user=Depends(current_user)):
    require(user, "admin")
    store.reset_decisions(location)
    pipeline.invalidate(location)
    ledger.record("DEMO_RESET", location or "INDIA", "-", officer_label(user), "Officer decisions cleared for a fresh demo")
    return {"status": "Officer decisions cleared"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="127.0.0.1", port=8000)
