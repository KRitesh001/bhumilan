/* BhuMilan web console - every number on screen comes from the FastAPI backend. */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n, d = 0) => (n === null || n === undefined || n === "") ? "–" : Number(n).toLocaleString("en-IN", { maximumFractionDigits: d });

const S = {
  user: null, states: [], locations: [], loc: null, data: null, selected: null,
  queueFilter: "review", lastVerify: null, evTab: "evidence", upType: "cadastral", upFile: null, upPreview: null,
};

const ISSUE = {
  boundary_shift: ["Boundary shift", "#C9840A"], overlap: ["Overlaps neighbour", "#7B5CB8"],
  invalid_geometry: ["Invalid shape", "#7B5CB8"], utility: ["Utility easement", "#2B6CB0"],
  owner_conflict: ["Owner conflict", "#B0432E"], owner_uncertain: ["Owner unclear", "#D0752F"],
  mutation_pending: ["Inheritance not transferred", "#A23B72"], no_revenue_record: ["No revenue record", "#8A2D1F"],
  new_construction: ["New construction", "#C02AC8"], extra_floors: ["Unrecorded floors", "#5B6B8C"],
};
const PENALTY = {
  boundary: ["Boundary", "#C9840A"], topology: ["Topology", "#7B5CB8"], utility: ["Utility", "#2B6CB0"],
  owner: ["Owner", "#B0432E"], link: ["Record link", "#8A2D1F"], municipal_link: ["Municipal link", "#9C8A6E"],
  construction: ["New construction", "#C02AC8"], floors: ["Floors", "#5B6B8C"],
};
const ACTION_TEXT = {
  UPDATE_BOUNDARY: "Update boundary", ORDER_GNSS_SURVEY: "Order GNSS survey", RECORD_EASEMENT: "Record easement",
  STANDARDISE_OWNER: "Standardise owner name", START_MUTATION: "Start mutation", CONFIRM_OWNER: "Confirm owner",
  FIELD_ENQUIRY: "Field enquiry", UPDATE_BUILDING_RECORD: "Update building record",
};
const DTYPES = [
  ["cadastral", "Cadastral map", "Parcel boundaries · GeoJSON, KML, Shapefile"],
  ["revenue", "Revenue records", "Record of rights · CSV (any language headers)"],
  ["municipal", "Municipal records", "Property tax with lat/lon · CSV"],
  ["gnss", "GNSS / CORS points", "Ground truth corners · CSV, GeoJSON"],
  ["utilities", "Utility lines", "Water, power, sewer, gas · GeoJSON, KML, Shapefile"],
];
const UNITS = [["sq_m", "sq. metre", 1], ["sq_ft", "sq. foot", 0.09290304], ["sq_yd", "sq. yard / gaj", 0.83612736],
  ["acre", "acre", 4046.8564], ["cent", "cent", 40.468564], ["hectare", "hectare", 10000], ["guntha", "guntha", 101.17141],
  ["kanal", "kanal", 505.857], ["marla", "marla", 25.2929], ["bigha_e", "bigha (Assam / West Bengal)", 1337.8],
  ["bigha_n", "bigha (Rajasthan / UP / Bihar)", 2529.3], ["bigha_p", "bigha (Punjab / Haryana / HP)", 836.1]];

/* ---------------- session, api, toast ---------------- */
function loadSession() { try { const s = sessionStorage.getItem("bhumilan"); if (s) S.user = JSON.parse(s); } catch (e) { /* blocked */ } }
function saveSession() { try { S.user ? sessionStorage.setItem("bhumilan", JSON.stringify(S.user)) : sessionStorage.removeItem("bhumilan"); } catch (e) { /* */ } }
const can = (p, loc) => !!(S.user && S.user.permissions.includes(p) &&
  (!loc || S.user.jurisdiction.includes("*") || S.user.jurisdiction.includes(loc)));

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json" };
  if (S.user) headers.Authorization = "Bearer " + S.user.token;
  let res;
  try { res = await fetch(path, { ...opts, headers }); }
  catch (e) { $("#offlineBanner").hidden = false; throw new Error("Server not reachable"); }
  $("#offlineBanner").hidden = true;
  const body = await res.json().catch(() => ({}));
  if (res.status === 401 && S.user && path !== "/api/login") { S.user = null; saveSession(); showGate("Your session has expired. Please sign in again."); }
  if (!res.ok) throw new Error(body.detail || ("Request failed (" + res.status + ")"));
  return body;
}
// <img> and download links can't send headers, so they carry the session token in the URL
const withTok = u => S.user ? u + (u.includes("?") ? "&" : "?") + "token=" + encodeURIComponent(S.user.token) : u;
function toast(msg, err = false) {
  const t = $("#toast"); t.textContent = msg; t.className = "toast" + (err ? " err" : ""); t.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), 4200);
}
function kindOf(status) {
  if ((status || "").startsWith("Verified")) return "good";
  if (status === "Serious conflict") return "bad";
  if (status === "Review required") return "warn";
  return "purple";
}
const KIND_COLOR = { good: "#4C8C5A", warn: "#C9840A", bad: "#B0432E", purple: "#7B5CB8" };

/* ---------------- routing ---------------- */
const VIEWS = ["india", "map", "queue", "upload", "ledger", "models"];
function go(view, loc, pid) {
  let h = "#" + view;
  if (loc) h += "/" + loc + (pid ? "/" + pid : "");
  if (location.hash !== h) location.hash = h; else route();
}
async function route() {
  if (!S.user) return;
  const [v, loc, pid] = (location.hash || "#india").slice(1).split("/");
  const view = VIEWS.includes(v) ? v : "india";
  if (loc && loc !== S.loc) await loadLocation(loc);
  if (!S.loc && ["map", "queue"].includes(view) && S.locations.length) await loadLocation(S.locations[0].id);
  $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.view === view));
  $$(".view").forEach(el => (el.hidden = el.id !== "view-" + view));
  $("#locPickWrap").style.visibility = ["map", "queue"].includes(view) ? "visible" : "hidden";
  if (view === "india") renderIndia();
  if (view === "map") {
    setTimeout(() => {
      if (!map) return;
      map.invalidateSize();
      if (pid) selectParcel(pid, true);
      else if (S.needFit) fitParcels();
      S.needFit = false;
    }, 80);
  }
  if (view === "queue") renderQueue();
  if (view === "upload") renderUpload();
  if (view === "ledger") loadLedger();
  if (view === "models") renderModels();
}
window.addEventListener("hashchange", route);
$$(".tab").forEach(t => t.addEventListener("click", () => go(t.dataset.view, ["map", "queue"].includes(t.dataset.view) ? S.loc : null)));

/* ---------------- user / login ---------------- */
function renderUser() {
  const box = $("#userBox");
  if (S.user) {
    const j = S.user.jurisdiction.includes("*") ? "All India" : S.user.jurisdiction.join(", ");
    box.innerHTML = `<div class="user-chip"><b>${esc(S.user.name)}</b><span>${esc(S.user.role)} · ${esc(j)}</span></div><button class="btn small" id="logoutBtn">Log out</button>`;
    $("#logoutBtn").onclick = signOut;
  } else box.innerHTML = "";
  $$(".admin-only").forEach(el => (el.hidden = !can("admin")));
  if (S.selected) renderDrawer();
  if (!$("#view-upload").hidden) renderUpload();
}
async function signOut() {
  try { await api("/api/logout", { method: "POST" }); } catch (e) { /* */ }
  S.user = null; saveSession();
  location.reload();               // start clean: no parcel data stays in the page
}
async function showGate(msg) {
  $("#app").hidden = true; $$(".modal").forEach(m => (m.hidden = true));
  $("#loginGate").hidden = false; $("#loginPass").value = "";
  $("#loginError").textContent = msg || ""; $("#loginError").hidden = !msg;
  try {
    const accts = await api("/api/accounts");
    $("#acctList").innerHTML = accts.map(a => `<button type="button" class="acct" data-user="${esc(a.username)}"><b>${esc(a.username)}</b><span>${esc(a.role)} · ${a.jurisdiction.includes("*") ? "all India" : esc(a.jurisdiction.join(", "))}</span></button>`).join("");
    $$(".acct").forEach(b => (b.onclick = () => { $("#loginUser").value = b.dataset.user; $("#loginPass").value = "demo123"; $("#loginSubmit").focus(); }));
  } catch (e) { /* offline banner shows */ }
  setTimeout(() => $("#loginUser").focus(), 30);
}
// "Log in as ..." prompts inside the app switch to another officer
document.addEventListener("click", e => { if (e.target.closest("[data-login]")) signOut(); });
$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("#loginSubmit"); btn.disabled = true; btn.textContent = "Signing in…";
  try {
    S.user = await api("/api/login", { method: "POST", body: JSON.stringify({ username: $("#loginUser").value, password: $("#loginPass").value }) });
    saveSession(); $("#loginGate").hidden = true;
    await startApp();
    toast("Signed in as " + S.user.name + " · " + S.user.role);
  } catch (err) { $("#loginError").textContent = err.message; $("#loginError").hidden = false; }
  btn.disabled = false; btn.textContent = "Sign in";
});
$$(".modal").forEach(m => m.addEventListener("click", e => { if (e.target === m || e.target.hasAttribute("data-close")) m.hidden = true; }));
document.addEventListener("keydown", e => { if (e.key === "Escape") $$(".modal").forEach(m => (m.hidden = true)); });
function openImage(src, title) { $("#imgBig").src = src; $("#imgTitle").textContent = title; $("#imgModal").hidden = false; }

/* ---------------- locations ---------------- */
async function loadLocations() {
  S.locations = await api("/api/locations");
  const byState = {};
  S.locations.forEach(l => (byState[l.state] = byState[l.state] || []).push(l));
  const opts = Object.keys(byState).sort().map(st => `<optgroup label="${esc(st)}">${byState[st].map(l => `<option value="${l.id}">${esc(l.city)} (${l.id})</option>`).join("")}</optgroup>`).join("");
  $("#locPick").innerHTML = opts; $("#upLoc").innerHTML = opts;
  if (S.loc) { $("#locPick").value = S.loc; $("#upLoc").value = S.loc; }
}
$("#locPick").addEventListener("change", e => go(location.hash.startsWith("#queue") ? "queue" : "map", e.target.value));
async function loadLocation(loc) {
  S.loc = loc; S.selected = null;
  $("#locPick").value = loc;
  try { S.data = await api(`/api/locations/${loc}`); }
  catch (e) { toast(e.message, true); S.data = null; return; }
  $("#queueCount").textContent = S.data.summary.needs_review;
  renderSidebar(); drawMap(true); S.needFit = true;
  const worst = [...S.data.parcels].sort((a, b) => a.score - b.score)[0];
  if (worst) selectParcel(worst.parcel_id, false);
}
async function refreshLocation() {
  if (!S.loc) return;
  const keep = S.selected;
  S.data = await api(`/api/locations/${S.loc}`);
  $("#queueCount").textContent = S.data.summary.needs_review;
  renderSidebar(); drawMap(false);
  if (keep) selectParcel(keep, false);
  if (!$("#view-queue").hidden) renderQueue();
}

/* ---------------- India overview ---------------- */
let indiaMap = null, indiaLayer = null;
function renderIndia() {
  const L_ = S.locations.filter(l => l.summary);
  const tot = L_.reduce((a, l) => a + l.summary.total_parcels, 0);
  const ver = L_.reduce((a, l) => a + l.summary.verified, 0);
  const rev = L_.reduce((a, l) => a + l.summary.needs_review, 0);
  const states = new Set(S.locations.map(l => l.state)).size;
  $("#indiaKpis").innerHTML = `
    <div class="kpi blue"><div class="n">${S.locations.length}</div><div class="l">locations in ${states} states</div></div>
    <div class="kpi"><div class="n">${fmt(tot)}</div><div class="l">parcels harmonized</div></div>
    <div class="kpi good"><div class="n">${tot ? Math.round(100 * ver / tot) : 0}%</div><div class="l">verified (${fmt(ver)})</div></div>
    <div class="kpi warn"><div class="n">${fmt(rev)}</div><div class="l">need an officer</div></div>
    <div class="kpi"><div class="n">${L_.length ? (L_.reduce((a, l) => a + l.summary.average_confidence * l.summary.total_parcels, 0) / Math.max(1, tot)).toFixed(1) : "–"}</div><div class="l">average confidence</div></div>`;
  const agg = {};
  L_.forEach(l => Object.entries(l.summary.issues || {}).forEach(([k, n]) => (agg[k] = (agg[k] || 0) + n)));
  $("#indiaIssues").innerHTML = Object.entries(ISSUE).filter(([k]) => agg[k]).map(([k, [lab, c]]) =>
    `<div class="issue-row"><span class="dot" style="background:${c}"></span>${lab}<span class="n">${agg[k]}</span></div>`).join("") || `<p class="muted small">No issues found.</p>`;
  $("#locTable tbody").innerHTML = S.locations.map(l => {
    const s = l.summary;
    return `<tr class="clickable" data-loc="${l.id}"><td>${esc(l.state)}</td><td><b>${esc(l.city)}</b><div class="muted small">${esc(l.district)}${l.synthetic ? " · pilot (synthetic)" : ""}</div></td>
      <td class="mono">${l.state_code_lgd ?? "–"}</td><td class="mono">${l.utm_epsg ? "EPSG:" + l.utm_epsg : "–"}</td>
      <td>${l.datasets.map(d => `<span class="issue">${esc(d)}</span>`).join("") || '<span class="muted">none yet</span>'}</td>
      <td>${s ? s.total_parcels : "–"}</td><td>${s ? `<b style="color:var(--good)">${s.verified}</b>` : "–"}</td>
      <td>${s ? `<b style="color:var(--warn)">${s.needs_review}</b>` : "–"}</td><td>${s ? s.average_confidence : "–"}</td>
      <td><button class="btn small">${s ? "Open →" : "Upload data →"}</button></td></tr>`;
  }).join("");
  $$("#locTable tbody tr").forEach(tr => tr.addEventListener("click", () => {
    const l = S.locations.find(x => x.id === tr.dataset.loc);
    l.summary ? go("map", l.id) : (S.loc = l.id, go("upload"));
  }));
  if (typeof L === "undefined") return;
  if (!indiaMap) {
    indiaMap = L.map("indiaMap", { zoomControl: true, scrollWheelZoom: false }).setView([22.5, 80], 5);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "© OpenStreetMap contributors" }).addTo(indiaMap);
    indiaLayer = L.layerGroup().addTo(indiaMap);
  }
  indiaLayer.clearLayers();
  S.locations.forEach(l => {
    if (!l.center) return;
    const s = l.summary, share = s ? s.verified / Math.max(1, s.total_parcels) : 0;
    const col = !s ? "#9C8A6E" : share >= 0.75 ? "#4C8C5A" : share >= 0.5 ? "#C9840A" : "#B0432E";
    L.circleMarker(l.center, { radius: s ? 8 + Math.sqrt(s.total_parcels) * 1.6 : 7, color: "#fff", weight: 2, fillColor: col, fillOpacity: 0.9 })
      .bindTooltip(`<b>${esc(l.city)}</b>, ${esc(l.state)}<br>${s ? `${s.total_parcels} parcels · ${s.verified} verified · ${s.needs_review} need officer` : "no data yet"}`)
      .on("click", () => (s ? go("map", l.id) : (S.loc = l.id, go("upload")))).addTo(indiaLayer);
  });
  setTimeout(() => indiaMap.invalidateSize(), 60);
}

/* ---------------- new location ---------------- */
async function openNewLocation() {
  if (!can("upload")) { toast("Only a GIS Data Officer or admin can add a location — log out and sign in as gis.officer", true); return; }
  if (!S.states.length) S.states = await api("/api/states");
  $("#nlState").innerHTML = S.states.map(s => `<option>${esc(s.name)}</option>`).join("");
  $("#nlError").hidden = true; $("#newLocModal").hidden = false;
}
$("#newLocBtn").onclick = openNewLocation; $("#upNewLoc").onclick = openNewLocation;
$("#newLocForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const m = await api("/api/locations", { method: "POST", body: JSON.stringify({ state: $("#nlState").value, district: $("#nlDistrict").value, city: $("#nlCity").value, urban_local_body: $("#nlUlb").value }) });
    $("#newLocModal").hidden = true; await loadLocations(); S.loc = m.id; $("#upLoc").value = m.id;
    toast(`Created ${m.city} (${m.id}). Upload its cadastral map first.`); go("upload");
  } catch (err) { $("#nlError").textContent = err.message; $("#nlError").hidden = false; }
});

/* ---------------- map console ---------------- */
let map = null, L_parcels, L_detected, L_build, L_util, L_gnss, L_orig;
const polyById = {};
function initMap() {
  if (typeof L === "undefined") { $("#mapBadge").textContent = "Map library failed to load"; return; }
  map = L.map("realMap", { zoomSnap: 0.25 }).setView([20.5, 79], 5);
  const tiles = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 20, maxNativeZoom: 19, attribution: "© OpenStreetMap contributors" }).addTo(map);
  let ok = false, errs = 0;
  tiles.on("tileload", () => { if (!ok) { ok = true; $("#mapBadge").textContent = "OpenStreetMap · live"; } });
  tiles.on("tileerror", () => { if (!ok && ++errs >= 3) $("#mapBadge").textContent = "Offline: base map unavailable, data still works"; });
  L_orig = L.layerGroup().addTo(map); L_parcels = L.layerGroup().addTo(map); L_detected = L.layerGroup().addTo(map);
  L_build = L.layerGroup().addTo(map); L_util = L.layerGroup().addTo(map); L_gnss = L.layerGroup().addTo(map);
  $("#fitBtn").onclick = fitParcels;
  [["#lyrDetected", () => L_detected], ["#lyrBuild", () => L_build], ["#lyrUtil", () => L_util], ["#lyrGnss", () => L_gnss]].forEach(([id, g]) =>
    ($(id).onchange = e => (e.target.checked ? g().addTo(map) : g().remove())));
  $("#runBtn").onclick = async () => {
    const b = $("#runBtn"); b.disabled = true; b.textContent = "Running…";
    try { const r = await api(`/api/locations/${S.loc}/run`, { method: "POST" }); await refreshLocation(); toast(`Re-ran all checks on ${r.summary.total_parcels} parcels in ${r.elapsed_seconds} s`); }
    catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = "▶ Re-run";
  };
}
function fitParcels() { const p = Object.values(polyById); if (p.length && map) map.fitBounds(L.featureGroup(p).getBounds(), { padding: [30, 30] }); }
function utilityBuffer(line, m) {
  const out = [];
  for (let i = 0; i < line.length - 1; i++) {
    const a = line[i], b = line[i + 1];
    const mLat = 111320, mLon = 111320 * Math.cos(a[0] * Math.PI / 180);
    const dx = (b[1] - a[1]) * mLon, dy = (b[0] - a[0]) * mLat, len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len * m, ny = dx / len * m;
    const off = (p, s) => [p[0] + s * ny / mLat, p[1] + s * nx / mLon];
    out.push([off(a, 1), off(b, 1), off(b, -1), off(a, -1)]);
  }
  return out;
}
function drawMap(fit) {
  if (!map || !S.data) return;
  [L_orig, L_parcels, L_detected, L_build, L_util, L_gnss].forEach(g => g.clearLayers());
  for (const k in polyById) delete polyById[k];
  S.data.parcels.forEach(p => {
    const c = KIND_COLOR[kindOf(p.status)];
    if (p.corrected) L.polygon(p.original_polygon, { color: "#8a8a8a", weight: 1.5, dashArray: "2 5", fill: false, interactive: false }).addTo(L_orig);
    const poly = L.polygon(p.polygon, { color: c, weight: p.parcel_id === S.selected ? 4 : 2, fillColor: c, fillOpacity: 0.3 }).addTo(L_parcels);
    poly.bindTooltip(`${p.parcel_id} · ${p.score}${p.issues.length ? " · " + p.issues.map(i => ISSUE[i] ? ISSUE[i][0] : i).join(", ") : ""}`, { className: "pid-tip", sticky: true });
    poly.on("click", () => { history.replaceState(null, "", `#map/${S.loc}/${p.parcel_id}`); selectParcel(p.parcel_id, false); });
    polyById[p.parcel_id] = poly;
    const b = p.checks.boundary;
    if (b.detected && (b.offset_m > 1 || p.issues.includes("overlap")))
      L.polygon(b.detected, { color: "#D2372A", weight: 2, dashArray: "6 5", fill: false, interactive: false }).addTo(L_detected);
    (p.checks.buildings.buildings || []).forEach(x => L.polygon(x.polygon, { color: "#E0A800", weight: 1, fillOpacity: 0.05, interactive: false }).addTo(L_build));
    (p.checks.buildings.new || []).forEach(x => L.polygon(x.polygon, { color: "#C02AC8", weight: 2, fillColor: "#C02AC8", fillOpacity: 0.45, interactive: false }).addTo(L_build));
  });
  (S.data.utilities || []).forEach(u => {
    utilityBuffer(u.line, u.buffer_m).forEach(q => L.polygon(q, { stroke: false, fillColor: "#2B6CB0", fillOpacity: 0.16, interactive: false }).addTo(L_util));
    L.polyline(u.line, { color: "#2B6CB0", weight: 3 }).bindTooltip(`${esc(u.name)} · ${u.buffer_m} m easement`).addTo(L_util);
  });
  (S.data.gnss_points || []).forEach(g => L.circleMarker([g.lat, g.lon], { radius: 3.5, color: "#fff", weight: 1, fillColor: "#1E8E3E", fillOpacity: 1 }).bindTooltip("GNSS " + esc(g.point_id)).addTo(L_gnss));
  if (fit) fitParcels();
}

function renderSidebar() {
  const d = S.data, s = d.summary, l = d.location;
  const ds = d.datasets.map(x => `<div class="ds"><b>${esc({ cadastral: "Cadastral map", revenue: "Revenue records", municipal: "Municipal records", utilities: "Utility lines", imagery: "Drone ORI", surface: "DSM / DTM", gnss: "GNSS survey" }[x.type] || x.type)}</b><span>${esc(x.source || "")}${x.version ? " · v" + x.version : ""}${x.area_unit ? " · area in " + esc(x.area_unit.replace("_", " ")) : ""}${x.script && x.script !== "Latin" ? " · " + esc(x.script) + " script" : ""}</span></div>`).join("");
  $("#sidebar").innerHTML = `
    <div class="loc-title">${esc(l.city)}</div>
    <div class="loc-sub">${esc(l.district)} · ${esc(l.state)} · LGD ${l.state_code_lgd ?? "–"}${l.utm_epsg ? " · EPSG:" + l.utm_epsg : ""}</div>
    <div class="stat-grid">
      <div class="stat"><div class="stat-num">${s.total_parcels}</div><div class="stat-label">parcels</div></div>
      <div class="stat good"><div class="stat-num">${s.verified}</div><div class="stat-label">verified</div></div>
      <div class="stat warn"><div class="stat-num">${s.needs_review}</div><div class="stat-label">need an officer</div></div>
      <div class="stat purple"><div class="stat-num">${s.total_parcels - s.verified - s.needs_review}</div><div class="stat-label">survey / enquiry</div></div>
    </div>
    <div class="row" style="margin-top:8px"><span>Average confidence</span><b>${s.average_confidence}</b></div>
    <div class="row"><span>Auto-approved by AI</span><b>${s.auto_verified} of ${s.total_parcels}</b></div>
    <div class="row"><span>Harmonized in</span><b>${s.elapsed_seconds} s</b></div>
    <div class="sb-section"><div class="sb-title">What the checks found</div>
      ${Object.entries(ISSUE).map(([k, [lab, c]]) => `<div class="row"><span><i class="dot" style="background:${c}"></i> ${lab}</span><b>${s.issues[k] || 0}</b></div>`).join("")}
      ${s.unlinked_revenue || s.unlinked_municipal ? `<div class="row"><span>Records not linked to any parcel</span><b>${s.unlinked_revenue + s.unlinked_municipal}</b></div>` : ""}
    </div>
    <div class="sb-section"><div class="sb-title">Data sources</div>${ds}</div>
    <div class="sb-section"><div class="sb-title">Share with other departments</div>
      <div class="btn-row"><a class="btn small" href="${withTok(`/api/locations/${l.id}/export.geojson`)}">GeoJSON</a><a class="btn small" href="${withTok(`/api/locations/${l.id}/export.csv`)}">CSV</a><a class="btn small" href="${withTok(`/ogc/collections/${l.id}-parcels/items`)}" target="_blank">OGC API</a></div>
      ${can("certify", l.id) ? `<button class="btn primary wide" id="certifyBtn" style="margin-top:8px">Certify verified parcels</button>` : ""}
    </div>`;
  const cb = $("#certifyBtn"); if (cb) cb.onclick = certify;
}

/* ---------------- drawer ---------------- */
function selectParcel(id, pan) {
  S.selected = id;
  Object.entries(polyById).forEach(([pid, l]) => l.setStyle({ weight: pid === id ? 4 : 2 }));
  if (pan && polyById[id] && map) map.fitBounds(polyById[id].getBounds(), { maxZoom: 19, padding: [70, 70] });
  renderDrawer();
}
function evidenceBlock(p) {
  if (!p.has_imagery) return `<p class="muted small">No drone imagery for this parcel.</p>`;
  const b = p.checks.buildings, t = Date.now();
  const yrs = p.surveys.length ? `${p.surveys[0]}→${p.surveys[p.surveys.length - 1]}` : "";
  const tabs = [["evidence", "Drone evidence"], ["change", "Change " + yrs], ["height", "Heights (DSM−DTM)"], ["surveys", "All surveys"]];
  let body = "";
  if (S.evTab === "evidence") body = `<img class="img-main" src="${withTok(`/api/locations/${S.loc}/parcels/${p.parcel_id}/evidence.jpg?t=${t}`)}" data-zoom="Drone evidence · ${p.parcel_id}"><div class="img-caption">Cyan = record · red = wall found by AI · yellow = buildings · magenta = new since ${p.surveys[0] || "first survey"} · green ✕ = GNSS points · blue = utility easement</div>`;
  if (S.evTab === "change") body = `<img class="img-main" src="${withTok(`/api/locations/${S.loc}/parcels/${p.parcel_id}/change.jpg?t=${t}`)}" data-zoom="Change ${yrs} · ${p.parcel_id}"><div class="img-caption">Left ${p.surveys[0]}, right ${p.surveys[p.surveys.length - 1]}. Roof pixels are compared on the same georeferenced ground, so lighting and trees don't trigger false changes. ${b.new && b.new.length ? `<b>New: ${fmt(b.new.reduce((a, x) => a + x.area_m2, 0), 1)} sq.m</b>` : "No new construction."}</div>`;
  if (S.evTab === "height") body = `<img class="img-main" src="${withTok(`/api/locations/${S.loc}/parcels/${p.parcel_id}/ndsm.png?t=${t}`)}" data-zoom="Height above ground · ${p.parcel_id}"><div class="img-caption">Height above ground = DSM (surface) − DTM (terrain). Building height ÷ 3.1 m per floor gives the number of floors.</div>`;
  if (S.evTab === "surveys") body = `<div class="thumbs" style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">${p.surveys.map(y => `<figure><img src="${withTok(`/imagery/${S.loc}/${p.parcel_id}/ori_${y}.jpg`)}" style="width:100%;border-radius:5px;border:1px solid var(--line);cursor:zoom-in" data-zoom="${p.parcel_id} · ORI ${y}"><figcaption class="muted small" style="text-align:center">${y}</figcaption></figure>`).join("")}</div>`;
  return `<div class="ev-tabs">${tabs.map(([k, l]) => `<button class="ev-tab ${S.evTab === k ? "active" : ""}" data-ev="${k}">${l}</button>`).join("")}</div>${body}`;
}
function renderDrawer() {
  const d = $("#drawer");
  const p = S.data && S.data.parcels.find(x => x.parcel_id === S.selected);
  if (!p) { d.innerHTML = `<div class="drawer-empty">Click a parcel on the map.</div>`; return; }
  const kind = kindOf(p.status), col = KIND_COLOR[kind], th = S.data.summary.auto_approve_threshold;
  const br = p.score_breakdown || {}, lost = Object.values(br).reduce((a, x) => a + x, 0);
  const b = p.checks.boundary, bl = p.checks.buildings, om = p.owner_match;
  const segs = Object.entries(br).map(([k, v]) => `<div class="bd-seg" style="width:${v}%;background:${(PENALTY[k] || [k, "#888"])[1]}" title="${(PENALTY[k] || [k])[0]} −${v}">−${v}</div>`).join("");

  // decision area
  let decision = "";
  if (p.decision) {
    const dd = p.decision;
    decision = `<div class="decision-card ${kindOf(dd.status) === "purple" ? "purple" : ""}"><b>${esc(dd.status)}</b> · v${dd.version}<br>
      <ul>${(dd.changes || []).map(c => `<li>${esc(c)}</li>`).join("")}</ul>
      <span class="muted">By ${esc(dd.officer)} · ${esc(new Date(dd.decided_at).toLocaleString())}</span><br><span class="muted">Remarks:</span> ${esc(dd.remarks)}
      ${can("decide", S.loc) ? `<div style="margin-top:8px"><button class="btn small" data-act="UNDO">Undo decision</button></div>` : ""}</div>`;
  }
  let actions = "";
  const needs = !p.status.startsWith("Verified") || p.recommendations.length;
  if (!p.decision && needs) {
    if (!S.user) actions = `<div class="locked">Log in as the Revenue Inspector or Tahsildar for ${esc(S.data.location.city)} to decide.<br><button class="btn small" data-login>Officer login</button></div>`;
    else if (!can("decide", S.loc)) actions = `<div class="locked">${esc(S.user.name)} (${esc(S.user.role)}) can view but not decide parcels in ${esc(S.data.location.city)}. Decisions are made by the Revenue Inspector or Tahsildar with jurisdiction here.<br><button class="btn small" data-login>Sign in as another officer</button></div>`;
    else actions = `<div class="actions"><textarea id="remarks" placeholder="Remarks (e.g. 'Checked sale deed dated 12-03-2019; surveyor confirmed corners')"></textarea>
      ${p.recommendations.length ? `<button class="btn primary" data-act="APPLY_RECOMMENDATIONS">✓ Apply the recommended action${p.recommendations.length > 1 ? "s" : ""}</button>` : ""}
      <button class="btn" data-act="ACCEPT_RECORD">✓ The record is correct as it is</button>
      <div class="btn-row"><button class="btn" data-act="ORDER_GNSS_SURVEY">⌖ Order GNSS survey</button><button class="btn" data-act="FIELD_ENQUIRY">⚑ Field enquiry</button></div></div>`;
  }

  const recs = p.recommendations.map(r => `<div class="rec"><b>${esc(ACTION_TEXT[r.action] || r.action)}</b> — ${esc(r.text)}<span class="src">Based on: ${esc(r.source)} · confidence <span class="conf-${r.confidence}">${r.confidence}</span></span></div>`).join("");

  // owners
  let owners = "";
  if (p.revenue || p.municipal) {
    const rv = p.revenue || {}, mu = p.municipal || {};
    const pr = om ? om.probability : null;
    const pc = pr === null ? "#999" : pr >= 0.8 ? "#4C8C5A" : pr >= 0.5 ? "#C9840A" : "#B0432E";
    owners = `<div class="sec">Owner in each department</div><div class="cmp">
      <div class="cmp-row"><span>Revenue (record of rights)</span><span class="indic">${esc(rv.owner_name || "— not found —")}${om && om.scripts[0] !== "Latin" ? `<br><span class="muted small">${esc(om.scripts[0])}: “${esc(om.transliterated[0])}”</span>` : ""}</span></div>
      <div class="cmp-row"><span>Municipal (property tax)</span><span class="indic">${esc(mu.owner_name || "— not found —")}${p.decision && p.decision.municipal_owner_override ? `<br><span class="muted small">updated to Revenue owner</span>` : ""}</span></div>
      <div class="cmp-row"><span>Father / guardian</span><span class="indic">${esc(rv.father_name || "–")} / ${esc(mu.father_name || "–")}</span></div>
      ${om ? `<div class="cmp-row ${pr >= 0.8 ? "good" : pr < 0.5 ? "bad" : ""}"><span>AI: same person?</span><span>${Math.round(pr * 100)}% · ${esc(om.verdict)}</span></div>` : ""}
      ${p.municipal_link ? `<div class="cmp-row"><span>Municipal record linked by</span><span>map location (${esc(p.municipal_link)})</span></div>` : ""}
    </div>
    ${om ? `<div class="pbar"><div style="width:${Math.round(pr * 100)}%;background:${pc}"></div></div>
      <div class="img-caption">${om.agrees_on.length ? "Agrees: " + esc(om.agrees_on.join(", ")) + ". " : ""}${om.differs_on.length ? "Differs: " + esc(om.differs_on.join(", ")) + ". " : ""}Model ${esc(om.model_version)}.</div>
      ${can("decide", S.loc) ? `<div class="btn-row" style="margin-top:6px"><span class="muted small" style="align-self:center">Teach the AI:</span><button class="btn small" data-label="1">Same person</button><button class="btn small" data-label="0">Different people</button></div>` : ""}` : ""}`;
  }

  // boundary
  const bstate = { matches: "matches the record", shifted: "differs from the record", "partly hidden": "partly hidden by trees / shadow", unclear: "not clearly visible", "no imagery": "no imagery" }[b.state] || b.state;
  const boundary = `<div class="sec">Boundary</div><div class="cmp">
    <div class="cmp-row ${b.state === "shifted" ? "bad" : b.state === "matches" ? "good" : ""}"><span>Wall in drone image</span><span>${esc(bstate)}${b.state === "shifted" || b.state === "matches" ? ` (${b.offset_m} m)` : ""}</span></div>
    <div class="cmp-row"><span>Recorded area</span><span>${fmt(p.area_m2, 1)} sq.m${p.revenue && p.revenue.area_sq_m ? ` · revenue says ${fmt(p.revenue.area_sq_m, 1)} sq.m` : ""}</span></div>
    ${b.gnss_points ? `<div class="cmp-row ${b.gnss_vs_record_m > 2 ? "bad" : "good"}"><span>GNSS survey (${b.gnss_points} points)</span><span>${b.gnss_vs_record_m} m from record${b.gnss_vs_drone_m !== null ? ` · ${b.gnss_vs_drone_m} m from drone` : ""}</span></div>` : ""}
    ${p.checks.topology.overlaps.map(o => `<div class="cmp-row bad"><span>Overlaps ${esc(o.with)}</span><span>${o.area_m2} sq.m · caused by ${esc(o.cause || "?")}</span></div>`).join("")}
    ${p.checks.utilities.map(u => `<div class="cmp-row bad"><span>${esc(u.name)}</span><span>${u.clearance_m} m clearance (needs ${u.buffer_m} m)</span></div>`).join("")}
    ${p.corrected ? `<div class="cmp-row good"><span>Record</span><span>corrected by officer (old boundary dotted grey)</span></div>` : ""}
  </div>
  <details class="trust"><summary>Which source wins?</summary><ol>${S.data.trust_order.boundary.map(x => `<li>${esc(x)}</li>`).join("")}</ol>Ownership: ${esc(S.data.trust_order.ownership.join(" › "))}. Buildings: ${esc(S.data.trust_order.building.join(" › "))}.</details>`;

  const buildings = `<div class="sec">Buildings</div><div class="cmp">
    <div class="cmp-row"><span>Footprint measured (${p.surveys[p.surveys.length - 1] || ""})</span><span>${fmt(bl.footprint_m2, 1)} sq.m</span></div>
    <div class="cmp-row"><span>Built-up in municipal record</span><span>${fmt(bl.recorded_built_up_m2, 1)} sq.m</span></div>
    <div class="cmp-row ${p.issues.includes("extra_floors") ? "bad" : ""}"><span>Floors: measured / recorded</span><span>${bl.floors_est ?? "–"}${bl.height_m ? ` (${bl.height_m} m tall)` : ""} / ${bl.recorded_floors ?? "–"}</span></div>
    ${bl.new && bl.new.length ? `<div class="cmp-row bad"><span>New since ${bl.change_years[0]}</span><span>${fmt(bl.new.reduce((a, x) => a + x.area_m2, 0), 1)} sq.m</span></div>` : ""}
  </div>`;

  const rv = p.revenue || {}, mu = p.municipal || {};
  const records = `<details class="trust" style="margin-top:14px"><summary>Full records</summary>
    <div class="kv" style="margin-top:8px"><div class="k">Survey no.</div><div class="v">${esc(p.survey_number)}</div>
    <div class="k">Khata no.</div><div class="v">${esc(rv.khata_number || "–")}</div><div class="k">Land use</div><div class="v">${esc(rv.land_use || "–")}</div>
    <div class="k">Document</div><div class="v">${esc(rv.document_type || "–")} · ${esc(rv.registration_date || "")}</div>
    <div class="k">Assessment no.</div><div class="v">${esc(mu.assessment_number || "–")}</div><div class="k">Ward</div><div class="v">${esc(mu.ward || "–")}</div>
    <div class="k">ULPIN-style ID</div><div class="v mono">${esc(p.ulpin_style_id)}</div></div></details>`;

  d.innerHTML = `
    <div class="dr-head"><span class="dr-id">${p.parcel_id}</span><span class="status ${kind}">${esc(p.status)}</span></div>
    <div class="dr-sub">${esc(p.village)} · Survey no. ${esc(p.survey_number)}</div>
    <div class="conf-label"><span>Confidence${p.decision && p.auto_score !== p.score ? ` <span class="muted">(AI score ${p.auto_score} before officer review)</span>` : ""}</span><b style="color:${col}">${p.score}/100</b></div>
    <div class="conf-bar"><div class="conf-bar-fill" style="width:${p.score}%;background:${col}"></div><div class="conf-thresh" style="left:${th}%"></div><div class="conf-thresh-label" style="left:${th}%">auto-approve ${th}</div></div>
    <div class="bd-bar">${segs}<div class="bd-keep">${lost ? "" : "No deductions"}</div></div>
    ${lost ? `<div class="bd-legend">${Object.entries(br).map(([k, v]) => `<span><i class="dot" style="background:${(PENALTY[k] || [k, "#888"])[1]}"></i>${(PENALTY[k] || [k])[0]} −${v}</span>`).join("")}</div>` : ""}
    <div class="sec">What BhuMilan found</div><div class="note"><ul>${p.reasons.map(r => `<li>${esc(r)}</li>`).join("")}</ul></div>
    ${recs ? `<div class="sec">Recommended</div>${recs}` : ""}
    ${decision || actions ? `<div class="sec">Officer decision</div>${decision}${actions}` : ""}
    <div class="sec">Evidence</div>${evidenceBlock(p)}
    ${boundary}${owners}${buildings}${records}`;

  $$("[data-ev]", d).forEach(bt => (bt.onclick = () => { S.evTab = bt.dataset.ev; renderDrawer(); }));
  $$("[data-zoom]", d).forEach(im => (im.onclick = () => openImage(im.src, im.dataset.zoom)));
  $$("[data-act]", d).forEach(bt => (bt.onclick = () => decide(p.parcel_id, bt.dataset.act)));
  $$("[data-label]", d).forEach(bt => (bt.onclick = () => labelOwner(p.parcel_id, bt.dataset.label === "1")));
}
async function decide(pid, action) {
  const remarks = ($("#remarks") || {}).value || "";
  $$("[data-act]").forEach(b => (b.disabled = true));
  try {
    const r = await api(`/api/locations/${S.loc}/parcels/${pid}/decide`, { method: "POST", body: JSON.stringify({ action, remarks }) });
    toast(`${pid}: ${r.changes.join("; ")} — saved to the audit ledger`);
    await refreshLocation();
  } catch (e) { toast(e.message, true); $$("[data-act]").forEach(b => (b.disabled = false)); }
}
async function labelOwner(pid, same) {
  try { const r = await api(`/api/locations/${S.loc}/parcels/${pid}/owner-label`, { method: "POST", body: JSON.stringify({ same_person: same }) }); toast(`Thanks - ${r.labels_collected} officer label(s) collected for retraining`); }
  catch (e) { toast(e.message, true); }
}
async function certify() {
  try {
    const r = await api(`/api/locations/${S.loc}/certify`, { method: "POST" });
    $("#infoTitle").textContent = "Batch certified";
    $("#infoBody").innerHTML = `<div class="kv"><div class="k">Batch ID</div><div class="v mono">${esc(r.batch_id)}</div>
      <div class="k">Certified</div><div class="v"><b>${r.certified_count}</b> of ${r.total_parcels} parcels</div>
      <div class="k">Still pending</div><div class="v">${r.pending_parcels.length ? r.pending_parcels.map(esc).join(", ") : "None"}</div>
      <div class="k">Certified by</div><div class="v">${esc(r.officer)}</div><div class="k">Batch hash</div><div class="v mono">${esc(r.batch_hash)}</div>
      <div class="k">Ledger entry</div><div class="v mono">#${r.ledger_entry.index}</div></div>`;
    $("#infoModal").hidden = false;
  } catch (e) { toast(e.message, true); }
}

/* ---------------- review queue ---------------- */
$$("#queueFilters .chip").forEach(c => c.addEventListener("click", () => {
  S.queueFilter = c.dataset.filter; $$("#queueFilters .chip").forEach(x => x.classList.toggle("active", x === c)); renderQueue();
}));
function renderQueue() {
  if (!S.data) return;
  const f = S.queueFilter;
  const rows = S.data.parcels.filter(p => {
    const k = kindOf(p.status);
    return f === "all" || (f === "review" && (k === "warn" || k === "bad")) || (f === "ordered" && k === "purple") || (f === "verified" && k === "good");
  }).sort((a, b) => a.score - b.score);
  $("#queueEmpty").hidden = rows.length > 0;
  $("#queueTable tbody").innerHTML = rows.map(p => {
    const k = kindOf(p.status), c = KIND_COLOR[k];
    const iss = p.issues.map(i => `<span class="issue" style="border-color:${(ISSUE[i] || ["", "#999"])[1]}88">${esc((ISSUE[i] || [i])[0])}</span>`).join("") || `<span class="muted">—</span>`;
    const rec = p.recommendations.map(r => esc(ACTION_TEXT[r.action] || r.action)).join(", ") || "—";
    return `<tr class="clickable" data-id="${p.parcel_id}"><td class="mono">${p.parcel_id}</td><td>${esc(p.village)}</td>
      <td><b style="color:${c}">${p.score}</b><div class="mini-bar"><div style="width:${p.score}%;background:${c}"></div></div></td>
      <td>${iss}</td><td class="small">${rec}</td><td><span class="status ${k}">${esc(p.status)}</span></td><td><button class="btn small">Open →</button></td></tr>`;
  }).join("");
  $$("#queueTable tbody tr").forEach(tr => tr.addEventListener("click", () => go("map", S.loc, tr.dataset.id)));
}

/* ---------------- upload ---------------- */
function renderUpload() {
  const allowed = can("upload");
  $("#uploadLocked").hidden = allowed; $("#uploadForm").style.opacity = allowed ? 1 : 0.45; $("#uploadForm").style.pointerEvents = allowed ? "auto" : "none";
  if (S.loc) $("#upLoc").value = S.loc;
  $("#upTypes").innerHTML = DTYPES.map(([k, t, dsc]) => `<button class="dtype ${S.upType === k ? "active" : ""}" data-t="${k}"><b>${t}</b><span>${dsc}</span></button>`).join("");
  $$(".dtype").forEach(b => (b.onclick = () => { S.upType = b.dataset.t; renderUpload(); }));
}
const drop = $("#upDrop");
["dragover", "dragenter"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
drop.addEventListener("drop", e => { if (e.dataTransfer.files[0]) setUpFile(e.dataTransfer.files[0]); });
$("#upFile").addEventListener("change", e => e.target.files[0] && setUpFile(e.target.files[0]));
function setUpFile(f) { S.upFile = f; $("#upFileName").textContent = `${f.name} · ${fmt(f.size / 1024, 1)} KB`; $("#upPreviewBtn").disabled = false; $("#upResult").innerHTML = ""; }
const toB64 = f => new Promise((ok, bad) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(",")[1] || ""); r.onerror = bad; r.readAsDataURL(f); });
$("#upPreviewBtn").onclick = async () => {
  const btn = $("#upPreviewBtn"); btn.disabled = true; btn.textContent = "Reading…";
  try {
    const b64 = await toB64(S.upFile);
    S.upB64 = b64;
    S.upPreview = await api("/api/upload/preview", { method: "POST", body: JSON.stringify({ location: $("#upLoc").value, dataset_type: S.upType, filename: S.upFile.name, content_base64: b64 }) });
    renderPreview();
  } catch (e) { toast(e.message, true); }
  btn.disabled = false; btn.textContent = "Check file";
};
function unitSelect(sel) {
  const guess = sel ? UNITS.find(u => Math.abs(u[2] - sel) < 1e-6) : null;
  return `<select data-unit>${`<option value="">— choose unit —</option>` + UNITS.map(u => `<option value="${u[2]}" ${guess && guess[0] === u[0] ? "selected" : ""}>${u[1]}</option>`).join("")}</select>`;
}
function renderPreview() {
  const pv = S.upPreview, r = pv.report;
  const rows = pv.columns.map(c => {
    const conf = c.confidence >= 0.9 ? "hi" : c.confidence >= 0.7 ? "mid" : "lo";
    const isArea = ["area", "built_up_area"].includes(c.field);
    return `<tr data-col="${esc(c.column)}"><td class="indic"><b>${esc(c.column)}</b><div class="muted small">e.g. ${esc(c.sample)}</div></td>
      <td><select data-field><option value="">— keep as extra info —</option>${pv.fields.map(f => `<option ${c.field === f ? "selected" : ""}>${f}</option>`).join("")}</select>
      ${isArea ? `<div style="margin-top:4px">${unitSelect(c.unit_m2)}</div>` : ""}</td>
      <td>${c.field ? `<span class="badge ${conf}">${Math.round(c.confidence * 100)}%</span>` : ""}<div class="muted small">${esc(c.reason)}</div></td></tr>`;
  }).join("");
  const prevCols = pv.preview.length ? Object.keys(pv.preview[0]) : [];
  $("#upResult").innerHTML = `
    <div class="report">
      <div class="kpi"><div class="n">${esc(pv.format)}</div><div class="l">format detected</div></div>
      <div class="kpi"><div class="n">${pv.rows}</div><div class="l">rows in file</div></div>
      <div class="kpi ${r.rows_ok === r.rows_in ? "good" : "warn"}"><div class="n">${r.rows_ok}</div><div class="l">rows valid</div></div>
      <div class="kpi"><div class="n" style="font-size:14px;font-family:var(--sans)">${esc(pv.crs)}</div><div class="l">coordinate system</div></div>
    </div>
    ${r.problems.length ? `<div class="problems"><b>${r.problems.length} problem(s):</b><br>${r.problems.map(esc).join("<br>")}</div>` : ""}
    <div class="card" style="margin-top:12px"><div class="card-title">Column mapping — check and correct, then save</div>
      <div class="table-card"><table class="table map-table"><thead><tr><th>Your column</th><th>BhuMilan field</th><th>Why</th></tr></thead><tbody>${rows}</tbody></table></div>
      ${pv.preview.length ? `<div class="card-title" style="margin-top:14px">Preview after conversion</div><div class="table-card"><table class="table"><thead><tr>${prevCols.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${pv.preview.map(row => `<tr>${prevCols.map(c => `<td class="small indic">${esc(typeof row[c] === "number" ? fmt(row[c], 6) : row[c])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : ""}
      <button class="btn primary" id="upCommit" style="margin-top:12px">Save to ${esc($("#upLoc").selectedOptions[0]?.textContent || "")}</button>
    </div>`;
  $("#upCommit").onclick = commitUpload;
}
async function commitUpload() {
  const mapping = {}, units = {};
  $$("#upResult tr[data-col]").forEach(tr => {
    const f = $("select[data-field]", tr).value; mapping[tr.dataset.col] = f || null;
    const u = $("select[data-unit]", tr); if (f && u && u.value) units[f] = parseFloat(u.value);
  });
  try {
    const r = await api("/api/upload/commit", { method: "POST", body: JSON.stringify({ location: $("#upLoc").value, dataset_type: S.upType, filename: S.upFile.name, content_base64: S.upB64, mapping, units, source: $("#upSource").value }) });
    await loadLocations();
    const loc = $("#upLoc").value;
    $("#upResult").innerHTML = `<div class="verify-banner ok"><span class="big">✓</span><div><b>Saved as version ${r.dataset.version}.</b> ${r.report.rows_ok} rows · ${esc(r.report.crs)}. The original file is kept for audit and the upload is in the ledger.
      <div style="margin-top:8px"><button class="btn small" id="upOpen">Open ${esc(loc)} in the map console →</button></div></div></div>`;
    $("#upOpen").onclick = () => { S.loc = null; go("map", loc); };
  } catch (e) { toast(e.message, true); }
}

/* ---------------- ledger ---------------- */
async function loadLedger() {
  try {
    const q = $("#ledgerThisLoc").checked && S.loc ? `?location=${S.loc}` : "";
    const { entries } = await api("/api/audit-log" + q);
    const show = $("#showLogins").checked;
    const res = S.lastVerify ? Object.fromEntries(S.lastVerify.results.map(r => [r.index, r])) : {};
    $("#ledgerTable tbody").innerHTML = entries.filter(e => show || e.action !== "OFFICER_LOGIN").reverse().map(e => {
      const r = res[e.index];
      const chk = !r ? `<span class="muted">—</span>` : r.ok ? `<span class="ok-mark">✓</span>` : `<span class="bad-mark">✗ ${esc(r.reason)}</span>`;
      return `<tr class="${r && !r.ok ? "broken" : ""}"><td class="mono">${e.index}</td><td class="mono small">${esc(new Date(e.timestamp).toLocaleString())}</td>
        <td class="mono small">${esc(e.action)}</td><td class="mono small">${esc(e.location)}</td><td class="mono small">${esc(e.parcel_id)}</td><td class="small">${esc(e.officer_id)}</td>
        <td class="small">${esc(e.details)}</td><td><div class="hash" title="${esc(e.block_hash)}">${esc(e.block_hash.slice(0, 10))}…</div><div class="hash">← ${esc(e.prev_hash.slice(0, 8))}…</div></td><td>${chk}</td></tr>`;
    }).join("");
  } catch (e) { toast(e.message, true); }
}
async function verifyLedger() {
  try {
    const v = await api("/api/audit-log/verify"); S.lastVerify = v;
    const bn = $("#verifyBanner"); bn.hidden = false;
    bn.className = "verify-banner " + (v.valid ? "ok" : "bad");
    bn.innerHTML = v.valid ? `<span class="big">✓</span><div><b>Chain intact.</b> All ${v.checked} entries match their hashes — nothing has been changed since it was written.</div>`
      : `<span class="big">✗</span><div><b>Tampering detected at entry #${v.broken_at}.</b> Its content no longer matches the hash stored when it was written, so it and every later entry can't be trusted.</div>`;
    await loadLedger();
  } catch (e) { toast(e.message, true); }
}
$("#verifyBtn").onclick = verifyLedger; $("#showLogins").onchange = loadLedger; $("#ledgerThisLoc").onchange = loadLedger;
$("#tamperBtn").onclick = async () => { try { const r = await api("/api/demo/tamper", { method: "POST" }); toast(r.status + " — now click Verify chain"); S.lastVerify = null; $("#verifyBanner").hidden = true; loadLedger(); } catch (e) { toast(e.message, true); } };
$("#restoreBtn").onclick = async () => { try { const r = await api("/api/demo/restore", { method: "POST" }); toast(r.status); await verifyLedger(); } catch (e) { toast(e.message, true); } };
$("#resetBtn").onclick = async () => {
  if (!confirm("Clear all officer decisions in every location for a fresh demo? The ledger keeps its history.")) return;
  try { const r = await api("/api/demo/reset", { method: "POST" }); toast(r.status); await loadLocations(); if (S.loc) await refreshLocation(); loadLedger(); } catch (e) { toast(e.message, true); }
};

/* ---------------- models ---------------- */
async function renderModels() {
  try {
    const m = await api("/api/model"), nm = m.name_matcher.metrics, v = m.vision;
    const pct = x => (x * 100).toFixed(1) + "%";
    $("#modelGrid").innerHTML = `
      <div class="card"><div class="card-title">Owner-name matcher · logistic regression · ${esc(m.name_matcher.version)}</div>
        <p class="small muted">Decides whether two departments' owner names are the same person — across initials, missing middle names, spelling variants and 11 Indian scripts (transliterated first). Trained on ${fmt(m.name_matcher.training_pairs)} labelled pairs${nm.officer_labels_used ? ` including ${nm.officer_labels_used} officer decisions` : ""}.</p>
        <div class="metric"><span>Accuracy on ${fmt(nm.test_pairs)} unseen pairs</span><span><b>${pct(nm.accuracy)}</b> <span class="vs">old difflib rule ${pct(nm.old_difflib_rule_accuracy)}</span></span></div>
        <div class="metric"><span>Names in different scripts (${nm.cross_script_pairs} pairs)</span><span><b>${pct(nm.cross_script_accuracy)}</b> <span class="vs">old rule ${pct(nm.cross_script_old_rule_accuracy)}</span></span></div>
        <div class="metric"><span>F1 score</span><b>${nm.f1.toFixed(3)}</b></div>
        <div class="metric"><span>Officer labels waiting for retraining</span><b>${m.officer_labels_collected}</b></div>
        ${can("admin") ? `<button class="btn primary" id="retrainBtn" style="margin-top:10px">Retrain with officer decisions</button>` : `<p class="small muted" style="margin-top:8px">Admin can retrain the model with officers' "same / different person" decisions.</p>`}
        <div class="card-title" style="margin-top:16px">Try it — any script</div>
        <div class="try"><input class="input indic" id="tryA" value="రవి కుమార్"><input class="input indic" id="tryB" value="Ravi Kumar"></div>
        <button class="btn small" id="tryBtn" style="margin-top:8px">Compare</button><div id="tryOut" class="small" style="margin-top:8px"></div></div>
      <div class="card"><div class="card-title">Drone imagery computer vision</div>
        <p class="small muted">Finds compound walls and roofs in georeferenced ORI, matches walls to records by IoU, compares survey years for new construction, and reads building height from DSM − DTM.</p>
        ${v ? `<div class="metric"><span>Boundary walls found (IoU ≥ 0.9)</span><b>${v.boundary_iou_ge_0_9}/${v.parcels}</b></div>
        <div class="metric"><span>Mean IoU of found walls</span><b>${v.boundary_iou_mean}</b></div>
        <div class="metric"><span>Built-up area error (median)</span><b>${v.built_up_area_error_median_pct}%</b></div>
        <div class="metric"><span>New construction found</span><span><b>${v.new_construction_found}/${v.new_construction_truth}</b> <span class="vs">${v.new_construction_false_alarms} false alarms</span></span></div>
        <div class="metric"><span>Floors estimated correctly</span><b>${v.floors_correct}/${v.floors_evaluated}</b></div>
        <p class="small muted" style="margin-top:8px">${esc(v.note)} Walls hidden by trees or shadow are reported as "partly hidden — ground check", never as a shift. On real ORI the same interfaces take a trained segmentation model.</p>` : "<p class='muted'>Run tools/evaluate_vision.py to measure.</p>"}</div>
      <div class="card"><div class="card-title">Coordinate engine</div>
        <p class="small muted">WGS84 ⇄ UTM for every zone covering India (42N–47N), Krüger series. Round-trip error under 1 mm across 5,000 random points; matches an independent meridian-arc integration to 0.1 mm. Detects CRS from .prj files, EPSG codes or the coordinate values, including swapped lat/lon columns.</p></div>
      <div class="card"><div class="card-title">Which source wins (conflict resolution)</div>
        <p class="small"><b>Boundary:</b> GNSS / CORS survey › drone ORI › digitised cadastral map<br><b>Ownership:</b> Revenue record of rights › municipal record<br><b>Buildings:</b> DSM / ORI measurement › municipal record</p>
        <p class="small muted" style="margin-top:6px">Safety rule: utility easements, overlaps, owner conflicts and unrecorded construction always go to an officer, whatever the score.</p></div>`;
    const rb = $("#retrainBtn");
    if (rb) rb.onclick = async () => { rb.disabled = true; rb.textContent = "Training…"; try { const r = await api("/api/model/retrain", { method: "POST" }); toast(`Model ${r.version}: accuracy ${(r.metrics.accuracy * 100).toFixed(1)}%`); renderModels(); } catch (e) { toast(e.message, true); rb.disabled = false; } };
    $("#tryBtn").onclick = async () => {
      try {
        const r = await api(`/api/model/match?a=${encodeURIComponent($("#tryA").value)}&b=${encodeURIComponent($("#tryB").value)}`);
        $("#tryOut").innerHTML = `<b>${Math.round(r.probability * 100)}% — ${esc(r.verdict)}</b><br>Read as: “${esc(r.read_as[0])}” vs “${esc(r.read_as[1])}” (${esc(r.scripts.join(" / "))})${r.agrees_on.length ? "<br>Agrees: " + esc(r.agrees_on.join(", ")) : ""}${r.differs_on.length ? "<br>Differs: " + esc(r.differs_on.join(", ")) : ""}`;
      } catch (e) { toast(e.message, true); }
    };
  } catch (e) { toast(e.message, true); }
}

/* ---------------- start ---------------- */
// Nothing is fetched or drawn until an officer has signed in.
let started = false;
async function startApp() {
  $("#app").hidden = false; renderUser();
  if (!started) { initMap(); started = true; }
  try { await loadLocations(); } catch (e) { toast(e.message, true); }
  route();
}
(async function boot() {
  loadSession();
  if (S.user) {
    try { await api("/api/me"); return startApp(); } catch (e) { S.user = null; saveSession(); }
  }
  showGate();
})();
