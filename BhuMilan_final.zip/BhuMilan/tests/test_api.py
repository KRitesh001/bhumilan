"""
tests/test_api.py - end-to-end tests for BhuMilan.     python tests/test_api.py
Your officer decisions and ledger are backed up first and restored afterwards.
"""

import base64
import io
import json
import shutil
import struct
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient  # noqa: E402

from engine import geo, store  # noqa: E402

EXPECTED = {  # problems deliberately planted in the pilot data -> the check that must catch them
    "AP-VSK": {"005": "extra_floors", "011": "overlap", "014": "boundary_shift", "017": "utility",
               "019": "new_construction", "023": "mutation_pending"},
    "RJ-JPR": {"004": "extra_floors", "005": "boundary_shift", "007": "mutation_pending", "009": "new_construction",
               "011": "utility"},
    "MH-PNE": {"003": "new_construction", "006": "overlap", "008": "extra_floors", "010": "owner_conflict",
               "011": "boundary_shift"},
    "AS-GHY": {"003": "boundary_shift", "006": "new_construction", "009": "utility", "012": "extra_floors"},
    "OD-BBS": {"002": "overlap", "004": "utility", "007": "mutation_pending", "010": "extra_floors",
               "012": "new_construction"},
}
SAME_PERSON_ACROSS_SCRIPTS = {"AP-VSK-003", "AP-VSK-007", "AP-VSK-018", "AP-VSK-021"}


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def make_shapefile_zip(polys_utm, attrs, zone):
    """Minimal ESRI shapefile writer (polygons) - used to test the reader."""
    def rec_poly(ring):
        pts = ring + [ring[0]]
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        body = struct.pack("<i4dii", 5, min(xs), min(ys), max(xs), max(ys), 1, len(pts)) + struct.pack("<i", 0)
        body += b"".join(struct.pack("<2d", *p) for p in pts)
        return body
    recs = [rec_poly(r) for r in polys_utm]
    allx = [p[0] for r in polys_utm for p in r]
    ally = [p[1] for r in polys_utm for p in r]
    shp_body = b"".join(struct.pack(">2i", i + 1, len(b) // 2) + b for i, b in enumerate(recs))
    hdr = struct.pack(">7i", 9994, 0, 0, 0, 0, 0, (100 + len(shp_body)) // 2) + struct.pack(
        "<2i4d4d", 1000, 5, min(allx), min(ally), max(allx), max(ally), 0, 0, 0, 0)
    fields = list(attrs[0].keys())
    dbf = struct.pack("<4BIHH20x", 3, 126, 1, 1, len(attrs), 32 + 32 * len(fields) + 1, 1 + 20 * len(fields))
    for f in fields:
        dbf += f.encode()[:11].ljust(11, b"\x00") + b"C" + b"\x00" * 4 + bytes([20, 0]) + b"\x00" * 14
    dbf += b"\x0d"
    for a in attrs:
        dbf += b" " + b"".join(str(a[f]).encode()[:20].ljust(20) for f in fields)
    dbf += b"\x1a"
    z = io.BytesIO()
    with zipfile.ZipFile(z, "w") as zf:
        zf.writestr("parcels.shp", hdr + shp_body)
        zf.writestr("parcels.dbf", dbf)
        zf.writestr("parcels.prj", f'PROJCS["WGS_1984_UTM_Zone_{zone}N",GEOGCS["GCS_WGS_1984"]]')
    return z.getvalue()


class SignedIn:
    """Test client that sends an officer's session token unless a call gives its own headers."""
    def __init__(self, client, headers):
        self.c, self.h = client, headers

    def get(self, path, headers=None, **kw):
        return self.c.get(path, headers=headers or self.h, **kw)

    def post(self, path, headers=None, **kw):
        return self.c.post(path, headers=headers or self.h, **kw)


def run(anon: TestClient):
    tok = lambda u: {"Authorization": "Bearer " + anon.post("/api/login", json={"username": u, "password": "demo123"}).json()["token"]}

    # --- pages + static are public; every data route needs a signed-in officer
    assert anon.get("/").status_code == 200
    assert anon.get("/static/leaflet/leaflet.js").status_code == 200
    assert anon.get("/static/../server.py").status_code == 404
    assert anon.get("/api/accounts").status_code == 200
    for path in ["/api/locations", "/api/states", "/api/locations/AP-VSK", "/api/locations/AP-VSK/parcels/AP-VSK-014",
                 "/api/locations/AP-VSK/parcels/AP-VSK-014/evidence.jpg", "/imagery/AP-VSK/AP-VSK-014/ori_2025.jpg",
                 "/api/locations/AP-VSK/export.csv", "/api/locations/AP-VSK/export.geojson", "/ogc/collections",
                 "/ogc/collections/AP-VSK-parcels/items", "/api/audit-log", "/api/audit-log/verify", "/api/model",
                 "/api/model/match?a=Ravi&b=Ravi", "/api/locations/AP-VSK/parcels/AP-VSK-014/evidence.jpg?token=forged"]:
        assert anon.get(path).status_code == 401, path
    assert anon.post("/api/locations/AP-VSK/run").status_code == 401
    adm = tok("admin")
    c = SignedIn(anon, adm)
    # image/download links carry the token in the URL
    t = adm["Authorization"][7:]
    assert anon.get(f"/api/locations/AP-VSK/parcels/AP-VSK-014/evidence.jpg?token={t}").status_code == 200
    assert anon.get(f"/api/locations/AP-VSK/export.csv?token={t}").status_code == 200
    # an officer only sees their own jurisdiction
    ri_view = tok("ri.vsk")
    assert [l["id"] for l in anon.get("/api/locations", headers=ri_view).json()] == ["AP-VSK"]
    assert anon.get("/api/locations/RJ-JPR", headers=ri_view).status_code == 403
    assert anon.get("/ogc/collections/RJ-JPR-parcels/items", headers=ri_view).status_code == 403
    assert all(e["location"] in ("AP-VSK", "INDIA") for e in anon.get("/api/audit-log", headers=ri_view).json()["entries"])
    # logging out kills the token
    anon.post("/api/logout", headers=ri_view)
    assert anon.get("/api/locations", headers=ri_view).status_code == 401
    print("Sign-in required for all data; jurisdiction limits what each officer sees")

    # --- every planted problem is found; same-person names in other scripts are NOT flagged
    locs = {l["id"]: l for l in c.get("/api/locations").json()}
    assert set(EXPECTED) <= set(locs), locs.keys()
    caught = 0
    for loc, exp in EXPECTED.items():
        d = c.get(f"/api/locations/{loc}").json()
        by = {p["parcel_id"][-3:]: p for p in d["parcels"]}
        for n, issue in exp.items():
            assert issue in by[n]["issues"], (loc, n, issue, by[n]["issues"])
            caught += 1
        for p in d["parcels"]:
            if p["parcel_id"] in SAME_PERSON_ACROSS_SCRIPTS:
                assert not any(i.startswith("owner") for i in p["issues"]), p["parcel_id"]
    print(f"All {caught} planted problems caught; cross-script owners accepted")

    # --- permissions and jurisdiction
    assert anon.post("/api/locations/AP-VSK/parcels/AP-VSK-014/decide", json={"action": "ACCEPT_RECORD"}).status_code == 401
    assert c.post("/api/login", json={"username": "ri.vsk", "password": "x"}).status_code == 401
    ri, rij = tok("ri.vsk"), tok("ri.jaipur")
    assert c.post("/api/locations/RJ-JPR/parcels/RJ-JPR-005/decide", json={"action": "ACCEPT_RECORD"}, headers=ri).status_code == 403
    assert c.post("/api/locations/AP-VSK/parcels/AP-VSK-014/decide", json={"action": "ACCEPT_RECORD"}, headers=tok("surveyor")).status_code == 403
    assert c.post("/api/locations/AP-VSK/certify", headers=ri).status_code == 403
    print("Roles and jurisdiction enforced")

    # --- applying recommendations corrects the records (and the fix cascades to neighbours)
    r = c.post("/api/locations/AP-VSK/parcels/AP-VSK-014/decide", json={"action": "APPLY_RECOMMENDATIONS", "remarks": "t"}, headers=ri).json()
    assert r["parcel"]["corrected"] and r["parcel"]["status"].startswith("Verified") and not r["parcel"]["issues"]
    c.post("/api/locations/AP-VSK/parcels/AP-VSK-011/decide", json={"action": "APPLY_RECOMMENDATIONS"}, headers=ri)
    d = c.get("/api/locations/AP-VSK").json()
    assert "overlap" not in next(p for p in d["parcels"] if p["parcel_id"] == "AP-VSK-010")["issues"]
    r = c.post("/api/locations/AP-VSK/parcels/AP-VSK-023/decide", json={"action": "APPLY_RECOMMENDATIONS"}, headers=ri).json()
    assert "mutation_pending" not in r["parcel"]["issues"]
    r = c.post("/api/locations/RJ-JPR/parcels/RJ-JPR-005/decide", json={"action": "ORDER_GNSS_SURVEY"}, headers=rij).json()
    assert r["parcel"]["status"] == "Ground survey ordered"
    r = c.post("/api/locations/AP-VSK/parcels/AP-VSK-014/decide", json={"action": "UNDO"}, headers=ri).json()
    assert "boundary_shift" in r["parcel"]["issues"]
    assert c.post("/api/locations/AP-VSK/parcels/AP-VSK-021/owner-label", json={"same_person": True}, headers=ri).status_code == 200
    cert = c.post("/api/locations/AP-VSK/certify", headers=tok("tahsildar.vsk")).json()
    assert cert["certified_count"] >= 18
    print(f"Decisions correct records; batch certified {cert['certified_count']} parcels")

    # --- evidence images
    for u in ("evidence.jpg", "change.jpg", "ndsm.png"):
        assert c.get(f"/api/locations/RJ-JPR/parcels/RJ-JPR-009/{u}").status_code == 200
    print("Evidence images OK")

    # --- a brand-new location: cadastral map as a UTM shapefile, municipal CSV with odd headers, KML utilities
    gis = tok("gis.officer")
    m = c.post("/api/locations", json={"state": "Telangana", "district": "Hyderabad", "city": "Test City"}, headers=gis).json()
    loc = m["id"]
    try:
        lat0, lon0 = 17.4400, 78.3800
        e0, n0, zone = geo.latlon_to_utm(lat0, lon0)
        polys = [[(e0 + x, n0), (e0 + x + 20, n0), (e0 + x + 20, n0 + 18), (e0 + x, n0 + 18)] for x in (0, 30)]
        shp = make_shapefile_zip(polys, [{"SY_NO": "101/A", "VILLAGE": "Gachibowli"}, {"SY_NO": "102/B", "VILLAGE": "Gachibowli"}], zone)
        pv = c.post("/api/upload/preview", json={"location": loc, "dataset_type": "cadastral", "filename": "parcels.zip",
                                                  "content_base64": b64(shp)}, headers=gis).json()
        assert "UTM zone 44N" in pv["crs"] and pv["report"]["rows_ok"] == 2, pv
        mapping = {col["column"]: col["field"] for col in pv["columns"]}
        assert mapping["SY_NO"] == "survey_number"
        r = c.post("/api/upload/commit", json={"location": loc, "dataset_type": "cadastral", "filename": "parcels.zip",
                                                "content_base64": b64(shp), "mapping": mapping}, headers=gis).json()
        assert r["success"]
        (clat, clon), = geo.from_local_m([(10, 9)], (lat0, lon0))
        csv_txt = ("खसरा नंबर,खातेदार का नाम,पिता का नाम,क्षेत्रफल हेक्टेयर\n101/A,रवि कुमार,सुरेश कुमार,0.036\n102/B,प्रिया रेड्डी,मोहन रेड्डी,0.036\n")
        pv = c.post("/api/upload/preview", json={"location": loc, "dataset_type": "revenue", "filename": "rev.csv",
                                                  "content_base64": b64(csv_txt.encode("utf-8"))}, headers=gis).json()
        mp = {col["column"]: col["field"] for col in pv["columns"]}
        assert mp == {"खसरा नंबर": "survey_number", "खातेदार का नाम": "owner_name", "पिता का नाम": "father_name",
                      "क्षेत्रफल हेक्टेयर": "area"}, mp
        units = {col["field"]: col["unit_m2"] for col in pv["columns"] if col["unit_m2"]}
        assert units == {"area": 10000.0}
        c.post("/api/upload/commit", json={"location": loc, "dataset_type": "revenue", "filename": "rev.csv",
                                           "content_base64": b64(csv_txt.encode("utf-8")), "mapping": mp, "units": units}, headers=gis)
        mun = f"Door No,Name of Owner,S/O,GPS Lat,GPS Long,Built Up (Sq Yd),Storeys\n1-2-3,Ravi Kumar,Suresh Kumar,{clat},{clon},120,2\n"
        pv = c.post("/api/upload/preview", json={"location": loc, "dataset_type": "municipal", "filename": "mun.csv",
                                                  "content_base64": b64(mun.encode())}, headers=gis).json()
        mp = {col["column"]: col["field"] for col in pv["columns"]}
        assert mp["Name of Owner"] == "owner_name" and mp["GPS Lat"] == "lat" and mp["Built Up (Sq Yd)"] == "built_up_area"
        c.post("/api/upload/commit", json={"location": loc, "dataset_type": "municipal", "filename": "mun.csv",
                                           "content_base64": b64(mun.encode()), "mapping": mp,
                                           "units": {"built_up_area": 0.83612736}}, headers=gis)
        (ulat, ulon), (ulat2, ulon2) = geo.from_local_m([(-20, 19.5), (80, 19.5)], (lat0, lon0))
        kml = (f'<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><Placemark><name>Water main</name>'
               f'<ExtendedData><Data name="type"><value>water</value></Data></ExtendedData><LineString><coordinates>'
               f'{ulon},{ulat},0 {ulon2},{ulat2},0</coordinates></LineString></Placemark></Document></kml>')
        pv = c.post("/api/upload/preview", json={"location": loc, "dataset_type": "utilities", "filename": "u.kml",
                                                  "content_base64": b64(kml.encode())}, headers=gis).json()
        c.post("/api/upload/commit", json={"location": loc, "dataset_type": "utilities", "filename": "u.kml",
                                           "content_base64": b64(kml.encode()),
                                           "mapping": {col["column"]: col["field"] for col in pv["columns"]}}, headers=gis)
        d = c.get(f"/api/locations/{loc}").json()
        p1 = d["parcels"][0]
        assert abs(p1["area_m2"] - 360) < 1, p1["area_m2"]
        assert p1["owner_match"]["probability"] > 0.9, p1["owner_match"]           # रवि कुमार == Ravi Kumar
        assert "utility" in p1["issues"]                                             # 1.5 m from the water main
        print(f"New location {loc}: UTM shapefile + Hindi CSV + KML ingested and harmonized")
    finally:
        store.delete_location(loc)

    # --- sharing: exports + OGC API Features
    assert c.get("/api/locations/MH-PNE/export.geojson").status_code == 200
    assert c.get("/api/locations/MH-PNE/export.csv").status_code == 200
    col = c.get("/ogc/collections").json()["collections"]
    assert any(x["id"] == "AP-VSK-parcels" for x in col)
    items = json.loads(c.get("/ogc/collections/AP-VSK-parcels/items?limit=5").content)
    assert items["numberReturned"] == 5 and items["numberMatched"] == 24
    print("Exports and OGC API - Features OK")

    # --- models
    mi = c.get("/api/model").json()
    assert mi["name_matcher"]["metrics"]["accuracy"] > 0.95
    assert c.get("/api/model/match?a=%E0%B0%B0%E0%B0%B5%E0%B0%BF&b=Ravi").json()["probability"] > 0.9

    # --- tamper-evident ledger
    adm = tok("admin")
    assert c.get("/api/audit-log/verify").json()["valid"]
    assert c.post("/api/demo/tamper", headers=adm).status_code == 200
    v = c.get("/api/audit-log/verify").json()
    assert not v["valid"] and v["broken_at"] is not None
    c.post("/api/demo/restore", headers=adm)
    assert c.get("/api/audit-log/verify").json()["valid"]
    print(f"Ledger tampering detected at entry #{v['broken_at']} and restored")

    # --- geo engine sanity
    e, n, z = geo.latlon_to_utm(28.6139, 77.2090)
    la, lo = geo.utm_to_latlon(e, n, z)
    assert z == 43 and abs(la - 28.6139) < 1e-8 and abs(lo - 77.2090) < 1e-8
    print("\nALL TESTS PASSED")


def main():
    state, training = store.STATE, store.TRAINING
    backup = Path(tempfile.mkdtemp())
    for src, name in ((state, "state"), (training, "training")):
        if src.exists():
            shutil.copytree(src, backup / name)
            shutil.rmtree(src)
    try:
        from server import app
        run(TestClient(app))
    finally:
        for src, name in ((state, "state"), (training, "training")):
            if src.exists():
                shutil.rmtree(src)
            if (backup / name).exists():
                shutil.copytree(backup / name, src)
        shutil.rmtree(backup, ignore_errors=True)


if __name__ == "__main__":
    main()
